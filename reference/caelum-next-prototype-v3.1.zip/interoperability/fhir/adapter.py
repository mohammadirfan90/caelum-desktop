"""HL7 FHIR R4 export: Observation (+ Device reference), Bundle. Codes come from the parameter
catalog; parameters without a LOINC code are exported with a local CAELUM code system."""
import uuid
from typing import Any, Optional

from app.core_time import as_utc
from app.domain.parameters import PARAMETERS

LOCAL_SYSTEM = "urn:caelum:parameter"
CATEGORY = {"vital-signs": "vital-signs", "derived": "exam", "environment": "survey",
            "context": "activity"}


class FHIRAdapter:
    @staticmethod
    def observation(o: Any, device: Optional[Any] = None) -> dict:
        spec = PARAMETERS[o.parameter]
        coding = ([{"system": "http://loinc.org", "code": spec.loinc, "display": spec.loinc_display}]
                  if spec.loinc else [])
        coding.append({"system": LOCAL_SYSTEM, "code": spec.key, "display": spec.label})
        res = {
            "resourceType": "Observation",
            "id": f"obs-{o.id}",
            "status": "final" if o.quality in ("GOOD", "DEGRADED") else "entered-in-error",
            "category": [{"coding": [{
                "system": "http://terminology.hl7.org/CodeSystem/observation-category",
                "code": CATEGORY[spec.category]}]}],
            "code": {"coding": coding, "text": spec.label},
            "subject": {"reference": f"Patient/{o.astronaut_id}"},
            "effectiveDateTime": as_utc(o.measured_at).isoformat(),
            "valueQuantity": {"value": round(float(o.value), 3), "unit": spec.unit,
                              "system": "http://unitsofmeasure.org", "code": spec.ucum},
            "device": {"reference": f"Device/{o.device_id}"},
        }
        if o.quality != "GOOD":
            res["interpretation"] = [{"text": f"Signal quality {o.quality}"}]
        if o.simulated or (device is not None and device.is_simulated):
            res["meta"] = {"tag": [{"system": "urn:caelum:provenance", "code": "SIMULATED"}]}
        return res

    @staticmethod
    def bundle(resources: list[dict]) -> dict:
        return {"resourceType": "Bundle", "id": f"bundle-{uuid.uuid4().hex[:12]}",
                "type": "collection", "entry": [{"resource": r} for r in resources]}
