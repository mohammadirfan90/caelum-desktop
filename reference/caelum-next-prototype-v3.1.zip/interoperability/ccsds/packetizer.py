"""CCSDS Space Packet (CCSDS 133.0-B-2) framing.

The secondary-header flag is set ONLY when a secondary header is actually present. The optional
secondary header here is a CCSDS Unsegmented Time Code (CUC, CCSDS 301.0-B) with an implicit
P-field: 4 bytes coarse seconds + 2 bytes fine time, relative to a mission-defined epoch.
"""
import struct
from typing import Any, Optional

APID_CREW_HEALTH = 0x01E4
MAX_DATA_FIELD = 65536


def cuc_time(seconds_since_epoch: float) -> bytes:
    coarse = int(seconds_since_epoch)
    fine = int(round((seconds_since_epoch - coarse) * 65536)) & 0xFFFF
    return struct.pack(">IH", coarse & 0xFFFFFFFF, fine)


def frame_packet(apid: int, sequence_count: int, user_data: bytes,
                 time_since_epoch: Optional[float] = None) -> bytes:
    if not 0 <= apid <= 0x7FF:
        raise ValueError("APID must be 11 bits")
    sec = cuc_time(time_since_epoch) if time_since_epoch is not None else b""
    data_field = sec + user_data
    if not 1 <= len(data_field) <= MAX_DATA_FIELD:
        raise ValueError("packet data field must be 1..65536 bytes")
    packet_id = (0 << 13) | (0 << 12) | ((1 if sec else 0) << 11) | apid
    seq_ctrl = (0b11 << 14) | (sequence_count % 16384)
    return struct.pack(">HHH", packet_id, seq_ctrl, len(data_field) - 1) + data_field


def parse_primary_header(packet: bytes) -> dict[str, Any]:
    if len(packet) < 6:
        raise ValueError("packet shorter than the 6-byte primary header")
    pid, seq, length = struct.unpack(">HHH", packet[:6])
    if len(packet) != 6 + length + 1:
        raise ValueError("packet length field does not match packet size")
    return {"version": pid >> 13, "type": "telecommand" if (pid >> 12) & 1 else "telemetry",
            "has_secondary_header": bool((pid >> 11) & 1), "apid": pid & 0x7FF,
            "sequence_flags": seq >> 14, "sequence_count": seq & 0x3FFF, "data_length": length + 1}


class CCSDSPacketizer:  # backwards-compatible facade
    APID_CREW_HEALTH = APID_CREW_HEALTH
    frame_packet = staticmethod(frame_packet)
    parse_primary_header = staticmethod(parse_primary_header)
