from datetime import datetime, timezone
from types import SimpleNamespace

import pytest

from interoperability.ccsds.packetizer import frame_packet, parse_primary_header
from interoperability.fhir.adapter import FHIRAdapter
from interoperability.ground.openmct_provider import dictionary


def test_ccsds_secondary_header_flag_matches_content():
    plain = parse_primary_header(frame_packet(0x1E4, 5, b"abc"))
    assert plain["has_secondary_header"] is False and plain["data_length"] == 3
    timed = parse_primary_header(frame_packet(0x1E4, 16385, b"abc", time_since_epoch=12.5))
    assert timed["has_secondary_header"] is True and timed["data_length"] == 9
    assert timed["sequence_count"] == 1  # wraps at 16384
    with pytest.raises(ValueError):
        parse_primary_header(frame_packet(0x1E4, 1, b"abc")[:-1])


def test_fhir_spo2_uses_pulse_oximetry_loinc_and_flags_simulated():
    o = SimpleNamespace(id=1, parameter="spo2", value=97.0, quality="GOOD", astronaut_id="ast-01",
                        measured_at=datetime.now(timezone.utc), device_id="sim-01", simulated=True)
    r = FHIRAdapter.observation(o)
    assert r["code"]["coding"][0]["code"] == "59408-5"
    assert r["meta"]["tag"][0]["code"] == "SIMULATED"


def test_openmct_dictionary_generated_from_catalog():
    keys = [m["key"] for m in dictionary()["measurements"]]
    assert "caelum.vital-signs.spo2" in keys
