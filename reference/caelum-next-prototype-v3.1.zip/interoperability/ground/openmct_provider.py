"""Open MCT telemetry dictionary generated from the parameter catalog (single source of truth)."""
from app.domain.parameters import PARAMETERS


def dictionary() -> dict:
    return {"name": "CAELUM Crew Health", "key": "caelum.health", "measurements": [
        {"name": p.label, "key": f"caelum.{p.category}.{p.key}",
         "values": [{"key": "value", "name": p.label, "units": p.unit, "format": "float",
                     "min": p.plausible[0], "max": p.plausible[1], "hints": {"range": 1}},
                    {"key": "utc", "source": "timestamp", "name": "Timestamp", "format": "utc",
                     "hints": {"domain": 1}}]}
        for p in PARAMETERS.values()]}
