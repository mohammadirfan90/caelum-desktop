import pytest

from acquisition.astroskin.adapter import AstroSkinAdapter
from acquisition.gateway.gateway import AcquisitionGateway
from acquisition.spacecraft.bridge import SpacecraftTelemetryBridge
from acquisition.synchronization.sync import TimeSynchronizer


def test_gateway_buffers_and_counts_drops():
    gw = AcquisitionGateway(max_buffer=2)
    gw.register_device("d1", "Test", "wearable", "ble_standard")
    assert gw.devices["d1"]["status"] == "DISCONNECTED"
    for i in range(3):
        assert gw.ingest_packet("d1", {"i": i})
    assert gw.dropped == 1 and len(gw.drain_buffer()) == 2
    assert gw.ingest_packet("unknown", {}) is False


def test_bridge_never_fabricates_missing_values():
    r = SpacecraftTelemetryBridge().parse_vehicle_telemetry_frame({"met_hours": 240.0, "cabin_o2_kpa": 21.0})
    assert r["met_day"] == 11 and r["values"]["cabin_o2"] == 21.0
    assert r["values"]["cabin_co2"] is None and "cabin_co2" in r["missing"]


def test_unimplemented_garment_refuses_to_produce_data():
    with pytest.raises(NotImplementedError):
        AstroSkinAdapter("g1").parse_telemetry_frame(b"\x00")


def test_time_synchronizer_clock_skew():
    s = TimeSynchronizer()
    s.update_clock_offset("dev-1", 1000.0, 1002.5)
    assert abs(s.normalize_timestamp("dev-1", 1000.0) - 1002.5) < 0.01
