"""Local acquisition gateway: tracks device links and buffers packets for the ingestion API."""
import time
from collections import deque
from datetime import datetime, timezone
from typing import Any


class AcquisitionGateway:
    def __init__(self, max_buffer: int = 10000):
        self.devices: dict[str, dict[str, Any]] = {}
        self.buffer: deque = deque(maxlen=max_buffer)
        self.dropped = 0

    def register_device(self, device_id: str, name: str, category: str, adapter: str) -> None:
        self.devices[device_id] = {"id": device_id, "name": name, "category": category,
                                   "adapter": adapter, "status": "DISCONNECTED",
                                   "last_packet_time": None, "packets_received": 0}

    def ingest_packet(self, device_id: str, data: dict[str, Any]) -> bool:
        dev = self.devices.get(device_id)
        if dev is None:
            return False
        if len(self.buffer) == self.buffer.maxlen:
            self.dropped += 1  # oldest packet is evicted; counted so the loss is visible
        dev.update(status="STREAMING", last_packet_time=time.time(),
                   packets_received=dev["packets_received"] + 1)
        self.buffer.append({"device_id": device_id, "data": data,
                            "gateway_timestamp": datetime.now(timezone.utc).isoformat()})
        return True

    def drain_buffer(self) -> list[dict[str, Any]]:
        out = list(self.buffer)
        self.buffer.clear()
        return out
