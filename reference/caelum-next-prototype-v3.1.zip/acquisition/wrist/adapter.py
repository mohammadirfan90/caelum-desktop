"""Wrist-module adapter. Maps an already-decoded packet; missing fields stay missing (None)."""
from datetime import datetime, timezone
from typing import Any, Optional


class WristModuleAdapter:
    adapter_id = "wrist_module"

    def __init__(self, device_id: str):
        self.device_id = device_id

    def parse_packet(self, data: dict[str, Any], measured_at: Optional[datetime] = None) -> dict[str, Any]:
        return {"device_id": self.device_id,
                "measured_at": (measured_at or datetime.now(timezone.utc)).isoformat(),
                "eda_us": data.get("eda"), "ppg_raw": data.get("ppg"),
                "skin_temp_c": data.get("temp"), "accel_magnitude_g": data.get("accel_mag")}
