"""Smart-garment adapter (Astroskin/Hexoskin-class). NOT IMPLEMENTED.

The previous version returned hard-coded 'normal' values (SpO2 98, skin temp 34.5) for every
frame, which would have hidden real deterioration. Until the vendor export/API format is
integrated, this adapter refuses to produce data. See backend/app/devices/registry.py.
"""


class AstroSkinAdapter:
    adapter_id = "smart_garment"
    status = "planned"

    def __init__(self, device_id: str):
        self.device_id = device_id

    def parse_telemetry_frame(self, raw: bytes):
        raise NotImplementedError("Smart-garment decoding is not implemented; no data is fabricated.")
