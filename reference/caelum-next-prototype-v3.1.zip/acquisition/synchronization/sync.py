from typing import Dict

class TimeSynchronizer:
    """
    Clock synchronization and drift compensator between wearable sensor local oscillators
    and Spacecraft Master Time (Mission Elapsed Time - MET / GPS time).
    """
    def __init__(self):
        self.device_offsets: Dict[str, float] = {} # Offset in seconds

    def update_clock_offset(self, device_id: str, device_timestamp_sec: float, master_timestamp_sec: float):
        """Calculates and stores running exponential moving average clock skew."""
        skew = master_timestamp_sec - device_timestamp_sec
        if device_id in self.device_offsets:
            self.device_offsets[device_id] = 0.9 * self.device_offsets[device_id] + 0.1 * skew
        else:
            self.device_offsets[device_id] = skew

    def normalize_timestamp(self, device_id: str, device_timestamp_sec: float) -> float:
        offset = self.device_offsets.get(device_id, 0.0)
        return device_timestamp_sec + offset
