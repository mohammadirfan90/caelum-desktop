"""Read-only spacecraft environment bridge. Normalizes a vehicle telemetry frame.

Missing fields are reported as None. The previous version silently substituted nominal cabin
values (e.g. CO2 3280 ppm, O2 21.3 kPa), which could mask a real atmosphere problem.
"""
from datetime import datetime, timezone
from typing import Any, Optional

FIELDS = {"cabin_o2_kpa": "cabin_o2", "cabin_co2_mmhg": "cabin_co2",
          "cabin_pressure_kpa": "cabin_pressure", "radiation_rate_usv_h": "radiation_dose_rate"}


class SpacecraftTelemetryBridge:
    security_mode = "READ_ONLY_ENFORCED"  # this class has no write/command path by design

    def __init__(self, bridge_name: str = "vehicle-bridge"):
        self.bridge_name = bridge_name

    def parse_vehicle_telemetry_frame(self, frame: dict[str, Any]) -> dict[str, Any]:
        met: Optional[float] = frame.get("met_hours")
        values = {param: (float(frame[k]) if frame.get(k) is not None else None)
                  for k, param in FIELDS.items()}
        return {"bridge": self.bridge_name, "received_at": datetime.now(timezone.utc).isoformat(),
                "met_hours": met, "met_day": int(met // 24) + 1 if met is not None else None,
                "values": values, "missing": [p for p, v in values.items() if v is None],
                "security_mode": self.security_mode}
