# Codebase Zip Maintenance Rule

## Obligation
Whenever you add, modify, or delete any source code, components, styles, or configuration files in this codebase, you **MUST ALWAYS** run the atomic Python packager and verifier at the end of the turn before finishing:

```bash
python scripts/package_codebase.py
python scripts/verify_archive.py
```

Or:

```bash
npm run zip
npm run verify:zip
```

## Details
- The script packages the entire clean codebase into `caelum-next.zip` in the project root and copies it to `../caelum-next.zip`.
- It executes `check_secrets.py` beforehand to prevent accidental leakage of sensitive keys or credentials.
- It validates the presence of all required subsystems (`frontend`, `backend`, `acquisition`, `interoperability`, `docs`, `scripts`).
- It generates a SHA-256 checksum saved to `caelum-next.zip.sha256`.
- It excludes `node_modules`, `.next`, `.venv`, `*.zip`, `.git`, databases, and build caches.
- Always verify that the script exited successfully (exit code 0).
