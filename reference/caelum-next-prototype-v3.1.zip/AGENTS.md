# CAELUM: rules for AI coding assistants

Read `docs/AUDIT_REPORT.md` first. It lists every known defect, what has been fixed, and the
remaining work in priority order.

## Non-negotiable safety rules
1. **Never fabricate physiological data.** No `Math.random()`, constants or "nominal" defaults
   standing in for a measurement. Missing data is shown as NO DATA / STALE / UNAVAILABLE.
2. **No silent fallback.** In `NEXT_PUBLIC_DATA_MODE=live` the frontend must never show demo data
   when the backend fails. Demo data is allowed only in demo mode and must be labelled.
3. **Simulated data is always labelled.** Anything from the simulator carries `simulated=true`
   end to end (observation, alert, FHIR tag, UI).
4. **Absolute safety limits are never overridden.** Baselines may add early warnings; they may
   never suppress, delay or downgrade an absolute-limit alert. Every rule change bumps
   `RULES_VERSION` and adds/updates a test in `backend/tests/test_alert_engine.py`.
5. **Read-only to the spacecraft and to therapeutic devices.** No command path to vehicle
   systems, defibrillators or any device that can act on a person.
6. **Every endpoint requires authentication** and enforces role/astronaut scoping
   (`ensure_can_read_astronaut`). Mission Control never receives raw physiology.
7. **One source of truth for parameters:** `backend/app/domain/parameters.py`.

## Workflow
- Backend: `cd backend && uv sync --extra dev && uv run pytest` must pass.
- Frontend: `pnpm install && pnpm typecheck:frontend && pnpm build:frontend` must pass offline.
- Package: `npm run zip && npm run verify:zip` before handing over a release.
- Next.js 16: read `frontend/node_modules/next/dist/docs/` before using unfamiliar APIs.
