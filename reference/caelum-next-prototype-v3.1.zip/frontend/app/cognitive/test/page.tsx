"use client"

import CognitiveTest from "@/modules/cognitive/Test"

export default function CognitiveTestPage() {
  return <CognitiveTest />
}
