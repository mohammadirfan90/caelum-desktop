"use client"

import Cognitive from "@/modules/cognitive"

export default function CognitivePage() {
  return <Cognitive />
}
