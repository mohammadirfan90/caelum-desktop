"use client"

import Alerts from "@/screens/Alerts"

export default function AlertsPage() {
  return <Alerts />
}
