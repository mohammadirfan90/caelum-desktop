"use client"

import Contested from "@/modules/contested"

export default function ContestedPage() {
  return <Contested />
}
