"use client"

import * as React from "react"
import { useRouter } from "next/navigation"
import { login } from "@/api/http"
import { DATA_MODE } from "@/api/config"

export default function LoginPage() {
  const router = useRouter()
  const [username, setUsername] = React.useState("")
  const [password, setPassword] = React.useState("")
  const [error, setError] = React.useState<string | null>(null)
  const [busy, setBusy] = React.useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setBusy(true)
    setError(null)
    try {
      await login(username, password)
      router.push("/")
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign-in failed")
    } finally {
      setBusy(false)
    }
  }

  const quick = [
    ["varga", "Cdr. Ines Varga", "Astronaut: sees only her own data"],
    ["chen", "Dr. Alexei Chen", "Crew medical officer: whole crew, onboard"],
    ["surgeon", "Flight surgeon", "Ground, full medical detail"],
    ["mcc", "Mission control", "Ground operations: status only, no physiology"],
  ]
  const demoLogin = process.env.NEXT_PUBLIC_DEMO_LOGIN === "true"
  async function quickLogin(u: string) {
    setUsername(u)
    setBusy(true)
    setError(null)
    try {
      await login(u, "caelum-dev")
      router.push(u === "surgeon" || u === "mcc" ? "/presenter" : "/")
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign-in failed")
    } finally {
      setBusy(false)
    }
  }

  return (
    <main style={{ maxWidth: 380, margin: "12vh auto", padding: 24, fontFamily: "Outfit, system-ui, sans-serif" }}>
      <h1 style={{ fontSize: 28, fontWeight: 600, margin: "0 0 6px" }}>Sign in</h1>
      <p style={{ color: "#555", margin: "0 0 20px" }}>
        {DATA_MODE === "live" ? "Connect to the onboard CAELUM server." : "Demo mode does not need sign-in."}
      </p>
      {demoLogin && (
        <section aria-label="Demo roles" style={{ display: "grid", gap: 8, marginBottom: 20 }}>
          <div style={{ fontWeight: 600 }}>Demo: sign in as</div>
          {quick.map(([u, name, desc]) => (
            <button key={u} type="button" onClick={() => quickLogin(u)} disabled={busy}
              style={{ textAlign: "left", padding: 12, borderRadius: 10, border: "1px solid #bbb", background: "#fff", font: "inherit", cursor: "pointer" }}>
              <b>{name}</b>
              <div style={{ fontSize: 13, color: "#555" }}>{desc}</div>
            </button>
          ))}
          <div style={{ fontSize: 12.5, color: "#777" }}>Demo accounts exist only on a development server.</div>
        </section>
      )}
      <form onSubmit={submit} style={{ display: "grid", gap: 12 }}>
        <label style={{ display: "grid", gap: 4 }}>
          Username
          <input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" required
            style={{ padding: 10, fontSize: 16, borderRadius: 8, border: "1px solid #bbb" }} />
        </label>
        <label style={{ display: "grid", gap: 4 }}>
          Password
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password" required
            style={{ padding: 10, fontSize: 16, borderRadius: 8, border: "1px solid #bbb" }} />
        </label>
        {error && <p role="alert" style={{ color: "#b42318", margin: 0 }}>{error}</p>}
        <button type="submit" disabled={busy}
          style={{ padding: 12, fontSize: 16, fontWeight: 600, borderRadius: 8, border: 0, background: "#006D58", color: "#fff" }}>
          {busy ? "Signing in" : "Sign in"}
        </button>
      </form>
    </main>
  )
}
