"use client"

import Timeline from "@/screens/Timeline"

export default function TimelinePage() {
  return <Timeline />
}
