"use client"
import type { ReactNode } from "react"
import { DATA_MODE } from "@/api/config"
import { useSession } from "@/components/LiveSync"
import { Link } from "@/components/Link"

const ALLOWED = ["Flight Surgeon", "Mission Control", "Medical Officer", "Administrator"]

/** Ground and medical screens: in live mode only for medical and ground roles (server role). */
export default function McLayout({ children }: { children: ReactNode }) {
  const s = useSession()
  if (DATA_MODE === "live" && !ALLOWED.includes(s?.user.role ?? "")) {
    return (
      <div style={{ padding: 32, fontFamily: "Outfit, system-ui, sans-serif" }}>
        <h1 style={{ fontSize: 24 }}>Restricted</h1>
        <p>Mission control and flight-surgeon screens need a ground or medical role.</p>
        <Link href="/login" style={{ textDecoration: "underline" }}>Sign in with another role</Link>
      </div>
    )
  }
  return <>{children}</>
}
