import { redirect } from "next/navigation"

export default function MissionControlIndex() {
  redirect("/mc/hazards")
}
