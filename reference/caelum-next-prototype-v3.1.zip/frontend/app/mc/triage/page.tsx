"use client"

import Triage from "@/modules/triage"

export default function TriagePage() {
  return <Triage />
}
