"use client"

import Hazards from "@/modules/hazards"

export default function HazardsPage() {
  return <Hazards />
}
