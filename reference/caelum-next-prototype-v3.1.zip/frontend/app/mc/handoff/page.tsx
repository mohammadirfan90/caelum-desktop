"use client"

import Triage from "@/modules/triage"

export default function HandoffPage() {
  return <Triage />
}
