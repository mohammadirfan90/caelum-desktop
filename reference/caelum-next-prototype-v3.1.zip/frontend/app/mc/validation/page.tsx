"use client"

import Validation from "@/modules/validation"

export default function ValidationPage() {
  return <Validation />
}
