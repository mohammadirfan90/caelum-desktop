"use client"

import Immune from "@/modules/immune"

export default function ImmunePage() {
  return <Immune />
}
