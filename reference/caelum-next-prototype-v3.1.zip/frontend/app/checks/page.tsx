"use client"

import Scheduler from "@/modules/scheduler"

export default function ChecksPage() {
  return <Scheduler />
}
