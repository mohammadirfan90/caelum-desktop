"use client"

import Coach from "@/modules/coach"

export default function CoachPage() {
  return <Coach />
}
