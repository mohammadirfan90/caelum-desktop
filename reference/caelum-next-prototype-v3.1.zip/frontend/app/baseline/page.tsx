"use client"

import Baseline from "@/screens/Baseline"

export default function BaselinePage() {
  return <Baseline />
}
