"use client"

import Heart from "@/modules/heart"

export default function BodyPage() {
  return <Heart />
}
