"use client"

import Sources from "@/screens/Sources"

export default function SourcesPage() {
  return <Sources />
}
