"use client"
/**
 * Presenter console (prototype only). Drives the simulator; everything downstream is the real
 * system: ingestion, alert engine, escalation, audit log and downlink queue.
 */
import * as React from "react"
import { useQuery, useQueryClient } from "@tanstack/react-query"
import { DATA_MODE } from "@/api/config"
import { http } from "@/api/http"
import { setDemoScenario, useLiveTelemetry, valueStatus } from "@/api/live"
import { useCrew } from "@/api/crew"
import { useSession } from "@/components/LiveSync"
import { Link } from "@/components/Link"

interface Scenario { id: string; label: string; description: string; expect: string }
interface DemoState { enabled: boolean; time_scale: number; crew: Record<string, string>; scenarios: Scenario[] }

const DEMO_SCENARIOS: Scenario[] = [
  { id: "normal", label: "Normal day", description: "All vitals within personal range.", expect: "No alerts." },
  { id: "hypoxia", label: "Oxygen dropping", description: "SpO2 falls about 0.5 % per second.", expect: "Live mode: critical alert ~50 s, then escalation." },
  { id: "tachycardia", label: "Extreme heart rate", description: "Heart rate jumps to ~185 bpm.", expect: "Live mode: critical alert ~40 s." },
  { id: "bradycardia", label: "Very low heart rate", description: "Heart rate drops to ~36 bpm.", expect: "Live mode: critical alert ~40 s." },
  { id: "fever", label: "Fever developing", description: "Core temperature climbs.", expect: "Live mode: fever warning." },
  { id: "co2", label: "Cabin CO2 rising", description: "Cabin CO2 rises to 6 mmHg.", expect: "Live mode: environment warning." },
  { id: "sensor_fault", label: "Loose sensor", description: "HR and SpO2 signals unusable.", expect: "Live mode: sensor advisory, no false alarm." },
]

const STEPS = ["Sensors", "Ingestion & validation", "Alert engine", "Escalation", "Audit + downlink"]
const EVENT_TEXT: Record<string, string> = {
  alert: "Alert raised", escalation: "Escalated", "alert-acknowledged": "Acknowledged",
  "alert-resolved": "Resolved", "alert-superseded": "Superseded", demo: "Scenario",
}

export default function Presenter() {
  const live = useLiveTelemetry()
  const s = useSession()
  const qc = useQueryClient()
  const { data: crew } = useCrew()
  const [target, setTarget] = React.useState("ast-01")
  const isLive = DATA_MODE === "live"
  const ready = isLive && !!s && live.link === "live"
  const { data: state } = useQuery({
    queryKey: ["demo-state"], queryFn: () => http.get<DemoState>("/api/v1/demo/state"),
    enabled: ready, refetchInterval: 5000,
  })
  const { data: devices } = useQuery({
    queryKey: ["devices"], queryFn: () => http.get<any[]>("/api/v1/devices"), enabled: ready, refetchInterval: 5000,
  })
  const canSeeDownlink = ["Flight Surgeon", "Mission Control", "Administrator"].includes(s?.user.role ?? "")
  const { data: downlink } = useQuery({
    queryKey: ["downlink"], queryFn: () => http.get<any[]>("/api/v1/downlink/queue"),
    enabled: ready && canSeeDownlink, refetchInterval: 5000,
  })
  const scenarios = state?.scenarios ?? DEMO_SCENARIOS
  const current = isLive ? state?.crew?.[target] : undefined

  async function run(id: string) {
    if (!isLive) return setDemoScenario(id)
    await http.post("/api/v1/demo/scenario", { astronaut_id: target, scenario: id })
    qc.invalidateQueries({ queryKey: ["demo-state"] })
  }
  async function reset() {
    if (!isLive) return setDemoScenario("normal")
    await http.post("/api/v1/demo/reset")
    qc.invalidateQueries()
  }

  const lastStep = (() => {
    const e = live.events[0]
    if (!e) return live.lastEventAt ? 1 : -1
    if (Date.now() - e.at > 8000) return 1
    return e.type === "escalation" ? 3 : e.type.startsWith("alert") ? 2 : 1
  })()

  const card: React.CSSProperties = { background: "var(--color-surface, #fff)", border: "1px solid var(--color-border, #ddd)", borderRadius: 16, padding: 18 }
  return (
    <main style={{ height: "100%", overflow: "auto", padding: "20px clamp(12px, 3vw, 32px) 120px", fontFamily: "Outfit, system-ui, sans-serif" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto", display: "grid", gap: 16 }}>
        <header>
          <h1 style={{ fontSize: 32, fontWeight: 600, margin: 0 }}>Presenter console</h1>
          <p style={{ margin: "6px 0 0", color: "#555", maxWidth: 780 }}>
            Prototype-only control. It changes what the <b>simulated sensors</b> report. Everything after that is the real
            system: validation, the alert engine, escalation, the audit log and the downlink queue.
            {isLive && state && state.time_scale < 1 && (
              <> Demo timing is on: alert windows longer than 60 s run {Math.round(1 / state.time_scale)}× faster (critical timings stay real).</>
            )}
          </p>
          {!isLive && <p style={{ color: "#9a5b00" }}>Demo mode: vitals change in the browser only. Start the full demo (live mode) to see alerts fire and escalate.</p>}
          {isLive && !s && <p>Sign in first: <Link href="/login" style={{ textDecoration: "underline" }}>Sign in</Link></p>}
          {isLive && s && state && !state.enabled && <p style={{ color: "#b42318" }}>The server is running without the simulator. Start it with the demo launcher.</p>}
        </header>

        <section style={card} aria-label="Data pipeline">
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}>
            {STEPS.map((st, i) => (
              <React.Fragment key={st}>
                <span style={{ padding: "8px 12px", borderRadius: 10, fontWeight: 600, fontSize: 14,
                  background: i <= lastStep ? "#006D58" : "#eef1f4", color: i <= lastStep ? "#fff" : "#555", transition: "background .3s" }}>{st}</span>
                {i < STEPS.length - 1 && <span aria-hidden>→</span>}
              </React.Fragment>
            ))}
          </div>
        </section>

        <div style={{ display: "grid", gap: 16, gridTemplateColumns: "repeat(auto-fit, minmax(340px, 1fr))" }}>
          <section style={card} aria-label="Scenarios">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
              <h2 style={{ fontSize: 20, margin: 0 }}>1. Choose what happens</h2>
              {isLive && (
                <select value={target} onChange={(e) => setTarget(e.target.value)} style={{ padding: 6, borderRadius: 8, fontSize: 14 }}>
                  {(crew ?? []).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              )}
            </div>
            <div style={{ display: "grid", gap: 8, marginTop: 12 }}>
              {scenarios.map((sc) => (
                <button key={sc.id} onClick={() => run(sc.id)} disabled={isLive && !ready}
                  style={{ textAlign: "left", padding: 12, borderRadius: 12, cursor: "pointer", font: "inherit",
                    border: current === sc.id ? "2px solid #006D58" : "1px solid #ccc", background: current === sc.id ? "#e8f4f1" : "#fff" }}>
                  <b>{sc.label}</b>{current === sc.id && " · running"}
                  <div style={{ fontSize: 13, color: "#555" }}>{sc.description}</div>
                  <div style={{ fontSize: 12.5, color: "#006D58", marginTop: 2 }}>Expect: {sc.expect}</div>
                </button>
              ))}
            </div>
            <button onClick={reset} style={{ marginTop: 12, padding: "10px 14px", borderRadius: 10, border: "1px solid #b42318", color: "#b42318", background: "#fff", font: "inherit", cursor: "pointer" }}>
              Reset demo (clear alerts and readings)
            </button>
          </section>

          <section style={card} aria-label="Crew vitals">
            <h2 style={{ fontSize: 20, margin: 0 }}>2. Watch the crew</h2>
            <table style={{ width: "100%", marginTop: 12, borderCollapse: "collapse", fontSize: 14 }}>
              <thead><tr style={{ textAlign: "left", color: "#555" }}><th>Crew</th><th>HR</th><th>SpO₂</th><th>Temp</th><th>CO₂</th></tr></thead>
              <tbody>
                {(crew ?? []).map((c) => {
                  const v = live.values[c.id] ?? {}
                  const cell = (k: string, d = 0) => {
                    const st = valueStatus(v[k])
                    return st === "LIVE" ? v[k].value.toFixed(d) : <span style={{ color: "#b54708", fontSize: 12 }}>{st.replace("_", " ").toLowerCase()}</span>
                  }
                  return (
                    <tr key={c.id} style={{ borderTop: "1px solid #eee" }}>
                      <td style={{ padding: "8px 0" }}>{c.name}</td><td>{cell("heart_rate")}</td><td>{cell("spo2", 1)}</td>
                      <td>{cell("core_temp", 1)}</td><td>{cell("cabin_co2", 1)}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
            <p style={{ fontSize: 13, color: "#555" }}>Open <Link href="/" style={{ textDecoration: "underline" }}>the crew app</Link> and <Link href="/alerts" style={{ textDecoration: "underline" }}>Alerts</Link> in a second window to show the astronaut's view.</p>
          </section>

          <section style={card} aria-label="System events">
            <h2 style={{ fontSize: 20, margin: 0 }}>3. What the system did</h2>
            <ol style={{ listStyle: "none", padding: 0, margin: "12px 0 0", display: "grid", gap: 6, maxHeight: 360, overflow: "auto" }}>
              {live.events.length === 0 && <li style={{ color: "#777" }}>No events yet. Pick a scenario.</li>}
              {live.events.map((e, i) => (
                <li key={i} style={{ fontSize: 13.5, borderLeft: `3px solid ${e.level === "critical" ? "#b42318" : e.level === "warning" ? "#b54708" : "#006D58"}`, paddingLeft: 8 }}>
                  <span style={{ color: "#777" }}>{new Date(e.at).toLocaleTimeString()} </span>
                  <b>{EVENT_TEXT[e.type] ?? e.type}</b>
                  {e.title && <> · {e.title}</>}
                  {e.audience && <> → {e.audience.replace("_", " ")}</>}
                  {e.scenario && <> · {e.scenario}</>}
                  {e.astronautId && <span style={{ color: "#777" }}> ({crew?.find((c) => c.id === e.astronautId)?.name ?? e.astronautId})</span>}
                </li>
              ))}
            </ol>
          </section>

          {isLive && (
            <section style={card} aria-label="Devices and downlink">
              <h2 style={{ fontSize: 20, margin: 0 }}>4. Devices and ground link</h2>
              <ul style={{ paddingLeft: 18, fontSize: 14 }}>
                {(devices ?? []).map((d) => (
                  <li key={d.id}>{d.name}: <b>{d.link}</b>{d.is_simulated ? " (simulated)" : ""}</li>
                ))}
              </ul>
              {canSeeDownlink ? (
                <>
                  <div style={{ fontWeight: 600, marginTop: 8 }}>Downlink queue to ground ({downlink?.length ?? 0})</div>
                  <ol style={{ fontSize: 13, paddingLeft: 18, maxHeight: 180, overflow: "auto" }}>
                    {(downlink ?? []).slice(-12).map((p) => (
                      <li key={p.id}>#{p.seq} {p.priority} → {p.destination.replaceAll("_", " ").toLowerCase()} ({p.payload.type})</li>
                    ))}
                  </ol>
                </>
              ) : <p style={{ fontSize: 13, color: "#555" }}>Sign in as the flight surgeon or mission control to see the ground downlink queue.</p>}
            </section>
          )}
        </div>
      </div>
    </main>
  )
}
