import type { Metadata, Viewport } from "next"
import "@fontsource/outfit/300.css"
import "@fontsource/outfit/400.css"
import "@fontsource/outfit/500.css"
import "@fontsource/outfit/600.css"
import "./globals.css"
import { Providers } from "./providers"
import { NextAppFrame } from "@/components/NextAppFrame"
import { DataModeBadge } from "@/components/DataModeBadge"
import { LiveSync } from "@/components/LiveSync"
import { CrewEmergencyBanner } from "@/components/CrewEmergencyBanner"

export const metadata: Metadata = {
  title: "CAELUM — Astronaut Health Intelligence",
  description: "Advisory crew health monitoring for long-duration missions. Research software, not approved for clinical use.",
  icons: {
    icon: "/favicon.ico",
  },
}

export const viewport: Viewport = {
  themeColor: "#006D58",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="font-sans bg-surface text-ink antialiased overflow-hidden">
        <Providers>
          <NextAppFrame>{children}</NextAppFrame>
          <DataModeBadge />
          <CrewEmergencyBanner />
          <LiveSync />
        </Providers>
      </body>
    </html>
  )
}
