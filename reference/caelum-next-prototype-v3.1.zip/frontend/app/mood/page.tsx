"use client"

import Mood from "@/modules/mood"

export default function MoodPage() {
  return <Mood />
}
