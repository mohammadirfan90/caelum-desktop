"use client"

import Environment from "@/modules/environment"

export default function EnvPage() {
  return <Environment />
}
