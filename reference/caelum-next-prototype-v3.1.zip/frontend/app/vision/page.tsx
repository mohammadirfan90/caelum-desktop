"use client"

import Vision from "@/modules/vision"

export default function VisionPage() {
  return <Vision />
}
