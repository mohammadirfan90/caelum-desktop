"use client"

import Twin from "@/modules/twin"

export default function TwinPage() {
  return <Twin />
}
