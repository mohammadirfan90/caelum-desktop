"use client"

import More from "@/screens/More"

export default function MorePage() {
  return <More />
}
