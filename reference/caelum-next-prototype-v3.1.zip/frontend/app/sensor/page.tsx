"use client"

import Sensor from "@/modules/sensor"

export default function SensorPage() {
  return <Sensor />
}
