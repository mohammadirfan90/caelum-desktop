"use client"

import Bone from "@/modules/bone"

export default function BonePage() {
  return <Bone />
}
