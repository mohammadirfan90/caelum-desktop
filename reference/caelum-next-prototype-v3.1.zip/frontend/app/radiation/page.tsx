"use client"

import Radiation from "@/modules/radiation"

export default function RadiationPage() {
  return <Radiation />
}
