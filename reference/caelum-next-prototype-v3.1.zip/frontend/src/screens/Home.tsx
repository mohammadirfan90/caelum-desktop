import * as React from "react"
import { Link } from "@/components/Link"
import {
  History,
  Radiation,
  Wind,
  CalendarClock,
  ShieldCheck,
} from "lucide-react"
import {
  IconBtn,
  SectionHead,
  AdviceFooter,
} from "../components/ui"
import { MissionTimeline } from "../components/MissionTimeline"
import { GatherEvaluateAct } from "../components/GatherEvaluateAct"
import { DotNum } from "../components/DotNum"
import { NoData } from "../components/NoData"
import { useVitals } from "../api/vitals"
import { HeartRateBars } from "../components/HeartRateBars"
import { AlertBadge, LevelDot, levelLabel } from "../components/Level"
import { AlertCard } from "../components/WhyDrawer"
import { EmptyChart, SkeletonChart, SkeletonCard } from "../components/EmptyState"
import { useAstronaut, useEvaluation, useAlerts, useNextCheck, useCareerDose, useLatestEnvironment, useConnection } from "../api/hooks"
import { useApp } from "../store/useApp"

const CAREER_LIMIT = 600

// ── Trend arrow ─────────────────────────────────────────────────────────────
function Trend({ value, prev, unit = "" }: { value: number; prev: number; unit?: string }) {
  const diff = value - prev
  if (Math.abs(diff) < 0.5) return <span className="text-[12px] text-ink-3">→ stable</span>
  const up = diff > 0
  return (
    <span className={`inline-flex items-center gap-0.5 text-[12px] font-medium ${up ? "text-signal" : "text-warning"}`}>
      {up ? "↑" : "↓"} {Math.abs(diff).toFixed(1)}{unit}
    </span>
  )
}

// ── Monthly summary cards ────────────────────────────────────────────────────
const MONTH_DATA = [
  { month: "May", hr: 58, hrv: 54, spo2: 98.1, stress: 24, rad: 0.47, mood: 72 },
  { month: "Jun", hr: 60, hrv: 51, spo2: 97.9, stress: 28, rad: 0.49, mood: 70 },
  { month: "Jul", hr: 57, hrv: 53, spo2: 98.0, stress: 22, rad: 0.50, mood: 74 },
  { month: "Aug", hr: 59, hrv: 49, spo2: 97.8, stress: 29, rad: 0.51, mood: 68 },
  { month: "Sep", hr: 58, hrv: 52, spo2: 98.2, stress: 23, rad: 0.52, mood: 75 },
  { month: "Oct", hr: 57, hrv: 50, spo2: 98.0, stress: 26, rad: 0.53, mood: 71 },
]

function MonthCard({ d }: { d: typeof MONTH_DATA[0] }) {
  const barPct = Math.min(100, (d.stress / 60) * 100)
  return (
    <div className="card flex flex-col gap-3 p-4">
      <span className="label font-semibold text-ink">{d.month}</span>
      <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 text-[12.5px]">
        <div className="flex flex-col">
          <span className="text-ink-3">Avg HR</span>
          <span className="font-semibold tabular-nums">{d.hr} <span className="font-normal text-ink-3">bpm</span></span>
        </div>
        <div className="flex flex-col">
          <span className="text-ink-3">HRV</span>
          <span className="font-semibold tabular-nums">{d.hrv} <span className="font-normal text-ink-3">ms</span></span>
        </div>
        <div className="flex flex-col">
          <span className="text-ink-3">SpO2</span>
          <span className="font-semibold tabular-nums">{d.spo2}<span className="font-normal text-ink-3">%</span></span>
        </div>
        <div className="flex flex-col">
          <span className="text-ink-3">Mood</span>
          <span className="font-semibold tabular-nums">{d.mood}</span>
        </div>
        <div className="col-span-2 flex flex-col">
          <div className="flex justify-between">
            <span className="text-ink-3">Stress index</span>
            <span className="font-semibold tabular-nums">{d.stress}</span>
          </div>
          <span className="mt-1 h-1 overflow-hidden rounded-full bg-border">
            <span className="block h-full rounded-full bg-ink" style={{ width: `${barPct}%` }} />
          </span>
        </div>
        <div className="col-span-2 flex flex-col">
          <span className="text-ink-3">Radiation dose</span>
          <span className="font-semibold tabular-nums">{d.rad} <span className="font-normal text-ink-3">mSv/day</span></span>
        </div>
      </div>
    </div>
  )
}

// ── Main component ───────────────────────────────────────────────────────────
export default function Home() {
  const day = useApp((s) => s.day)
  const { data: _astronaut } = useAstronaut()
  const { data: ev, isLoading: evalLoading } = useEvaluation(day)
  const { data: alertsData } = useAlerts()
  const { data: nextCheck } = useNextCheck()
  const { data: careerDose } = useCareerDose()
  const { data: _envReading } = useLatestEnvironment()
  const { state: _commsState, queue: _queue } = useConnection()

  // ── live vitals (real telemetry, or labelled demo stream) ───────────────
  const vt = useVitals()
  const liveHR = vt.hr.value
  const prevHR = vt.hrHistory.length > 1 ? vt.hrHistory[vt.hrHistory.length - 2] : null
  const liveCO2 = vt.co2.value
  const liveRad = careerDose?.total ?? 0

  const alerts = alertsData ?? []
  const baselineHR = ev?.nowS?.expectedHr ?? 61
  const delta = liveHR === null ? 0 : liveHR - baselineHR
  const inDays = nextCheck ? nextCheck.due - (ev?.day ?? 0) : 0

  if (evalLoading) {
    return (
      <div className="grid items-start gap-5 pb-4 lg:grid-cols-12">
        <SkeletonChart />
        <div className="col-span-full lg:col-span-7"><SkeletonCard /></div>
        <SkeletonCard />
        <div className="grid grid-cols-2 gap-3 lg:col-span-6 lg:grid-cols-4">
          <SkeletonCard /><SkeletonCard /><SkeletonCard /><SkeletonCard />
        </div>
        <SkeletonCard />
      </div>
    )
  }

  return (
    <div className="grid items-start gap-5 pb-4 lg:grid-cols-12">
      <MissionTimeline />

      <div className="col-span-full">
        <GatherEvaluateAct />
      </div>

      {/* ── Balanced Telemetry Row: Live Heart Rate (Left) + 4 Mini Stat Cards (Right) ── */}
      <div className="col-span-full grid grid-cols-1 lg:grid-cols-12 gap-3.5 sm:gap-4 items-stretch">
        {/* Left Side: Live Heart Rate Card */}
        <section className="card p-5 lg:col-span-6 flex flex-col justify-between h-full" aria-label="Heart rate monitor">
          <div>
            <div className="flex items-center justify-between pb-1">
              <div className="flex items-center gap-2">
                <span className="live-pulse size-2 rounded-full bg-signal" aria-hidden />
                <span className="label font-medium text-ink-2">Heart rate · Live Telemetry</span>
              </div>
              <div className="flex items-center gap-2.5">
                <div className="hidden sm:flex items-center gap-3 text-[12px] text-label pr-1">
                  <span>Resting: <strong className="font-semibold text-ink">58–72</strong></span>
                  <span className="text-border">|</span>
                  <span>HRV: <strong className="font-semibold text-ink">54 ms</strong></span>
                </div>
                <IconBtn icon={History} label="Heart history" to="/body" size={38} />
              </div>
            </div>

            <div className="mt-2 flex flex-wrap items-baseline gap-x-4 gap-y-1">
              {liveHR === null ? <NoData status={vt.hr.status} size={68} /> : <DotNum value={Math.round(liveHR)} unit="bpm" size={68} />}
              <div className="flex items-center gap-2.5 text-[13px] text-label">
                <span className="rounded-full bg-signal-soft px-2.5 py-0.5 font-medium text-signal">
                  {Math.abs(delta) < 1
                    ? "On baseline"
                    : `${delta > 0 ? "+" : ""}${delta.toFixed(0)} bpm vs baseline`}
                </span>
                {liveHR !== null && prevHR !== null && <Trend value={liveHR} prev={prevHR} unit=" bpm" />}
                <span className="hidden md:inline text-[12px] text-ink-3">· Sinus Rhythm</span>
              </div>
            </div>

            {/* Clean Horizontal Range Bar */}
            <div className="mt-4 w-full">
              {liveHR !== null && <HeartRateBars bpm={liveHR} baseline={baselineHR} restingMin={58} restingMax={72} />}
            </div>

            {/* Physiological Micro-telemetry Breakdown */}
            <div className="mt-4 grid grid-cols-3 gap-2.5 rounded-lg border border-border/60 bg-surface/50 p-2.5">
              <div>
                <span className="text-[10px] uppercase tracking-wider text-label block font-mono">HRV (rMSSD)</span>
                <span className="text-[14px] font-semibold text-ink tabular-nums">54 <span className="text-[11px] font-normal text-label">ms</span></span>
                <span className="text-[10px] text-signal block">Nominal balance</span>
              </div>
              <div className="border-l border-border/50 pl-2.5">
                <span className="text-[10px] uppercase tracking-wider text-label block font-mono">R-R Cadence</span>
                <span className="text-[14px] font-semibold text-ink tabular-nums">{liveHR ? Math.round(60000 / liveHR) : "—"} <span className="text-[11px] font-normal text-label">ms</span></span>
                <span className="text-[10px] text-ink-3 block">Sinus intervals</span>
              </div>
              <div className="border-l border-border/50 pl-2.5">
                <span className="text-[10px] uppercase tracking-wider text-label block font-mono">SpO₂ Oxygen</span>
                <span className="text-[14px] font-semibold text-ink tabular-nums">98.2 <span className="text-[11px] font-normal text-label">%</span></span>
                <span className="text-[10px] text-signal block">Optimal perfusion</span>
              </div>
            </div>
          </div>

          {/* Action Footer */}
          <div className="mt-4 pt-3 border-t border-border/60 flex items-center justify-between text-[11.5px]">
            <span className="text-label flex items-center gap-1.5">
              <span className="size-1.5 rounded-full bg-signal" />
              Continuous biometric stream active
            </span>
            <Link to="/heart" className="font-medium text-signal hover:translate-x-0.5 transition-transform inline-flex items-center gap-1">
              <span>Cardiovascular diagnostics</span>
              <span aria-hidden>→</span>
            </Link>
          </div>
        </section>

        {/* ── 4 Mini Stat Cards (2x2 Grid) ── */}
        <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-3.5 h-full">
        {/* Card 1: Overall Status */}
        <Link to="/alerts" className="card group flex flex-col justify-between p-4.5 hover:border-border-strong transition-all shadow-xs">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="label flex items-center gap-1.5 font-medium">
                <ShieldCheck size={14} strokeWidth={1.8} aria-hidden />
                Overall status
              </span>
              <AlertBadge level={ev?.overall ?? "normal"} />
            </div>
            <div className="mt-1">
              <div className="text-[17px] font-semibold text-ink tracking-[-0.01em]">
                {ev?.overall === "normal" ? "All Systems Nominal" : "Clinical Observation"}
              </div>
              <p className="text-[12px] text-label mt-0.5">
                {ev?.overall === "normal"
                  ? "Telemetry tracks within expected baseline"
                  : `${alerts.length} active advisories flagged`}
              </p>
            </div>
          </div>
          <div className="mt-3 pt-2.5 border-t border-border/60 flex items-center justify-between text-[11.5px] font-medium text-signal group-hover:translate-x-0.5 transition-transform">
            <span>Review triage protocol</span>
            <span aria-hidden>→</span>
          </div>
        </Link>

        {/* Card 2: Radiation */}
        <Link to="/radiation" className="card group flex flex-col justify-between p-4.5 hover:border-border-strong transition-all shadow-xs">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="label flex items-center gap-1.5 font-medium">
                <Radiation size={14} strokeWidth={1.8} aria-hidden />
                Radiation
              </span>
              <span className="text-[11px] font-medium text-signal bg-signal-soft px-2 py-0.5 rounded-full">
                0.47 mSv/d
              </span>
            </div>
            <div className="mt-1 flex items-baseline gap-1.5">
              <span className="text-[26px] font-semibold tabular-nums leading-none tracking-[-0.02em] text-ink">
                {Math.round(liveRad)}
              </span>
              <span className="text-[13px] font-medium text-label">
                / {CAREER_LIMIT} mSv
              </span>
            </div>
          </div>

          <div className="mt-3">
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-border/70" role="progressbar"
              aria-label="Career dose" aria-valuenow={Math.round((liveRad / CAREER_LIMIT) * 100)}>
              <div className="h-full rounded-full bg-signal transition-all duration-700"
                style={{ width: `${Math.min(100, (liveRad / CAREER_LIMIT) * 100)}%` }} />
            </div>
            <div className="mt-1.5 flex justify-between text-[11px] text-label">
              <span>{((liveRad / CAREER_LIMIT) * 100).toFixed(1)}% of career cap</span>
              <span className="font-medium text-ink-3">{CAREER_LIMIT - Math.round(liveRad)} mSv margin</span>
            </div>
          </div>
        </Link>

        {/* Card 3: Cabin CO2 */}
        <Link to="/env" className="card group flex flex-col justify-between p-4.5 hover:border-border-strong transition-all shadow-xs">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="label flex items-center gap-1.5 font-medium">
                <Wind size={14} strokeWidth={1.8} aria-hidden />
                Cabin CO2
              </span>
              <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${
                liveCO2 !== null && liveCO2 > 4.0 ? "text-warning bg-warning/15" : "text-signal bg-signal-soft"
              }`}>
                {liveCO2 === null ? "No data" : liveCO2 > 4.0 ? "Elevated" : "Nominal"}
              </span>
            </div>
            <div className="mt-1">
              {liveCO2 === null ? <NoData status={vt.co2.status} /> : <DotNum value={Math.round(liveCO2 * 10) / 10} unit="mmHg" size={28} />}
            </div>
          </div>
          <div className="mt-2.5 pt-2 border-t border-border/60 flex items-center justify-between text-[11.5px] text-label">
            <span>Threshold: 5,000 ppm</span>
            <span className="font-medium text-ink-3">Scrubber Bus Active</span>
          </div>
        </Link>

        {/* Card 4: Next Check */}
        <Link to="/checks" className="card group flex flex-col justify-between p-4.5 hover:border-border-strong transition-all shadow-xs">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="label flex items-center gap-1.5 font-medium">
                <CalendarClock size={14} strokeWidth={1.8} aria-hidden />
                Next protocol
              </span>
              <span className="text-[10.5px] font-medium text-label bg-canvas px-2 py-0.5 rounded-full border border-border/70 uppercase">
                {nextCheck ? nextCheck.type : "CHECK"}
              </span>
            </div>
            <div className="mt-1">
              <span className="text-[17px] font-semibold capitalize leading-tight tracking-[-0.01em] block text-ink">
                {nextCheck ? (nextCheck.type === "vision" ? "Vision & SANS Acuity" : `${nextCheck.type} Examination`) : "All Clear"}
              </span>
              <span className="text-[12px] text-label block mt-0.5 truncate">
                {nextCheck ? "Ultrasound & optical assessment" : "Routine timeline complete"}
              </span>
            </div>
          </div>
          <div className="mt-2.5 pt-2 border-t border-border/60 flex items-center justify-between text-[11.5px]">
            <span className="font-medium text-signal">
              {nextCheck ? (inDays <= 0 ? "Due today" : `In ${inDays} day${inDays > 1 ? "s" : ""}`) : "All clear"}
            </span>
            <span className="text-label/60 group-hover:text-ink transition-colors">Open checklist →</span>
          </div>
        </Link>
        </div>
      </div>

      {/* ── Monthly Health Summary ── */}
      <div className="col-span-full">
        <SectionHead>Monthly Health Summary</SectionHead>
        <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {MONTH_DATA.map((d) => <MonthCard key={d.month} d={d} />)}
        </div>
      </div>

      {/* ── Alerts section ── */}
      <div className="col-span-full grid gap-4 lg:grid-cols-2">
        <div className="col-span-full">
          <SectionHead
            right={
              <Link to="/alerts" className="min-h-11 px-2 pt-2 text-[14px] font-semibold text-label">
                All alerts
              </Link>
            }
          >
            Alerts
          </SectionHead>
        </div>
        {alerts.length === 0 ? (
          <div className="card flex items-center gap-3 p-5">
            <ShieldCheck size={22} strokeWidth={1.5} />
            <p className="text-[15px] leading-snug">
              No alerts. All signals are inside your own baseline. Status: {levelLabel("normal")}.
            </p>
          </div>
        ) : (
          alerts.map((a: any) => <AlertCard key={a.id} alert={a} />)
        )}
      </div>

      <AdviceFooter />
    </div>
  )
}
