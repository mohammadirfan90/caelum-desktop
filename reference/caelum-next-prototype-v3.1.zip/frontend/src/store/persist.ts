import { openDB } from "idb"

const isBrowser = typeof window !== "undefined" && typeof indexedDB !== "undefined"

const db = () => {
  if (!isBrowser) return Promise.resolve(null)
  return openDB("caelum", 1, {
    upgrade(d) {
      d.createObjectStore("kv")
    },
  })
}

export async function idbGet<T>(key: string): Promise<T | undefined> {
  if (!isBrowser) return undefined
  try {
    const database = await db()
    return database ? ((await database.get("kv", key)) as T) : undefined
  } catch {
    return undefined
  }
}

export async function idbSet(key: string, val: unknown) {
  if (!isBrowser) return
  try {
    const database = await db()
    if (database) {
      await database.put("kv", JSON.parse(JSON.stringify(val)), key)
    }
  } catch {
    /* storage unavailable */
  }
}

export async function idbCount() {
  if (!isBrowser) return 0
  try {
    const database = await db()
    return database ? await database.count("kv") : 0
  } catch {
    return 0
  }
}

export async function idbClear() {
  if (!isBrowser) return
  try {
    const database = await db()
    if (database) {
      await database.clear("kv")
    }
  } catch {
    /* noop */
  }
}
