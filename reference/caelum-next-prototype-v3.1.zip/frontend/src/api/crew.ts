"use client"
import { useQuery } from "@tanstack/react-query"
import { DATA_MODE } from "./config"
import { http } from "./http"

export interface CrewMember {
  id: string
  name: string
  initials: string
  role: string
  mission: string
  crew: string
}

const DEMO_CREW: CrewMember[] = [
  { id: "ast-01", name: "Cdr. Ines Varga", initials: "IV", role: "Commander", mission: "Expedition 74 (demo)", crew: "Crew-1" },
  { id: "ast-02", name: "Dr. Alexei Chen", initials: "AC", role: "Crew Medical Officer", mission: "Expedition 74 (demo)", crew: "Crew-1" },
  { id: "ast-03", name: "Lt. Maya Lin", initials: "ML", role: "Flight Engineer", mission: "Expedition 74 (demo)", crew: "Crew-1" },
]

export function useCrew() {
  return useQuery({
    queryKey: ["crew", DATA_MODE],
    queryFn: () => (DATA_MODE === "live" ? http.get<CrewMember[]>("/api/v1/crew") : Promise.resolve(DEMO_CREW)),
    staleTime: 5 * 60_000,
  })
}

export function useCrewMember(id: string): CrewMember {
  const { data } = useCrew()
  return data?.find((c) => c.id === id) ?? { id, name: id, initials: id.slice(-2), role: "", mission: "", crew: "" }
}
