/**
 * Data mode is explicit and visible:
 *  - "demo": every reading comes from the built-in demo data set and the UI says so.
 *  - "live": every reading comes from the backend. If the backend is unreachable the UI shows
 *    UNAVAILABLE. It never silently falls back to demo data.
 */
export type DataMode = "demo" | "live"
export const DATA_MODE: DataMode = process.env.NEXT_PUBLIC_DATA_MODE === "live" ? "live" : "demo"
export const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? ""
export const WS_URL = process.env.NEXT_PUBLIC_WS_URL ?? "ws://127.0.0.1:8000/ws/telemetry"
export const STALE_AFTER_MS = 30_000
export const DEFAULT_ASTRONAUT_ID = process.env.NEXT_PUBLIC_ASTRONAUT_ID ?? "ast-01"
