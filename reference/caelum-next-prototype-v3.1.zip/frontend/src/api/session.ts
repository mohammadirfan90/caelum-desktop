"use client"
/** Access token kept in sessionStorage (cleared when the tab closes). */
export interface SessionUser {
  username: string
  full_name: string
  role: string
  astronaut_id: string | null
}
const KEY = "caelum.session"
type Session = { token: string; user: SessionUser } | null
const listeners = new Set<() => void>()
let cached: Session | undefined

function read(): Session {
  if (cached !== undefined) return cached
  if (typeof window === "undefined") return null
  try {
    cached = JSON.parse(window.sessionStorage.getItem(KEY) ?? "null")
  } catch {
    cached = null
  }
  return cached ?? null
}

export const session = {
  get: read,
  token: () => read()?.token ?? null,
  set(s: Session) {
    cached = s
    try {
      if (s) window.sessionStorage.setItem(KEY, JSON.stringify(s))
      else window.sessionStorage.removeItem(KEY)
    } catch {}
    listeners.forEach((l) => l())
  },
  clear() {
    session.set(null)
  },
  subscribe(l: () => void) {
    listeners.add(l)
    return () => listeners.delete(l)
  },
}
