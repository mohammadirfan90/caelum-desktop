import { API_BASE } from "./config"
import { session, type SessionUser } from "./session"

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message)
    this.name = "ApiError"
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = session.token()
  const headers = new Headers(init.headers)
  if (!headers.has("Content-Type") && init.body && typeof init.body === "string") {
    headers.set("Content-Type", "application/json")
  }
  if (token) headers.set("Authorization", `Bearer ${token}`)
  let res: Response
  try {
    res = await fetch(`${API_BASE}${path}`, { ...init, headers })
  } catch {
    throw new ApiError(0, "Backend unreachable")
  }
  if (res.status === 401) {
    session.clear()
    throw new ApiError(401, "Session expired: sign in again")
  }
  if (!res.ok) {
    const text = await res.text().catch(() => "")
    throw new ApiError(res.status, text || res.statusText)
  }
  return (res.status === 204 ? undefined : await res.json()) as T
}

function withParams(path: string, params?: Record<string, unknown>) {
  if (!params) return path
  const q = new URLSearchParams()
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null) q.set(k, String(v))
  const s = q.toString()
  return s ? `${path}?${s}` : path
}

export const http = {
  get: <T>(path: string, options?: { params?: Record<string, unknown> }) => request<T>(withParams(path, options?.params)),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "POST", body: body !== undefined ? JSON.stringify(body) : undefined }),
  patch: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "PATCH", body: body !== undefined ? JSON.stringify(body) : undefined }),
  delete: <T>(path: string) => request<T>(path, { method: "DELETE" }),
}

export async function login(username: string, password: string) {
  const body = new URLSearchParams({ username, password })
  const r = await request<{ access_token: string; user: SessionUser }>("/api/v1/auth/login", {
    method: "POST",
    body,
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
  })
  session.set({ token: r.access_token, user: r.user })
  return r.user
}
