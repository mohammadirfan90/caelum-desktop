"use client"
import { useEffect, useState } from "react"
import { useLiveTelemetry, valueStatus, type ValueStatus } from "./live"

export interface Vital {
  value: number | null
  status: ValueStatus
  simulated: boolean
}

function useNow(ms = 1000) {
  const [now, setNow] = useState(() => Date.now())
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), ms)
    return () => clearInterval(id)
  }, [ms])
  return now
}

/** Current vitals of the selected astronaut. Values are null unless LIVE: never invented. */
export function useVitals() {
  const live = useLiveTelemetry()
  const now = useNow()
  const vals = live.values[live.selected] ?? {}
  const get = (k: string): Vital => {
    const v = vals[k]
    const status = valueStatus(v, now)
    return { value: status === "LIVE" ? v!.value : null, status, simulated: v?.simulated ?? false }
  }
  return {
    astronautId: live.selected,
    link: live.link,
    hr: get("heart_rate"),
    spo2: get("spo2"),
    temp: get("core_temp"),
    rr: get("respiration_rate"),
    hrv: get("hrv_rmssd"),
    co2: get("cabin_co2"), // mmHg
    hrHistory: live.history[live.selected]?.heart_rate ?? [],
  }
}

/** Format a vital: number with fixed digits, or a dash. */
export function fmt(v: Vital, digits = 0) {
  return v.value === null ? "—" : v.value.toFixed(digits)
}

export const STATUS_TEXT: Record<ValueStatus, string> = {
  LIVE: "live",
  STALE: "stale",
  NO_DATA: "no data",
  UNUSABLE: "signal unusable",
}
