"use client"
/**
 * Live telemetry store: one shared WebSocket (live mode) or a labelled in-browser demo stream
 * (demo mode). Keeps the latest value and a short history per astronaut and parameter, plus a
 * log of system events (alerts, escalations, acknowledgements) for the presenter view.
 */
import { useSyncExternalStore } from "react"
import { DATA_MODE, DEFAULT_ASTRONAUT_ID, STALE_AFTER_MS, WS_URL } from "./config"
import { session } from "./session"

export type LinkState = "demo" | "signed-out" | "connecting" | "live" | "offline"
export interface LiveValue {
  value: number
  unit: string
  measuredAt: string
  quality: string
  simulated: boolean
  deviceId: string
  receivedAt: number
}
export interface SystemEvent {
  at: number
  type: string
  astronautId?: string
  level?: string
  title?: string
  audience?: string
  status?: string
  scenario?: string
}
interface Snapshot {
  link: LinkState
  values: Record<string, Record<string, LiveValue>>
  history: Record<string, Record<string, number[]>>
  events: SystemEvent[]
  lastEventAt: number | null
  alertsVersion: number
  selected: string
}

const HISTORY = 120
let snap: Snapshot = {
  link: DATA_MODE === "demo" ? "demo" : "signed-out",
  values: {}, history: {}, events: [], lastEventAt: null, alertsVersion: 0,
  selected: DEFAULT_ASTRONAUT_ID,
}
const listeners = new Set<() => void>()
let ws: WebSocket | null = null
let retry = 0
let timer: ReturnType<typeof setTimeout> | null = null
let demoTimer: ReturnType<typeof setInterval> | null = null

function emit(next: Partial<Snapshot>) {
  snap = { ...snap, ...next }
  listeners.forEach((l) => l())
}

function addObservation(astro: string, param: string, v: LiveValue) {
  const vals = { ...(snap.values[astro] ?? {}), [param]: v }
  const h = snap.history[astro]?.[param] ?? []
  const hist = { ...(snap.history[astro] ?? {}), [param]: [...h.slice(-(HISTORY - 1)), v.value] }
  return { values: { ...snap.values, [astro]: vals }, history: { ...snap.history, [astro]: hist } }
}

function pushEvent(e: SystemEvent) {
  return [e, ...snap.events].slice(0, 60)
}

// ── live mode ────────────────────────────────────────────────────────────────
function connect() {
  if (DATA_MODE !== "live" || typeof window === "undefined" || ws) return
  const token = session.token()
  if (!token) return emit({ link: "signed-out" })
  const me = session.get()?.user
  if (me?.astronaut_id) snap = { ...snap, selected: me.astronaut_id }
  emit({ link: "connecting" })
  ws = new WebSocket(`${WS_URL}?token=${encodeURIComponent(token)}`)
  ws.onopen = () => {
    retry = 0
    emit({ link: "live" })
  }
  ws.onmessage = (m) => {
    let ev: any
    try {
      ev = JSON.parse(m.data)
    } catch {
      return
    }
    const now = Date.now()
    if (ev.type === "observation") {
      emit({
        lastEventAt: now,
        ...addObservation(ev.astronaut_id, ev.parameter, {
          value: ev.value, unit: ev.unit, measuredAt: ev.measured_at, quality: ev.quality,
          simulated: !!ev.simulated, deviceId: ev.device_id, receivedAt: now,
        }),
      })
    } else if (["alert", "escalation", "acknowledgement", "demo"].includes(ev.type)) {
      emit({
        lastEventAt: now,
        alertsVersion: snap.alertsVersion + 1,
        events: pushEvent({
          at: now, type: ev.type === "alert" && ev.status !== "ACTIVE" ? `alert-${String(ev.status).toLowerCase()}` : ev.type,
          astronautId: ev.astronaut_id, level: ev.level, title: ev.title, audience: ev.audience,
          status: ev.status, scenario: ev.scenario,
        }),
      })
    } else {
      emit({ lastEventAt: now })
    }
  }
  ws.onclose = () => {
    ws = null
    emit({ link: session.token() ? "offline" : "signed-out" })
    if (!session.token() || listeners.size === 0) return
    timer = setTimeout(connect, Math.min(30_000, 1000 * 2 ** retry++))
  }
}

// ── demo mode: labelled in-browser stream (no backend) ───────────────────────
let demoScenario = "normal"
let demoT = 0
export function setDemoScenario(s: string) {
  demoScenario = s
  demoT = 0
  emit({ events: pushEvent({ at: Date.now(), type: "demo", scenario: s, astronautId: snap.selected }) })
}
function demoTick() {
  demoT++
  const g = () => (Math.random() + Math.random() + Math.random() - 1.5) * 0.8
  const on = demoT - 10
  let hr = 62 + 3 * Math.sin(demoT / 40) + g()
  let spo2 = 97.4 + g() * 0.3
  let temp = 36.8 + g() * 0.03
  let co2 = 2.6 + g() * 0.04
  if (on > 0) {
    if (demoScenario === "hypoxia") { spo2 = Math.max(79, 97.4 - on * 0.5); hr += Math.min(28, on * 0.6) }
    if (demoScenario === "tachycardia") hr = 185 + g()
    if (demoScenario === "bradycardia") hr = 36 + g()
    if (demoScenario === "fever") temp = Math.min(39.8, 36.8 + on * 0.05)
    if (demoScenario === "co2") co2 = Math.min(6, 2.6 + on * 0.1)
  }
  const now = Date.now()
  const rows: [string, number, string][] = [
    ["heart_rate", hr, "bpm"], ["spo2", Math.min(100, spo2), "%"], ["core_temp", temp, "°C"],
    ["respiration_rate", 14 + g() * 0.6, "/min"], ["hrv_rmssd", 48 + g() * 4, "ms"], ["cabin_co2", co2, "mmHg"],
  ]
  let next: Partial<Snapshot> = {}
  for (const [p, v, u] of rows) {
    snap = { ...snap, ...next }
    next = addObservation(snap.selected, p, {
      value: Math.round(v * 100) / 100, unit: u, measuredAt: new Date(now).toISOString(),
      quality: demoScenario === "sensor_fault" && on > 0 && (p === "heart_rate" || p === "spo2") ? "UNUSABLE" : "GOOD",
      simulated: true, deviceId: "demo-browser", receivedAt: now,
    })
  }
  emit({ ...next, lastEventAt: now })
}

function subscribe(l: () => void) {
  listeners.add(l)
  if (DATA_MODE === "demo") {
    if (!demoTimer) {
      demoTick()
      demoTimer = setInterval(demoTick, 1000)
    }
  } else connect()
  const unsub = session.subscribe(() => {
    if (!session.token()) ws?.close()
    else connect()
  })
  return () => {
    listeners.delete(l)
    unsub()
    if (listeners.size === 0) {
      if (timer) clearTimeout(timer)
      if (demoTimer) clearInterval(demoTimer)
      demoTimer = null
      ws?.close()
    }
  }
}

export function selectAstronaut(id: string) {
  emit({ selected: id })
}

const getSnapshot = () => snap
export function useLiveTelemetry() {
  return useSyncExternalStore(subscribe, getSnapshot, getSnapshot)
}

export type ValueStatus = "LIVE" | "STALE" | "NO_DATA" | "UNUSABLE"
export function valueStatus(v: LiveValue | undefined, now = Date.now()): ValueStatus {
  if (!v) return "NO_DATA"
  if (v.quality === "UNUSABLE" || v.quality === "POOR") return "UNUSABLE"
  return now - v.receivedAt > STALE_AFTER_MS ? "STALE" : "LIVE"
}
