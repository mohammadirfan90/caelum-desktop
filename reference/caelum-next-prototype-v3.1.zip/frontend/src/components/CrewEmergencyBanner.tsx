"use client"
/** Crew-wide emergency: shown on every crew screen once an alert escalates to the whole crew. */
import { useQuery } from "@tanstack/react-query"
import { DATA_MODE } from "@/api/config"
import { http } from "@/api/http"
import { useLiveTelemetry } from "@/api/live"
import { Link } from "@/components/Link"

interface CrewAlert { id: string; astronaut_name: string; level: string; title: string; action: string; simulated: boolean }

export function CrewEmergencyBanner() {
  const { link } = useLiveTelemetry()
  const { data } = useQuery({
    queryKey: ["crew-alerts"],
    queryFn: () => http.get<CrewAlert[]>("/api/v1/alerts/crew"),
    enabled: DATA_MODE === "live" && link === "live",
    refetchInterval: 10_000,
  })
  if (!data?.length) return null
  const a = data[0]
  return (
    <div
      role="alert"
      style={{
        position: "fixed", top: "calc(10px + env(safe-area-inset-top, 0px))", left: "50%", transform: "translateX(-50%)",
        zIndex: 1100, maxWidth: "min(720px, calc(100vw - 24px))", display: "flex", gap: 12, alignItems: "center",
        padding: "10px 16px", borderRadius: 14, background: a.level === "critical" ? "#b42318" : "#b54708", color: "#fff",
        boxShadow: "0 8px 24px rgba(0,0,0,.25)", font: "500 14px/1.3 Outfit, system-ui, sans-serif",
      }}
    >
      <span aria-hidden style={{ fontSize: 20 }}>⬣</span>
      <span>
        <b>Crew alert: {a.astronaut_name}</b> · {a.title}{a.simulated ? " (simulated)" : ""}
        <br />
        <span style={{ opacity: 0.9 }}>{a.action}</span>
      </span>
      <Link href="/alerts" style={{ color: "#fff", textDecoration: "underline", whiteSpace: "nowrap" }}>Open</Link>
    </div>
  )
}
