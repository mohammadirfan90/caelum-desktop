import { useState, useEffect } from "react"
import { createPortal } from "react-dom"
import { motion, AnimatePresence } from "framer-motion"
import {
  X,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
} from "lucide-react"
import { useApp } from "../store/useApp"

export const TOTAL_DAYS = 183

export const MONTHS_CONFIG = [
  { name: "March", short: "Mar", year: 2026, days: 31, startDayOfWeek: 6, startMissionDay: 0 },
  { name: "April", short: "Apr", year: 2026, days: 30, startDayOfWeek: 2, startMissionDay: 31 },
  { name: "May", short: "May", year: 2026, days: 31, startDayOfWeek: 4, startMissionDay: 61 },
  { name: "June", short: "Jun", year: 2026, days: 30, startDayOfWeek: 0, startMissionDay: 92 },
  { name: "July", short: "Jul", year: 2026, days: 31, startDayOfWeek: 2, startMissionDay: 122 },
  { name: "August", short: "Aug", year: 2026, days: 31, startDayOfWeek: 5, startMissionDay: 153 },
]

export interface MilestoneDef {
  day: number
  dateStr: string
  code: string
  title: string
  category: "eva" | "cargo" | "launch" | "science" | "return" | "ops"
  summary: string
  badgeLabel: string
}

export const MISSION_MILESTONES: Record<number, MilestoneDef> = {
  0: {
    day: 0,
    dateStr: "01 Mar 2026",
    code: "Launch & Ingress",
    title: "Expedition 74 Soyuz MS-28 Docking & Ingress",
    badgeLabel: "Launch",
    category: "launch",
    summary: "Station docking at Poisk module. Hatch opening, cabin pressurization check & emergency vehicle egress briefing.",
  },
  6: {
    day: 6,
    dateStr: "07 Mar 2026",
    code: "SANS Baseline",
    title: "Acute Cephalad Fluid Shift & SANS Optical Baseline",
    badgeLabel: "SANS",
    category: "science",
    summary: "Initial microgravity cephalad venous pressure evaluation, OCT retinal tomography & optic nerve sheath diameter scan.",
  },
  20: {
    day: 20,
    dateStr: "21 Mar 2026",
    code: "Bio Samples",
    title: "Longitudinal Epigenetic & Telomere Cryo-Stowage",
    badgeLabel: "Samples",
    category: "science",
    summary: "Deep-cold collection of whole blood and saliva specimens for immune dysregulation assays. Transferred to MELFI freezer.",
  },
  41: {
    day: 41,
    dateStr: "11 Apr 2026",
    code: "EVA-1 Spacewalk",
    title: "EVA-1 Spacewalk: AMS-02 Thermal Bypass Upgrade",
    badgeLabel: "EVA-1",
    category: "eva",
    summary: "6h 34m extravehicular activity from Quest airlock. Alpha Magnetic Spectrometer coolant pump bypass & external camera installation.",
  },
  64: {
    day: 64,
    dateStr: "04 May 2026",
    code: "Progress Cargo",
    title: "Progress MS-30 Cargo Automated Docking",
    badgeLabel: "Progress",
    category: "cargo",
    summary: "Automated docking at Zvezda aft port with 2.6 tonnes of propellant, potable water, and fresh diagnostic kits.",
  },
  77: {
    day: 77,
    dateStr: "17 May 2026",
    code: "CRS-34 Dragon",
    title: "SpaceX CRS-34 Cargo Dragon Berthing",
    badgeLabel: "Dragon",
    category: "cargo",
    summary: "Autonomous rendezvous and docking at Harmony forward port. Cold-stowage life sciences hardware transferred to Columbus lab.",
  },
  91: {
    day: 91,
    dateStr: "31 May 2026",
    code: "DXA Bone Scan",
    title: "Mid-Mission DXA Bone Density & Vascular Scan",
    badgeLabel: "DXA Scan",
    category: "science",
    summary: "Comprehensive dual-energy X-ray absorptiometry scan of femoral neck and lumbar spine. Recalculation of T-score trajectory.",
  },
  104: {
    day: 104,
    dateStr: "13 Jun 2026",
    code: "Cygnus Depart",
    title: "Cygnus NG-23 Cargo Unberthing & Release",
    badgeLabel: "Cygnus",
    category: "cargo",
    summary: "Canadarm2 unberthing from Unity nadir port and release for controlled destructive atmospheric disposal.",
  },
  131: {
    day: 131,
    dateStr: "10 Jul 2026",
    code: "EVA-2 Solar Arrays",
    title: "EVA-2 Spacewalk: iROSA 1B Solar Array Rollout",
    badgeLabel: "EVA-2",
    category: "eva",
    summary: "7h 12m spacewalk installing the Port-4 integrated rollout solar array and structural modification kit on main truss.",
  },
  153: {
    day: 153,
    dateStr: "01 Aug 2026",
    code: "CO2 Transient",
    title: "Habitat Node 2 CO2 Transient & SANS Visual Shift",
    badgeLabel: "CO2 Alert",
    category: "ops",
    summary: "Active telemetry alert: Ambient Node 2 P_CO2 peaked at 4.35 mmHg. SANS high-contrast near-acuity monitoring actively logging.",
  },
  175: {
    day: 175,
    dateStr: "23 Aug 2026",
    code: "Command Handover",
    title: "Expedition 74 / 75 Formal Command Handover",
    badgeLabel: "Handover",
    category: "ops",
    summary: "Formal station command transfer to Expedition 75 crew. Crew personal equipment packing and vehicle stowage audit.",
  },
  182: {
    day: 182,
    dateStr: "30 Aug 2026",
    code: "Earth Return",
    title: "Soyuz MS-28 Undocking & Earth Touchdown",
    badgeLabel: "Return",
    category: "return",
    summary: "Undocking from Poisk module, 4-minute deorbit burn, atmospheric entry, and parachute touchdown in Kazakhstan steppe.",
  },
}

interface MissionCalendarModalProps {
  isOpen: boolean
  onClose: () => void
}

export function MissionCalendarModal({ isOpen, onClose }: MissionCalendarModalProps) {
  const currentDay = useApp((s) => s.day)
  const setDay = useApp((s) => s.setDay)

  const [mounted, setMounted] = useState(false)
  const [selectedDay, setSelectedDay] = useState(currentDay)

  useEffect(() => {
    setMounted(true)
  }, [])

  const getMonthIdx = (d: number) => {
    let acc = 0
    for (let i = 0; i < MONTHS_CONFIG.length; i++) {
      if (d >= acc && d < acc + MONTHS_CONFIG[i].days) return i
      acc += MONTHS_CONFIG[i].days
    }
    return 0
  }

  const [viewMonthIdx, setViewMonthIdx] = useState(() => getMonthIdx(currentDay))

  // Sync to currentDay when modal opens
  useEffect(() => {
    if (isOpen) {
      setSelectedDay(currentDay)
      setViewMonthIdx(getMonthIdx(currentDay))
    }
  }, [isOpen, currentDay])

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
      else if (e.key === "ArrowLeft") {
        setSelectedDay((d) => Math.max(0, d - 1))
      } else if (e.key === "ArrowRight") {
        setSelectedDay((d) => Math.min(TOTAL_DAYS - 1, d + 1))
      }
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [isOpen, onClose])

  const month = MONTHS_CONFIG[viewMonthIdx]
  const milestone = MISSION_MILESTONES[selectedDay]

  const handleSelectDay = (mDay: number) => {
    if (mDay < 0 || mDay >= TOTAL_DAYS) return
    setSelectedDay(mDay)
    const mIdx = getMonthIdx(mDay)
    if (mIdx !== viewMonthIdx) setViewMonthIdx(mIdx)
  }

  const prevMonth = () => {
    if (viewMonthIdx > 0) setViewMonthIdx((i) => i - 1)
  }
  const nextMonth = () => {
    if (viewMonthIdx < MONTHS_CONFIG.length - 1) setViewMonthIdx((i) => i + 1)
  }

  if (!mounted) return null

  return createPortal(
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-5 md:p-8 overflow-hidden">
          {/* Subtle dark backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/45 backdrop-blur-xs"
            aria-hidden="true"
          />

          {/* Modal Container */}
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label="Mission Calendar"
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 12 }}
            transition={{ type: "spring", stiffness: 380, damping: 36 }}
            className="relative z-10 flex flex-col w-full max-w-[820px] max-h-[90vh] rounded-2xl bg-surface p-5 sm:p-6 shadow-xl border border-border overflow-hidden"
          >
            {/* ── Native Clean Header ── */}
            <div className="flex items-center justify-between gap-4 pb-4 border-b border-border">
              <div className="flex items-baseline gap-3 flex-wrap">
                <h2 className="text-[22px] sm:text-[24px] font-semibold leading-tight tracking-[-0.03em] text-ink">
                  Mission Calendar
                </h2>
                <div className="flex items-center gap-2">
                  <span className="rounded-md bg-inset border border-border px-2.5 py-0.5 text-[11.5px] font-medium text-ink-2 tabular-nums">
                    Day {selectedDay + 1} of {TOTAL_DAYS}
                  </span>
                  <span className="text-[12.5px] text-ink-3 hidden sm:inline">
                    Expedition 74
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setSelectedDay(currentDay)
                    setViewMonthIdx(getMonthIdx(currentDay))
                  }}
                  className="hidden sm:inline-flex rounded-lg border border-border bg-surface hover:bg-inset px-3 py-1.5 text-[12px] font-medium text-ink transition-colors shadow-xs"
                >
                  Today (Day {currentDay + 1})
                </button>
                <button
                  onClick={onClose}
                  aria-label="Close"
                  className="flex size-9 items-center justify-center rounded-lg border border-border bg-surface hover:bg-inset text-ink transition-colors shadow-xs"
                >
                  <X size={18} strokeWidth={1.6} />
                </button>
              </div>
            </div>

            {/* ── Month Selector Ribbon ── */}
            <div className="flex items-center justify-between gap-2 py-3 border-b border-border">
              <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-hide py-0.5">
                {MONTHS_CONFIG.map((m, idx) => {
                  const isActive = idx === viewMonthIdx
                  return (
                    <button
                      key={m.short}
                      onClick={() => setViewMonthIdx(idx)}
                      className={`px-3 py-1.5 rounded-lg text-[13px] font-medium transition-all ${
                        isActive
                          ? "bg-accent text-canvas shadow-xs font-semibold"
                          : "text-ink-2 hover:bg-inset hover:text-ink"
                      }`}
                    >
                      {m.name}
                    </button>
                  )
                })}
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={prevMonth}
                  disabled={viewMonthIdx === 0}
                  aria-label="Previous month"
                  className="flex size-8 items-center justify-center rounded-lg border border-border bg-surface hover:bg-inset text-ink transition-colors shadow-xs disabled:opacity-30 disabled:pointer-events-none"
                >
                  <ChevronLeft size={16} />
                </button>
                <button
                  onClick={nextMonth}
                  disabled={viewMonthIdx === MONTHS_CONFIG.length - 1}
                  aria-label="Next month"
                  className="flex size-8 items-center justify-center rounded-lg border border-border bg-surface hover:bg-inset text-ink transition-colors shadow-xs disabled:opacity-30 disabled:pointer-events-none"
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>

            {/* ── Calendar Grid ── */}
            <div className="flex-1 min-h-0 overflow-y-auto pt-3">
              {/* Day of Week Labels */}
              <div className="grid grid-cols-7 gap-1.5 text-center text-[11px] font-semibold text-ink-3 uppercase pb-2 tracking-wider">
                <span>Mon</span>
                <span>Tue</span>
                <span>Wed</span>
                <span>Thu</span>
                <span>Fri</span>
                <span>Sat</span>
                <span>Sun</span>
              </div>

              {/* Day Matrix Cells */}
              <div className="grid grid-cols-7 gap-1.5 content-start pb-2">
                {/* Empty Offset Cells */}
                {Array.from({ length: month.startDayOfWeek }).map((_, i) => (
                  <div key={`empty-${i}`} className="h-16 sm:h-[70px] rounded-xl bg-inset/20 border border-transparent" />
                ))}

                {/* Day Cells */}
                {Array.from({ length: month.days }).map((_, i) => {
                  const calDay = i + 1
                  const missionDayIndex = month.startMissionDay + i
                  if (missionDayIndex >= TOTAL_DAYS) return null

                  const isSelected = missionDayIndex === selectedDay
                  const isToday = missionDayIndex === currentDay
                  const isPast = missionDayIndex < currentDay
                  const dayMilestone = MISSION_MILESTONES[missionDayIndex]

                  return (
                    <button
                      key={calDay}
                      onClick={() => handleSelectDay(missionDayIndex)}
                      className={`h-16 sm:h-[70px] rounded-xl p-2 flex flex-col justify-between text-left transition-all border relative active:scale-95 ${
                        isSelected
                          ? "bg-accent text-canvas border-accent shadow-xs z-10"
                          : isToday
                            ? "bg-surface border-accent ring-2 ring-accent/30 text-ink shadow-xs"
                            : isPast
                              ? "bg-surface border-border hover:border-border-strong text-ink shadow-xs"
                              : "bg-inset/40 border-border/50 hover:border-border text-ink-3 hover:text-ink"
                      }`}
                    >
                      {/* Top: Day number + Mission Day label */}
                      <div className="flex items-baseline justify-between w-full">
                        <span className={`text-[13.5px] font-semibold leading-none ${isSelected ? "text-canvas" : "text-ink"}`}>
                          {calDay}
                        </span>
                        <span
                          className={`text-[9.5px] uppercase font-mono tracking-wider tabular-nums ${
                            isSelected
                              ? "text-canvas/80"
                              : isToday
                                ? "text-accent font-bold"
                                : "text-ink-3"
                          }`}
                        >
                          D{missionDayIndex + 1}
                        </span>
                      </div>

                      {/* Middle: Milestone or Today tag */}
                      <div className="my-auto w-full overflow-hidden">
                        {isToday && !isSelected && (
                          <span className="inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 bg-accent/15 text-[9px] font-semibold text-accent">
                            <span className="size-1.5 rounded-full bg-accent live-pulse" />
                            Today
                          </span>
                        )}

                        {dayMilestone && (
                          <span
                            className={`block truncate rounded-md px-1.5 py-0.5 text-[9.5px] font-medium ${
                              isSelected
                                ? "bg-white/20 text-canvas font-semibold"
                                : "bg-inset border border-border text-ink-2 font-medium"
                            }`}
                            title={dayMilestone.title}
                          >
                            {dayMilestone.badgeLabel}
                          </span>
                        )}
                      </div>

                      {/* Bottom indicator */}
                      <div className="flex items-center gap-1 mt-auto">
                        <span
                          className={`size-1.5 rounded-full ${
                            isSelected ? "bg-canvas" : "bg-accent"
                          }`}
                        />
                      </div>
                    </button>
                  )
                })}
              </div>
            </div>

            {/* ── Clean Native Footer ── */}
            <div className="pt-3.5 mt-2 border-t border-border flex flex-wrap items-center justify-between gap-3 shrink-0">
              <div className="flex items-baseline gap-2">
                <span className="text-[13.5px] font-medium text-ink">
                  Mission Day {selectedDay + 1}
                </span>
                <span className="text-[12.5px] text-ink-3">
                  · {month.name} {selectedDay - month.startMissionDay + 1}, 2026
                </span>
                {milestone && (
                  <span className="rounded-md bg-inset border border-border px-2.5 py-0.5 text-[11.5px] text-ink-2 font-medium hidden sm:inline">
                    {milestone.title}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2.5">
                <button
                  onClick={onClose}
                  className="inline-flex items-center justify-center rounded-lg border border-border bg-surface hover:bg-inset text-[13px] font-medium text-ink h-9 px-4 transition-colors shadow-xs"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    setDay(selectedDay)
                    onClose()
                  }}
                  className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-ink text-canvas hover:opacity-90 text-[13px] font-medium h-9 px-4 transition-opacity shadow-xs"
                >
                  <span>Set Dashboard to Day {selectedDay + 1}</span>
                  <ArrowRight size={14} />
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  )
}
