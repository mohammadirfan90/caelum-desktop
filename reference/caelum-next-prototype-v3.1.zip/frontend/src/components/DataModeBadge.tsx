"use client"
import { Link } from "@/components/Link"
import { DATA_MODE } from "@/api/config"
import { useLiveTelemetry } from "@/api/live"
import { session } from "@/api/session"
import { useSession } from "./LiveSync"

const TEXT: Record<string, { label: string; tone: string }> = {
  demo: { label: "Demo data: simulated, not for clinical use", tone: "#9a5b00" },
  "signed-out": { label: "Live mode: sign in to receive data", tone: "#555" },
  connecting: { label: "Connecting to onboard server", tone: "#555" },
  live: { label: "Live", tone: "#0a7a3d" },
  offline: { label: "Onboard server unreachable: readings unavailable", tone: "#b42318" },
}

/** Always-visible statement of where the data on screen comes from. */
export function DataModeBadge() {
  const { link, values } = useLiveTelemetry()
  const s = useSession()
  const simulated = Object.values(values).some((byParam) => Object.values(byParam).some((v) => v.simulated))
  const t = TEXT[link]
  const label = link === "live" && simulated ? "Live connection: SIMULATOR data source" : t.label
  return (
    <div
      role="status"
      aria-live="polite"
      style={{
        position: "fixed", right: 12, bottom: "calc(12px + env(safe-area-inset-bottom, 0px))", zIndex: 1000,
        display: "flex", alignItems: "center", gap: 8, padding: "6px 12px", borderRadius: 999,
        background: "rgba(255,255,255,0.94)", border: `1.5px solid ${t.tone}`, color: t.tone,
        font: "500 12.5px/1.2 Outfit, system-ui, sans-serif", boxShadow: "0 2px 10px rgba(0,0,0,.12)",
      }}
    >
      <span aria-hidden style={{ width: 8, height: 8, borderRadius: 99, background: t.tone }} />
      {label}
      {DATA_MODE === "live" && link === "signed-out" && (
        <Link href="/login" style={{ color: t.tone, textDecoration: "underline" }}>Sign in</Link>
      )}
      {s?.user && (
        <span style={{ color: "#444" }}>
          · {s.user.full_name} ({s.user.role}) ·{" "}
          <button onClick={() => { session.clear(); window.location.href = "/login" }}
            style={{ background: "none", border: 0, padding: 0, color: "#444", textDecoration: "underline", cursor: "pointer", font: "inherit" }}>
            Sign out
          </button>
        </span>
      )}
      <Link href="/presenter" style={{ color: "#006D58", textDecoration: "underline" }}>Presenter</Link>
    </div>
  )
}
