import { motion, AnimatePresence } from "framer-motion"
import { ClipboardList, FlaskConical, Eye, Brain, CalendarCheck } from "lucide-react"
import { useEvaluation } from "../api/hooks"
import { useApp } from "../store/useApp"

const MONTHS = ["Mar", "Apr", "May", "Jun", "Jul", "Aug"]
const monthOf = (d: number) => Math.min(5, Math.floor(d / 30.5))
const ICONS = [ClipboardList, FlaskConical, Eye, Brain]
const checks = [
  { type: "vision", due: 3 },
  { type: "cognitive", due: 1 },
  { type: "balance", due: 5 },
  { type: "sample", due: 8 },
] as const

function Bars({ values, hatch }: { values: number[]; hatch?: boolean }) {
  const max = Math.max(...values),
    min = Math.min(...values) - 4
  return (
    <div className="flex h-20 items-end gap-1 sm:gap-1.5" aria-hidden>
      {values.map((v, i) => (
        <span
          key={i}
          className={`flex-1 rounded-t-[5px] transition-all duration-300 ease-out ${hatch ? "hatch opacity-45" : "bg-ink/90"}`}
          style={{
            height: `${Math.max(12, ((v - min) / (max - min || 1)) * 100)}%`,
          }}
        />
      ))}
    </div>
  )
}

export function MissionTimeline() {
  const day = useApp((s) => s.day)
  const setCalendarOpen = useApp((s) => s.setCalendarOpen)
  const { data: ev } = useEvaluation(day)
  const cur = monthOf(day)
  const start = Math.max(0, Math.min(cur - 1, 4))
  const cols = [start, start + 1]

  if (!ev) return null

  const hr = ev.live.map((s) => s.hr)
  const bars = Array.from(
    { length: 20 },
    (_, i) => hr[Math.floor((i / 20) * hr.length)] ?? 60,
  )
  return (
    <section aria-label="Mission history timeline" className="col-span-full">
      <div className="flex items-center justify-between pb-3 pt-1">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-label">
            Expedition 74 Timeline
          </span>
          <span className="text-label/40">·</span>
          <span className="text-[12.5px] font-medium text-ink">
            Day {day + 1} of 183
          </span>
        </div>
        <button
          onClick={() => setCalendarOpen(true)}
          className="inline-flex items-center gap-2 rounded-lg border border-border bg-surface hover:bg-inset px-3 py-1.5 text-[12px] font-medium text-ink shadow-xs transition-colors cursor-pointer active:scale-95"
        >
          <CalendarCheck size={14} className="text-accent" />
          <span>Open Mission Calendar</span>
        </button>
      </div>
      <div className="grid gap-5 lg:grid-cols-2">
        <AnimatePresence mode="popLayout" initial={false}>
          {cols.map((m) => {
            const isCur = m === cur
            const list = checks.filter((c) => monthOf(c.due) === m).slice(0, 4)
            return (
              <motion.div
                key={m}
                layout
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -16 }}
                transition={{ duration: 0.35, ease: [0.25, 1, 0.5, 1] }}
                className="relative border-l border-border pl-5"
              >
                <span
                  className={`absolute -left-[5px] top-0 size-2.5 rounded-full transition-all duration-300 ${
                    isCur
                      ? "bg-accent ring-2 ring-accent/30"
                      : "bg-ink"
                  }`}
                  aria-hidden
                />
                <h3 className="mb-3 text-[20px] font-medium tracking-[-0.02em] flex items-center gap-2.5">
                  <span>{MONTHS[m]}</span>
                  {isCur && (
                    <span className="rounded-md bg-accent/15 border border-accent/30 px-2 py-0.5 text-[11px] font-semibold text-accent">
                      Active
                    </span>
                  )}
                </h3>
                <div className="mb-3 flex flex-wrap gap-2">
                  {list.length === 0 && (
                    <span className="rounded-md bg-inset border border-border px-2.5 py-1 text-[11.5px] text-ink-3">
                      No checks scheduled
                    </span>
                  )}
                  {list.map((c, i) => {
                    const I = ICONS[i % 4]
                    return (
                      <span
                        key={i}
                        className="inline-flex items-center gap-1.5 rounded-md border border-border bg-surface px-2.5 py-1 text-[11.5px] font-medium text-ink capitalize shadow-xs transition-colors"
                      >
                        <I size={13} strokeWidth={1.5} className="text-ink-2" aria-hidden />
                        <span>{c.type}</span>
                        <span className="text-ink-3 font-normal">day {c.due + 1}</span>
                      </span>
                    )
                  })}
                </div>
                <div className="card p-4 sm:p-4.5">
                  <div className="mb-3 flex items-center justify-between">
                    <span className="text-[13px] font-medium text-ink">Heart rate, last hour</span>
                    <span className="rounded-md bg-inset border border-border px-2 py-0.5 font-mono text-[11px] font-semibold tabular-nums text-ink">
                      {Math.round(ev.nowS.hr)} bpm
                    </span>
                  </div>
                  <Bars values={bars} hatch={!isCur} />
                </div>
              </motion.div>
            )
          })}
        </AnimatePresence>
      </div>
    </section>
  )
}
