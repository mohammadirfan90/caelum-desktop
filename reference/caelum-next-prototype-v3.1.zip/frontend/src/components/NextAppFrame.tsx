"use client"

import { useState, useRef, useCallback, useEffect, type ReactNode } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { motion } from "framer-motion"
import {
  X,
  Orbit,
  House,
  HeartPulse,
  CalendarCheck,
  Wind,
  MessageCircle,
  LayoutGrid,
  SlidersHorizontal,
  ClipboardList,
  Dumbbell,
  FlaskConical,
} from "lucide-react"
import { SheetRootCtx } from "./Sheet"
import { OfflineBanner } from "./Layout"
import { useEvaluation } from "../api/hooks"
import { useApp } from "../store/useApp"
import { levelLabel } from "./Level"
import { MissionCalendarModal } from "./MissionCalendarModal"
import { useVitals, fmt, STATUS_TEXT } from "../api/vitals"
import { useCrew, useCrewMember } from "../api/crew"
import { selectAstronaut } from "../api/live"

const checks = [
  { type: "vision", due: 3 },
  { type: "cognitive", due: 1 },
  { type: "balance", due: 5 },
  { type: "sample", due: 8 },
] as const
const sessions = [] as any[]
const N = 183

const TABS = [
  { to: "/", label: "Home", icon: House },
  { to: "/body", label: "Body", icon: HeartPulse },
  { to: "/checks", label: "Checks", icon: CalendarCheck },
  { to: "/env", label: "Environment", icon: Wind },
  { to: "/coach", label: "Coach", icon: MessageCircle },
  { to: "/more", label: "More", icon: LayoutGrid },
]

const tabFor = (p: string) => {
  if (p === "/") return "/"
  if (["/body", "/bone", "/immune", "/vision", "/twin", "/sensor"].some((x) => p.startsWith(x))) return "/body"
  if (["/checks", "/cognitive"].some((x) => p.startsWith(x))) return "/checks"
  if (["/env", "/radiation"].some((x) => p.startsWith(x))) return "/env"
  if (p.startsWith("/coach")) return "/coach"
  return "/more"
}

const TITLES: Record<string, string> = {
  "/": "Overview",
  "/body": "Body",
  "/checks": "Checks",
  "/env": "Environment",
  "/coach": "Coach",
  "/more": "Mission",
}

const PILLS = [
  { to: "/alerts", label: "Alerts" },
  { to: "/radiation", label: "Radiation" },
  { to: "/bone", label: "Exercise" },
  { to: "/mood", label: "Mood" },
  { to: "/timeline", label: "Timeline" },
  { to: "/mc/hazards", label: "Hazard Map" },
  { to: "/mc/triage", label: "Triage & Earth Link" },
  { to: "/mc/validation", label: "Validation" },
  { to: "/baseline", label: "Baseline" },
  { to: "/privacy", label: "Privacy" },
  { to: "/sources", label: "Data Sources" },
]

function ScrollablePills() {
  const pathname = usePathname()
  const scrollRef = useRef<HTMLDivElement>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [startX, setStartX] = useState(0)
  const [scrollLeft, setScrollLeft] = useState(0)

  const onMouseDown = useCallback((e: React.MouseEvent) => {
    if (!scrollRef.current) return
    setIsDragging(true)
    setStartX(e.pageX - scrollRef.current.offsetLeft)
    setScrollLeft(scrollRef.current.scrollLeft)
  }, [])

  const onMouseLeave = useCallback(() => setIsDragging(false), [])
  const onMouseUp = useCallback(() => setIsDragging(false), [])
  const onMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (!isDragging || !scrollRef.current) return
      e.preventDefault()
      const x = e.pageX - scrollRef.current.offsetLeft
      const walk = (x - startX) * 2
      scrollRef.current.scrollLeft = scrollLeft - walk
    },
    [isDragging, startX, scrollLeft]
  )

  return (
    <div
      ref={scrollRef}
      className={`mt-4 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-hide ${isDragging ? "cursor-grabbing select-none" : "cursor-grab"}`}
      role="navigation"
      aria-label="Mission sections"
      onMouseDown={onMouseDown}
      onMouseLeave={onMouseLeave}
      onMouseUp={onMouseUp}
      onMouseMove={onMouseMove}
    >
      <span className="flex size-9 shrink-0 items-center justify-center rounded-lg border border-border bg-surface text-ink-2 pointer-events-none shadow-xs" aria-hidden>
        <SlidersHorizontal size={16} strokeWidth={1.5} />
      </span>
      {PILLS.map((p) => {
        const isActive = pathname === p.to
        return (
          <Link
            key={p.to}
            href={p.to}
            onClick={(e) => {
              if (isDragging) e.preventDefault()
            }}
            className={`inline-flex min-h-9 shrink-0 items-center rounded-lg border px-3.5 text-[13px] font-medium transition-colors ${
              isActive
                ? "bg-accent text-canvas border-accent shadow-xs"
                : "bg-surface border-border text-ink-2 hover:bg-inset hover:text-ink shadow-xs"
            }`}
          >
            {p.label}
          </Link>
        )
      })}
    </div>
  )
}

function PatientStrip() {
  const day = useApp((s) => s.day)
  const { data: ev } = useEvaluation(day)
  const top = ev?.alerts?.find((a) => a.level !== "normal")

  const vt = useVitals()
  const astronaut = useCrewMember(vt.astronautId)
  const { data: crew } = useCrew()
  const v = [
    ["Heart Rate", fmt(vt.hr), "bpm", vt.hr],
    ["Oxygen SpO₂", fmt(vt.spo2, 1), "%", vt.spo2],
    ["Cabin CO₂", fmt(vt.co2, 1), "mmHg", vt.co2],
    ["Core Temp", fmt(vt.temp, 1), "°C", vt.temp],
  ] as const

  return (
    <section aria-label="Astronaut profile and live telemetry" className="mb-6">
      <div className="card p-4 sm:p-5">
        <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-6 items-center">
          <div className="col-span-2 flex items-center gap-3">
            <span className="flex size-11 sm:size-12 shrink-0 items-center justify-center rounded-full bg-signal text-[15px] sm:text-[16px] font-semibold text-canvas tracking-wider shadow-xs">
              {astronaut.initials}
            </span>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[15px] sm:text-[17px] font-semibold text-ink leading-tight truncate">
                  {astronaut.name}
                </span>
                <span className="shrink-0 rounded-full border border-border px-2 py-0.5 text-[10.5px] font-medium text-label uppercase">
                  {astronaut.id}
                </span>
              </div>
              <div className="text-[12px] sm:text-[13px] text-label truncate">
                {astronaut.role} · {astronaut.mission}
              </div>
              {crew && crew.length > 1 && (
                <label className="mt-1 flex items-center gap-1.5 text-[12px] text-label">
                  Viewing
                  <select
                    value={vt.astronautId}
                    onChange={(e) => selectAstronaut(e.target.value)}
                    className="rounded-md border border-border bg-surface px-1.5 py-0.5 text-[12px] text-ink"
                  >
                    {crew.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </label>
              )}
            </div>
          </div>
          {v.map(([l, n, u, vv]) => (
            <div key={l}>
              <div className="text-[11px] text-label">
                {l}
                {vv.status !== "LIVE" && <span className="ml-1 font-medium text-warning">· {STATUS_TEXT[vv.status]}</span>}
              </div>
              <div className="text-[22px] sm:text-[30px] font-light leading-tight tabular-nums tracking-[-0.03em]">
                {n}
                <span className="ml-1 text-[12px] sm:text-[14px] text-label">{u}</span>
              </div>
            </div>
          ))}
        </div>
        <ScrollablePills />
      </div>
    </section>
  )
}

const MONTHS = ["Mar", "Apr", "May", "Jun", "Jul", "Aug"]
const monthOf = (d: number) => Math.min(5, Math.floor(d / 30.5))

function TimelineBar() {
  const day = useApp((s) => s.day)
  const setDay = useApp((s) => s.setDay)
  const cur = monthOf(day)
  const calendarOpen = useApp((s) => s.calendarOpen)
  const setCalendarOpen = useApp((s) => s.setCalendarOpen)

  const nodes = [
    {
      icon: ClipboardList,
      label: "checks",
      count: (m: number) => checks.filter((c) => monthOf(c.due) === m && c.type !== "sample").length,
    },
    {
      icon: Dumbbell,
      label: "exercise sessions with degraded machines",
      count: (m: number) => sessions.filter((s, i) => monthOf(i) === m && s.machineStatus !== "ok").length,
    },
    {
      icon: FlaskConical,
      label: "samples",
      count: (m: number) => checks.filter((c) => monthOf(c.due) === m && c.type === "sample").length,
    },
  ]

  return (
    <>
      <div className="pointer-events-none absolute inset-x-0 bottom-5 sm:bottom-6 z-30 flex justify-center px-4">
        <nav
          aria-label="Mission timeline"
          className="pointer-events-auto flex max-w-[calc(100vw-2rem)] items-center gap-1.5 overflow-x-auto rounded-full bg-raised/95 p-1.5 shadow-lg backdrop-blur-md border border-border scrollbar-hide"
        >
          <button
            onClick={() => setCalendarOpen(true)}
            aria-label={`Open Mission Calendar - currently Day ${day + 1} of ${N}`}
            className="flex shrink-0 items-center gap-2.5 rounded-full bg-nav p-1 pr-4 text-on-nav shadow-sm hover:bg-nav/90 transition-all cursor-pointer group active:scale-95"
          >
            <span className="flex size-[34px] items-center justify-center rounded-full bg-raised/20 text-on-nav group-hover:bg-accent group-hover:text-canvas transition-colors">
              <CalendarCheck size={16} strokeWidth={1.5} />
            </span>
            <span className="leading-tight text-left">
              <span className="block text-[10px] uppercase tracking-wider text-on-nav/60 group-hover:text-on-nav/80 transition-colors">Mission day</span>
              <span className="text-[13px] font-medium tabular-nums">
                {day + 1} <span className="text-on-nav/40 font-normal">/ {N}</span>
              </span>
            </span>
          </button>
          {MONTHS.map((m, i) => {
            const on = i === cur,
              future = i > cur
            return (
              <div
                key={m}
                className={`relative flex shrink-0 items-center gap-1 rounded-full p-1 transition-opacity ${
                  future ? "opacity-50" : ""
                }`}
              >
                <button
                  onClick={() => setDay(Math.round(i * 30.5))}
                  className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[12.5px] font-medium transition-all ${
                    on ? "bg-accent text-canvas font-semibold shadow-xs" : "text-ink hover:bg-surface/80"
                  }`}
                >
                  <span>{m}</span>
                </button>
                {on && (
                  <div className="flex items-center gap-1 px-1">
                    {nodes.map((n) => {
                      const c = n.count(i)
                      if (!c) return null
                      return (
                        <span
                          key={n.label}
                          className="flex size-6 items-center justify-center rounded-full bg-surface border border-border text-[11px] font-semibold text-ink shadow-2xs"
                          title={`${c} ${n.label}`}
                        >
                          <n.icon size={11} strokeWidth={1.6} className="text-ink-2" />
                        </span>
                      )
                    })}
                  </div>
                )}
              </div>
            )
          })}
        </nav>
      </div>
      <MissionCalendarModal
        isOpen={calendarOpen}
        onClose={() => setCalendarOpen(false)}
      />
    </>
  )
}

export function NextAppFrame({ children }: { children: ReactNode }) {
  const [root, setRoot] = useState<HTMLElement | null>(null)
  const pathname = usePathname()
  const router = useRouter()
  const active = tabFor(pathname)
  const home = pathname === "/"

  return (
    <div
      ref={setRoot}
      className="relative flex h-dvh w-full flex-col overflow-hidden bg-surface"
    >
      <SheetRootCtx.Provider value={root}>
        {/* Full-width Mission Control Header */}
        <header className="shrink-0 z-20 w-full border-b border-border/80 bg-nav text-on-nav shadow-sm">
          <div className="flex h-[66px] sm:h-[72px] w-full items-center justify-between px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-3 sm:gap-4">
              <button
                onClick={() => (home ? undefined : router.push("/"))}
                aria-label={home ? "CAELUM" : "Back to Overview"}
                className="flex size-11 items-center justify-center rounded-full bg-raised/15 text-on-nav hover:bg-raised/25 transition-all shadow-sm active:scale-95"
              >
                {home ? (
                  <Orbit size={20} strokeWidth={1.4} />
                ) : (
                  <X size={18} strokeWidth={1.4} />
                )}
              </button>
              <div className="flex items-baseline gap-2.5">
                <span className="text-[13.5px] font-semibold tracking-wider text-on-nav/50 uppercase hidden sm:inline">
                  CAELUM
                </span>
                <span className="text-on-nav/30 hidden sm:inline">/</span>
                <h1 className="text-[20px] sm:text-[26px] font-light tracking-[-0.03em] text-on-nav">
                  {TITLES[active] ?? "Overview"}
                </h1>
              </div>
            </div>

            <div className="flex items-center gap-2 sm:gap-3">
              <nav
                aria-label="Primary"
                className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto scrollbar-hide py-1"
              >
                {TABS.map((t) => {
                  const isActive = t.to === active
                  return (
                    <Link
                      key={t.to}
                      href={t.to}
                      aria-current={isActive ? "page" : undefined}
                      className={`inline-flex min-h-10 shrink-0 items-center gap-2 rounded-full px-3.5 sm:px-4 text-[13px] sm:text-[13.5px] font-medium transition-all ${
                        isActive
                          ? "bg-accent text-canvas shadow-[0_4px_14px_rgba(0,109,88,.35)]"
                          : "bg-raised/15 text-on-nav/80 hover:bg-raised/25 hover:text-on-nav"
                      }`}
                    >
                      <t.icon size={16} strokeWidth={1.4} aria-hidden />
                      <span className="hidden md:inline">{t.label}</span>
                    </Link>
                  )
                })}
              </nav>
            </div>
          </div>
        </header>

        {/* Full-width Main Viewport */}
        <div className="relative flex min-h-0 flex-1 flex-col bg-surface">
          <main
            id="scroll"
            className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 sm:px-8 lg:px-12 xl:px-16 pb-36 pt-6"
          >
            <div className="mx-auto max-w-[1720px] w-full">
              <PatientStrip />
              <OfflineBanner />
              {children}
            </div>
          </main>
          <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 h-28 bg-gradient-to-t from-surface via-surface/85 to-transparent" />
          <TimelineBar />
        </div>
      </SheetRootCtx.Provider>
    </div>
  )
}
