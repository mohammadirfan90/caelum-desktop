import * as React from "react"

interface HeartRateBarsProps {
  bpm: number
  baseline?: number
  restingMin?: number
  restingMax?: number
  height?: number
  className?: string
}

export function HeartRateBars({
  bpm = 61,
  baseline = 61,
  restingMin = 58,
  restingMax = 72,
  height,
  className = "",
}: HeartRateBarsProps) {
  // Physiological scale range: 40 bpm (deep rest/bradycardia threshold) to 110 bpm (elevated)
  const minScale = 40
  const maxScale = 110
  const scaleSpan = maxScale - minScale

  const toPct = (val: number) => {
    const clamped = Math.max(minScale, Math.min(maxScale, val))
    return Math.round(((clamped - minScale) / scaleSpan) * 1000) / 10
  }

  const livePct = toPct(bpm)
  const baselinePct = toPct(baseline)
  const zoneLeftPct = toPct(restingMin)
  const zoneWidthPct = toPct(restingMax) - zoneLeftPct

  const isElevated = bpm > restingMax + 4
  const isDepressed = bpm < restingMin - 4

  return (
    <div className={`w-full select-none ${className}`} aria-label={`Heart rate: ${bpm} bpm. Target resting range ${restingMin} to ${restingMax} bpm.`}>
      {/* ── Main Clinical Range Track ── */}
      <div className="relative h-2 w-full rounded-full bg-border/70 overflow-hidden" role="progressbar" aria-valuenow={bpm} aria-valuemin={minScale} aria-valuemax={maxScale}>
        {/* Shaded Optimal Resting Zone Band */}
        <div
          className="absolute top-0 bottom-0 bg-signal/20 border-x border-signal/40"
          style={{
            left: `${zoneLeftPct}%`,
            width: `${zoneWidthPct}%`,
          }}
          title={`Resting Range: ${restingMin}–${restingMax} bpm`}
        />

        {/* Live Active Telemetry Bar */}
        <div
          className={`h-full rounded-full transition-all duration-500 ${
            isElevated
              ? "bg-warning shadow-[0_0_8px_rgba(217,119,6,0.4)]"
              : isDepressed
                ? "bg-ink-3"
                : "bg-signal shadow-[0_0_8px_rgba(0,109,88,0.35)]"
          }`}
          style={{ width: `${livePct}%` }}
        />

        {/* Subtle Baseline Notch Line */}
        <div
          className="absolute top-0 bottom-0 w-[2px] bg-ink/70 z-10 -translate-x-1/2"
          style={{ left: `${baselinePct}%` }}
          title={`Expected Baseline: ${baseline} bpm`}
        />
      </div>

      {/* ── Precision Scale & Zone Indicators ── */}
      <div className="mt-2 flex items-center justify-between text-[11px] text-label">
        <div className="flex items-center gap-1.5">
          <span className="size-1.5 rounded-full bg-signal" />
          <span>Optimal band: <strong className="font-semibold text-ink">{restingMin}–{restingMax} bpm</strong></span>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="size-1.5 rounded-full bg-ink/60" />
          <span>Baseline: <strong className="font-semibold text-ink">{baseline} bpm</strong></span>
        </div>

        <div className="hidden sm:flex items-center gap-1 text-[10.5px] font-mono text-ink-3">
          <span>{bpm > baseline ? `+${(bpm - baseline).toFixed(1)} bpm` : `${(bpm - baseline).toFixed(1)} bpm`} vs base</span>
        </div>
      </div>
    </div>
  )
}
