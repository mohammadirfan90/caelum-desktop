"use client"
import { useState } from "react"
import { useQueryClient } from "@tanstack/react-query"
import { alertsApi } from "@/api/clients"
import { LevelDot, levelLabel } from "./Level"
import { useSession } from "./LiveSync"

const PLAN: Record<string, [number, string][]> = {
  critical: [[0, "Astronaut"], [0, "Medical officer"], [15, "Wristband sound"], [30, "Whole crew"], [60, "Flight surgeon (ground)"]],
  warning: [[0, "Astronaut"], [0, "Medical officer"], [60, "Whole crew"]],
  observe: [[0, "Astronaut"], [3600, "Reminder"], [86400, "Medical officer"]],
  advisory: [[0, "Astronaut"]],
}

function ago(iso: string) {
  const s = Math.max(0, Math.round((Date.now() - new Date(iso.endsWith("Z") || iso.includes("+") ? iso : iso + "Z").getTime()) / 1000))
  return s < 60 ? `${s}s ago` : s < 3600 ? `${Math.round(s / 60)} min ago` : `${Math.round(s / 3600)} h ago`
}

export function LiveAlertCard({ alert: a }: { alert: any }) {
  const qc = useQueryClient()
  const s = useSession()
  const [busy, setBusy] = useState(false)
  const plan = PLAN[a.rawLevel] ?? PLAN.advisory
  const role = s?.user.role
  const canAck = a.status === "ACTIVE" && (
    (role === "Astronaut" && s?.user.astronaut_id === a.astronautId) ||
    role === "Medical Officer" || role === "Flight Surgeon" || role === "Administrator")

  async function ack() {
    setBusy(true)
    try {
      await alertsApi.acknowledge(a.id)
      await qc.invalidateQueries({ queryKey: ["alerts"] })
    } finally {
      setBusy(false)
    }
  }

  return (
    <article className="card col-span-full p-4 sm:p-5" aria-label={`${levelLabel(a.level)} alert: ${a.title}`}>
      <div className="flex flex-wrap items-start gap-3">
        <LevelDot level={a.level} size={20} />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-[17px] font-semibold leading-tight">{a.title}</h3>
            <span className="rounded-full border border-border px-2 py-0.5 text-[11px] font-medium uppercase text-label">
              {a.rawLevel === "advisory" ? "Sensor advisory" : levelLabel(a.level)}
            </span>
            <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${a.status === "ACTIVE" ? "bg-warning/15 text-warning" : "bg-signal-soft text-signal"}`}>
              {a.status === "ACTIVE" ? "Not acknowledged" : `Acknowledged by ${a.acknowledgedBy}`}
            </span>
          </div>
          <div className="mt-0.5 text-[12px] text-label">
            {a.module} · {a.createdAt ? ago(a.createdAt) : ""} · rule {a.ruleId} v{a.ruleVersion}
          </div>
        </div>
        {canAck && (
          <button onClick={ack} disabled={busy} className="btn btn-ink">
            {role === "Astronaut" ? "I'm OK: acknowledge" : "Acknowledge"}
          </button>
        )}
      </div>

      <ul className="mt-3 list-disc space-y-1 pl-5 text-[13.5px] leading-snug">
        {a.why.map((w: string, i: number) => <li key={i}>{w}</li>)}
      </ul>
      {a.actions?.[0] && (
        <div className="mt-3 rounded-lg border border-border bg-raised p-3 text-[13.5px]">
          <b>What to do: </b>{a.actions[0]}
        </div>
      )}

      <div className="mt-4">
        <div className="text-[12px] font-semibold text-ink">Escalation</div>
        <ol className="mt-2 flex flex-wrap gap-2">
          {plan.map(([sec, who], i) => {
            const done = i < (a.escalationStage ?? 0)
            const stopped = !done && a.status !== "ACTIVE"
            return (
              <li key={who} className={`rounded-lg border px-2.5 py-1.5 text-[12px] ${done ? "border-transparent bg-ink text-canvas" : "border-border text-label"}`}>
                <span className="font-semibold">{done ? "✓ " : ""}{who}</span>
                <span className="ml-1 opacity-75">{stopped ? "stopped" : sec === 0 ? "immediately" : `+${sec}s`}</span>
              </li>
            )
          })}
        </ol>
      </div>
    </article>
  )
}
