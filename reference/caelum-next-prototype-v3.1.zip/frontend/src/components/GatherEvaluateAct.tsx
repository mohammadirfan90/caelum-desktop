import { Activity, Scale, ListChecks, ArrowRight, ShieldCheck } from "lucide-react"
import { Link } from "@/components/Link"
import { useEvaluation } from "../api/hooks"

export function GatherEvaluateAct() {
  const { data: ev } = useEvaluation(0)
  const signalsCount = ev ? Object.keys(ev.sm).length : 12
  const alertsCount = ev?.alerts.length ?? 2
  const actionsCount = ev?.alerts.reduce((n, a) => n + a.actions.length, 0) ?? 6

  const steps = [
    {
      num: "01",
      icon: Activity,
      label: "Gather",
      metric: `${signalsCount} Signals`,
      description: "Continuous bio-telemetry bus active",
      to: "/sources",
      active: true,
    },
    {
      num: "02",
      icon: Scale,
      label: "Evaluate",
      metric: `${alertsCount} Patterns`,
      description: alertsCount > 0 ? "Observation patterns flagged" : "All signals baseline normal",
      to: "/alerts",
      active: alertsCount > 0,
      highlight: alertsCount > 0,
    },
    {
      num: "03",
      icon: ListChecks,
      label: "Act",
      metric: `${actionsCount} Next Steps`,
      description: "Autonomous triage procedures ready",
      to: "/checks",
      active: true,
    },
  ]

  return (
    <nav
      aria-label="Clinical Decision Workflow: Gather, Evaluate, Act"
      className="card p-3 sm:p-3.5 border border-border bg-raised shadow-xs rounded-xl"
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 sm:gap-3">
        {steps.map((s, i) => (
          <Link
            key={s.label}
            to={s.to}
            className={`group relative flex items-center justify-between gap-3 rounded-lg border p-2.5 sm:p-3 transition-all hover:bg-canvas/40 ${
              s.highlight
                ? "border-warning/40 bg-warning/5"
                : "border-border/80 bg-surface/60"
            }`}
          >
            <div className="flex items-center gap-3 min-w-0">
              <span
                className={`flex size-10 shrink-0 items-center justify-center rounded-lg border text-signal transition-transform group-hover:scale-105 ${
                  s.highlight
                    ? "border-warning/30 bg-warning/15 text-warning"
                    : "border-border/80 bg-signal-soft text-signal"
                }`}
              >
                <s.icon size={18} strokeWidth={1.8} aria-hidden />
              </span>
              <div className="min-w-0 leading-tight">
                <div className="flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wider text-label">
                  <span>{s.num}</span>
                  <span>·</span>
                  <span>{s.label}</span>
                </div>
                <div className="mt-0.5 text-[14px] font-semibold tracking-[-0.01em] text-ink truncate">
                  {s.metric}
                </div>
                <div className="text-[11.5px] text-label truncate">
                  {s.description}
                </div>
              </div>
            </div>

            <div className="shrink-0 text-label/60 group-hover:text-ink transition-colors">
              <ArrowRight size={15} strokeWidth={1.7} />
            </div>
          </Link>
        ))}
      </div>
    </nav>
  )
}
