import { useState } from "react"
import { ChevronDown, CircleHelp, HeartPulse, Wind, Activity, ArrowRight } from "lucide-react"
import { Link } from "@/components/Link"
import type { Alert } from "../data/types"
import { Sheet } from "./Sheet"
import { AlertBadge, ConfidenceBar, LevelDot } from "./Level"
import { SourceChip, AdviceFooter } from "./ui"

type Why = Pick<Alert, "title" | "level" | "why" | "confidence" | "sources"> & Partial<Alert>

export function WhyButton({
  info,
  dark,
  className = "",
  size = "md",
}: {
  info: Why
  dark?: boolean
  className?: string
  size?: "sm" | "md"
}) {
  const [o, setO] = useState(false)
  return (
    <>
      <button
        onClick={() => setO(true)}
        className={`inline-flex items-center gap-1.5 rounded-full font-medium transition-all ${
          size === "sm" ? "px-3 py-1.5 text-[12px]" : "px-3.5 py-2 text-[13px]"
        } ${
          dark
            ? "bg-inset text-on-nav hover:bg-white/15"
            : "bg-raised border border-border text-ink hover:border-border-strong shadow-xs"
        } ${className}`}
      >
        <CircleHelp size={15} strokeWidth={1.8} aria-hidden />
        <span>Why am I seeing this?</span>
      </button>
      <WhyDrawer info={info} open={o} onClose={() => setO(false)} />
    </>
  )
}

export function WhyDrawer({
  info,
  open,
  onClose,
}: {
  info: Why
  open: boolean
  onClose: () => void
}) {
  return (
    <Sheet open={open} onClose={onClose} title="Why am I seeing this?">
      <div className="flex flex-col gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <AlertBadge level={info.level} />
          <span className="text-[15px] font-semibold">{info.title}</span>
        </div>
        <ConfidenceBar value={info.confidence} />
        <div>
          <div className="label mb-2">Contributing signals</div>
          <ul className="flex flex-col gap-2">
            {info.why.map((w, i) => (
              <li
                key={i}
                className="flex gap-3 rounded-2xl bg-raised p-3 text-[14.5px] leading-snug shadow-[0_2px_8px_rgba(0,0,0,.05)]"
              >
                <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-ink" />
                {w}
              </li>
            ))}
          </ul>
        </div>
        <div className="flex flex-wrap gap-2">
          {info.sources.map((s, i) => (
            <SourceChip key={i} kind={s.kind} label={s.label} />
          ))}
        </div>
        <p className="text-[13px] leading-snug text-label">
          This is a pattern, not a diagnosis. Decision support only.
        </p>
        <AdviceFooter />
      </div>
    </Sheet>
  )
}

export function RiskChain({ chain }: { chain: string[][] }) {
  const W = 320,
    colW = W / chain.length
  const rows = Math.max(...chain.map((c) => c.length))
  const H = 34 * rows + 20
  const pos = chain.map((col, ci) =>
    col.map((label, ri) => ({
      label,
      x: colW * ci + colW / 2,
      y: (H / (col.length + 1)) * (ri + 1),
    })),
  )
  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      className="w-full"
      role="img"
      aria-label={`Risk chain: ${chain.map((c) => c.join(" and ")).join(", leading to ")}`}
    >
      {pos
        .slice(0, -1)
        .flatMap((col, ci) =>
          col.flatMap((a, i) =>
            pos[ci + 1].map((b, j) => (
              <path
                key={`${ci}-${i}-${j}`}
                d={`M${a.x},${a.y} C${a.x + colW / 2},${a.y} ${b.x - colW / 2},${b.y} ${b.x},${b.y}`}
                fill="none"
                stroke="var(--ink-3)"
                strokeOpacity=".35"
                strokeWidth="1.2"
              />
            )),
          ),
        )}
      {pos.flat().map((p, i) => {
        const last = chain.length - 1 === pos.findIndex((c) => c.includes(p))
        return (
          <g key={i}>
            <circle
              cx={p.x}
              cy={p.y}
              r={last ? 6 : 4.5}
              fill={last ? "var(--ink)" : "var(--raised)"}
              stroke="var(--ink)"
              strokeWidth="1.4"
            />
            <text
              x={p.x}
              y={p.y + 17}
              fontSize="8.6"
              textAnchor="middle"
              fill="var(--ink-3)"
            >
              {p.label.length > 26 ? p.label.slice(0, 25) + "…" : p.label}
            </text>
          </g>
        )
      })}
    </svg>
  )
}

export function AlertCard({
  alert,
  expandable,
  dark,
}: {
  alert: Alert
  expandable?: boolean
  dark?: boolean
}) {
  const [open, setOpen] = useState(false)
  const [sheetOpen, setSheetOpen] = useState(false)

  const ModuleIcon = alert.module.toLowerCase().includes("cardio") || alert.module.toLowerCase().includes("heart")
    ? HeartPulse
    : alert.module.toLowerCase().includes("env")
      ? Wind
      : Activity

  return (
    <div className={`${dark ? "bg-nav text-on-nav border-border" : "card bg-raised border-border"} p-4 sm:p-5 rounded-xl border shadow-xs flex flex-col justify-between transition-all hover:border-border-strong`}>
      <div>
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-1.5 text-[11px] font-medium text-label uppercase tracking-wider">
            <ModuleIcon size={14} className="text-signal" />
            <span>{alert.module}</span>
          </div>
          <AlertBadge level={alert.level} dark={dark} />
        </div>

        <button
          onClick={() => setSheetOpen(true)}
          className="text-left block text-[16.5px] font-semibold leading-snug tracking-[-0.015em] hover:text-signal transition-colors text-ink w-full"
        >
          {alert.title}
        </button>

        {alert.why?.[0] && (
          <p className="mt-1.5 text-[12.5px] leading-snug text-label line-clamp-2">
            {alert.why[0]}
          </p>
        )}

        {/* Grouped Contributing Signals Tags */}
        {alert.grouped?.length > 0 && (
          <div className="mt-3 flex flex-wrap items-center gap-1.5">
            <span className="text-[10.5px] font-semibold uppercase tracking-wider text-label">
              Signals:
            </span>
            {alert.grouped.map((g, i) => (
              <span
                key={i}
                className="inline-flex items-center rounded-md bg-canvas/70 border border-border/70 px-2 py-0.5 text-[11px] font-medium text-ink-2"
              >
                {g}
              </span>
            ))}
          </div>
        )}

        <div className="mt-3.5">
          <ConfidenceBar value={alert.confidence} dark={dark} />
        </div>
      </div>

      <div className="mt-4 pt-3 border-t border-border/70 flex flex-wrap items-center justify-between gap-2">
        <WhyButton info={alert} dark={dark} size="sm" />

        {expandable ? (
          <button
            onClick={() => setOpen(!open)}
            aria-expanded={open}
            className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[12px] font-medium transition-colors ${
              dark
                ? "bg-white/10 hover:bg-white/15 text-white"
                : "bg-surface border border-border text-ink hover:bg-canvas"
            }`}
          >
            <span>{open ? "Hide details" : `${alert.actions.length} action steps & risk`}</span>
            <ChevronDown
              size={14}
              strokeWidth={1.8}
              className={`transition-transform duration-200 ${open ? "rotate-180" : ""}`}
            />
          </button>
        ) : (
          <Link
            to="/mc/triage"
            className="inline-flex items-center gap-1 text-[12px] font-medium text-signal hover:underline"
          >
            <span>Review triage protocol</span>
            <ArrowRight size={13} />
          </Link>
        )}
      </div>

      {open && (
        <div className="mt-4 flex flex-col gap-3.5 border-t border-border pt-4">
          <div>
            <div className="label text-[11px] mb-2 font-medium">Recommended Clinical Actions</div>
            <ul className="flex flex-col gap-1.5 text-[13px] text-ink">
              {alert.actions.map((act, i) => (
                <li key={i} className="flex items-start gap-2 leading-snug">
                  <span className="flex size-4 shrink-0 items-center justify-center rounded-full bg-signal text-[10px] font-bold text-canvas mt-0.5">
                    {i + 1}
                  </span>
                  <span>{act}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <div className="label text-[11px] mb-1.5 font-medium">Causal Risk Chain</div>
            <RiskChain chain={alert.chain} />
          </div>
        </div>
      )}

      <WhyDrawer info={alert} open={sheetOpen} onClose={() => setSheetOpen(false)} />
    </div>
  )
}
