import * as React from "react"

export function EcgLine({ bpm = 60, color = "#ef4444", height = 64 }: { bpm?: number; color?: string; height?: number }) {
  const canvasRef = React.useRef<HTMLCanvasElement>(null)
  const offsetRef = React.useRef(0)
  const rafRef = React.useRef(0)
  const bpmRef = React.useRef(bpm)
  bpmRef.current = bpm

  React.useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return
    const dpr = window.devicePixelRatio || 1

    const resize = () => {
      const w = canvas.parentElement?.clientWidth || 400
      canvas.width = w * dpr
      canvas.height = height * dpr
      canvas.style.width = w + "px"
      canvas.style.height = height + "px"
      ctx.scale(dpr, dpr)
    }
    resize()
    const ro = new ResizeObserver(resize)
    if (canvas.parentElement) ro.observe(canvas.parentElement)

    // Resolve color if it is a CSS variable (e.g. var(--signal))
    let activeColor = color
    if (color.startsWith("var(")) {
      const varName = color.slice(4, -1).trim()
      const computed = getComputedStyle(canvas).getPropertyValue(varName).trim()
      if (computed) activeColor = computed
    }

    // Physiologically accurate QRS wave cycle shape [xFrac (0..1), yFrac (0..1)]
    const SHAPE: [number, number][] = [
      [0.00, 0.50], [0.05, 0.50],
      [0.08, 0.44], [0.11, 0.41], [0.14, 0.50],  // P wave (smooth dome)
      [0.17, 0.50],
      [0.19, 0.54],                             // Q wave dip
      [0.22, 0.08],                             // R wave peak
      [0.25, 0.68],                             // S wave trough
      [0.28, 0.50],                             // ST junction
      [0.32, 0.48], [0.36, 0.38], [0.41, 0.49], // T wave (repolarization)
      [0.44, 0.50], [1.00, 0.50],               // Isoelectric baseline
    ]

    let lastT = 0
    const draw = (t: number) => {
      const dt = Math.min(t - (lastT || t - 16), 50)
      lastT = t
      const W = canvas.width / dpr
      const H = canvas.height / dpr
      // Cycle width tuned so 3.2 full cardiac cycles are visible
      const CW = Math.max(140, W / 3.4)
      const pxPerMs = (CW * (bpmRef.current / 60)) / 1000
      offsetRef.current = (offsetRef.current + pxPerMs * dt) % CW

      ctx.clearRect(0, 0, W, H)

      // ── Medical telemetry coordinate grid ──
      const gridSize = 18
      ctx.save()
      ctx.strokeStyle = activeColor.startsWith("#")
        ? `${activeColor}12`
        : "rgba(0, 109, 88, 0.07)"
      ctx.lineWidth = 0.75

      // Horizontal grid lines
      ctx.beginPath()
      for (let y = 0; y <= H; y += gridSize) {
        ctx.moveTo(0, y)
        ctx.lineTo(W, y)
      }
      // Vertical grid lines
      for (let x = 0; x <= W; x += gridSize) {
        ctx.moveTo(x, 0)
        ctx.lineTo(x, H)
      }
      ctx.stroke()

      // Central baseline reference line
      ctx.beginPath()
      ctx.strokeStyle = activeColor.startsWith("#")
        ? `${activeColor}24`
        : "rgba(0, 109, 88, 0.14)"
      ctx.lineWidth = 1
      ctx.moveTo(0, H * 0.50)
      ctx.lineTo(W, H * 0.50)
      ctx.stroke()
      ctx.restore()

      // ── Soft Area Fill Gradient Under Wave ──
      ctx.save()
      const areaGrad = ctx.createLinearGradient(0, 0, 0, H)
      areaGrad.addColorStop(0, activeColor.startsWith("#") ? `${activeColor}22` : "rgba(0, 109, 88, 0.15)")
      areaGrad.addColorStop(0.5, activeColor.startsWith("#") ? `${activeColor}08` : "rgba(0, 109, 88, 0.05)")
      areaGrad.addColorStop(1, "rgba(0, 0, 0, 0)")

      ctx.beginPath()
      ctx.moveTo(0, H * 0.50)
      for (let c = -1; c <= 5; c++) {
        for (const [px, py] of SHAPE) {
          const x = c * CW + px * CW - offsetRef.current
          const y = py * H
          ctx.lineTo(x, y)
        }
      }
      ctx.lineTo(W, H * 0.50)
      ctx.fillStyle = areaGrad
      ctx.fill()
      ctx.restore()

      // ── Outer Soft Glow Pass ──
      ctx.save()
      ctx.shadowColor = activeColor
      ctx.shadowBlur = 8
      ctx.strokeStyle = activeColor.startsWith("#") ? `${activeColor}66` : "rgba(0, 109, 88, 0.4)"
      ctx.lineWidth = 2.8
      ctx.lineCap = "round"
      ctx.lineJoin = "round"
      drawWavePath()
      ctx.restore()

      // ── Sharp Core Line Pass ──
      ctx.save()
      ctx.shadowColor = activeColor
      ctx.shadowBlur = 3
      ctx.strokeStyle = activeColor
      ctx.lineWidth = 1.8
      ctx.lineCap = "round"
      ctx.lineJoin = "round"
      drawWavePath()
      ctx.restore()

      rafRef.current = requestAnimationFrame(draw)

      function drawWavePath() {
        if (!ctx) return
        ctx.beginPath()
        let started = false
        for (let c = -1; c <= 5; c++) {
          for (const [px, py] of SHAPE) {
            const x = c * CW + px * CW - offsetRef.current
            const y = py * H
            if (!started) {
              ctx.moveTo(x, y)
              started = true
            } else {
              ctx.lineTo(x, y)
            }
          }
        }
        ctx.stroke()
      }
    }

    rafRef.current = requestAnimationFrame((t) => draw(t))
    return () => {
      cancelAnimationFrame(rafRef.current)
      ro.disconnect()
    }
  }, [color, height])

  return (
    <div className="relative w-full overflow-hidden rounded-lg border border-border/70 bg-surface/50 shadow-inner">
      <canvas ref={canvasRef} className="block w-full" />
    </div>
  )
}
