"use client"

import NextLink from "next/link"
import React from "react"

export interface LinkProps extends Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, "href"> {
  href?: string
  to?: string
  className?: string
  children?: React.ReactNode
}

export const Link = React.forwardRef<HTMLAnchorElement, LinkProps>(function Link(
  { to, href, className, children, ...props },
  ref
) {
  const target = href || to || "/"
  return (
    <NextLink ref={ref} href={target} className={className} {...props}>
      {children}
    </NextLink>
  )
})

export default Link
