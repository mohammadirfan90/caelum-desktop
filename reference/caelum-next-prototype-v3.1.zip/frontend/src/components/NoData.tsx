import { STATUS_TEXT } from "@/api/vitals"
import type { ValueStatus } from "@/api/live"

/** Shown instead of a number whenever a reading is not live. Never shows a made-up value. */
export function NoData({ status, size = 28 }: { status: ValueStatus; size?: number }) {
  return (
    <span className="inline-flex items-baseline gap-2" role="status">
      <span style={{ fontSize: size, lineHeight: 1 }} className="font-light text-ink-3">—</span>
      <span className="text-[12px] font-medium uppercase tracking-wider text-warning">{STATUS_TEXT[status]}</span>
    </span>
  )
}
