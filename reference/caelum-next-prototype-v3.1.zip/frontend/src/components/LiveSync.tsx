"use client"
/** Keeps cached data in step with live events, and the UI role in step with the signed-in user. */
import { useEffect, useSyncExternalStore } from "react"
import { useQueryClient } from "@tanstack/react-query"
import { useLiveTelemetry } from "@/api/live"
import { session } from "@/api/session"
import { useApp } from "@/store/useApp"

const UI_ROLE: Record<string, "Astronaut" | "Medical Officer" | "Mission Control"> = {
  Astronaut: "Astronaut",
  "Medical Officer": "Medical Officer",
  "Flight Surgeon": "Medical Officer",
  Administrator: "Medical Officer",
  "Mission Control": "Mission Control",
}

export function useSession() {
  return useSyncExternalStore(session.subscribe, session.get, () => null)
}

export function LiveSync() {
  const qc = useQueryClient()
  const { alertsVersion } = useLiveTelemetry()
  const s = useSession()
  const setRole = useApp((st) => st.setRole)
  useEffect(() => {
    if (alertsVersion > 0) {
      qc.invalidateQueries({ queryKey: ["alerts"] })
      qc.invalidateQueries({ queryKey: ["crew-alerts"] })
      qc.invalidateQueries({ queryKey: ["downlink"] })
    }
  }, [alertsVersion, qc])
  useEffect(() => {
    if (s?.user) setRole(UI_ROLE[s.user.role] ?? "Astronaut")
  }, [s, setRole])
  return null
}
