# CAELUM — Astronaut Health Intelligence Platform
**Autonomous Onboard Biomedical Telemetry & Mission Medical Decision Support System**

CAELUM is the central onboard Crew Health Application. It operates persistently aboard crewed spacecraft, acquiring real-time physiological data from wearable biometric garments, personal dosimeters, and clinical instruments, alongside vehicle environmental life support telemetry (ECLSS).

---

## Status
Advisory research software, **not approved for clinical use**. Read
[`docs/AUDIT_REPORT.md`](./docs/AUDIT_REPORT.md) for the v3.0.0 audit, fixes and roadmap, and
[`docs/IMPLEMENTATION_STATUS.md`](./docs/IMPLEMENTATION_STATUS.md) for what is live versus demo.

## Pitch demo (one command)
```bash
python scripts/demo.py
```
Then follow [`docs/PITCH_GUIDE.md`](./docs/PITCH_GUIDE.md): sign in with a one-click demo role,
open `/presenter`, and trigger scenarios live. The sensors are simulated (always labelled); the
pipeline, alert engine, escalation, audit and downlink are the real software.

## Quick start (development)
Requirements: Node.js 20+ with pnpm 9, Python 3.11+ with `uv`.
```bash
pnpm install
cd backend && uv sync --extra dev && cd ..
# Terminal 1: backend with the labelled simulator (demo users, password caelum-dev)
CAELUM_ENABLE_SIMULATOR=true npm run dev:backend
# Terminal 2: frontend reading live data from the backend
NEXT_PUBLIC_DATA_MODE=live npm run dev:frontend
```
Open http://localhost:3000/login (e.g. `varga` / `caelum-dev`). API docs: http://localhost:8000/docs.
Without `NEXT_PUBLIC_DATA_MODE=live` the UI runs on demo data and says so.

## 🧪 Testing & Validation

```bash
# Run Frontend TypeScript Strict Typecheck
npm run typecheck:frontend

# Run Next.js Production Build
npm run build:frontend

# Run Backend, Acquisition & Interoperability Test Suites (Pytest)
npm run test:backend   # 38 tests incl. alert-safety requirements
```

---

## 📦 Automated Source Packaging & Integrity Verification

```bash
# Scan for leaked secrets, package cleanly into caelum-next.zip, and generate SHA-256
python scripts/package_codebase.py

# Verify archive format, subsystem directories, and checksum
python scripts/verify_archive.py

# Or via npm
npm run zip
npm run verify:zip
```

---

## 📚 Technical Documentation

Detailed architecture documentation and diagrams are located in [`docs/`](./docs/):
- [`docs/SYSTEM_ARCHITECTURE.md`](./docs/SYSTEM_ARCHITECTURE.md) — Complete onboard-to-ground pipeline
- [`docs/HARDWARE_INTEGRATION.md`](./docs/HARDWARE_INTEGRATION.md) — AstroSkin, wrist, and sensor acquisition
- [`docs/SCIENTIFIC_METHODS.md`](./docs/SCIENTIFIC_METHODS.md) — SciPy ECG conditioning, Pan-Tompkins QRS, and HRV
- [`docs/MEDICAL_SAFETY.md`](./docs/MEDICAL_SAFETY.md) — NASA STD-3001 alert engine and hysteresis
- [`docs/MEDICAL_INTEROPERABILITY.md`](./docs/MEDICAL_INTEROPERABILITY.md) — HL7 FHIR R4 mapping
- [`docs/GROUND_OPERATIONS.md`](./docs/GROUND_OPERATIONS.md) — CCSDS framing and NASA Open MCT integration
- [`docs/PRIVACY_AND_SECURITY.md`](./docs/PRIVACY_AND_SECURITY.md) — RBAC and cryptographic audit trail
- [`docs/IMPLEMENTATION_STATUS.md`](./docs/IMPLEMENTATION_STATUS.md) — Flight software readiness matrix
