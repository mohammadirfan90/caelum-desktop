import struct

from app.devices import ble_health as b


def test_sfloat_and_special_values():
    assert b.sfloat(0x0061) == 97
    assert b.sfloat(0xF3E8) == 100.0  # mantissa 1000, exponent -1
    assert b.sfloat(0x07FF) is None and b.sfloat(0x0800) is None


def test_heart_rate_with_rr_and_no_contact():
    payload = bytes([0x10 | 0x04, 72]) + struct.pack("<H", 1024)  # RR present, contact supported/not detected
    r = b.heart_rate_measurement(payload)[0]
    assert r.value == 72 and r.quality == "POOR" and r.context["rr_intervals_ms"] == [1000.0]


def test_plx_invalid_measurement_is_unusable():
    payload = bytes([0x04]) + struct.pack("<HHH", 0x0050, 0x0048, 1 << 15)
    assert {r.quality for r in b.plx_continuous(payload)} == {"UNUSABLE"}


def test_blood_pressure_with_timestamp():
    payload = bytes([0x02]) + struct.pack("<HHH", 120, 80, 93) + struct.pack("<HBBBBB", 2026, 10, 9, 12, 0, 0)
    r = {x.parameter: x for x in b.blood_pressure_measurement(payload)}
    assert r["bp_systolic"].value == 120 and r["bp_diastolic"].measured_at.year == 2026


def test_thermometer_fahrenheit_and_site():
    raw = (0xFF << 24) | 986  # 98.6 with exponent -1
    payload = bytes([0x01 | 0x04]) + struct.pack("<I", raw) + bytes([1])  # armpit
    r = b.temperature_measurement(payload)[0]
    assert r.unit == "°F" and r.parameter == "skin_temp" and abs(r.value - 98.6) < 1e-6


def test_full_uuid_accepted():
    assert b.decode("00002a5f-0000-1000-8000-00805f9b34fb", bytes([0, 0x61, 0, 0x48, 0]))
