import os
import tempfile

_tmp = tempfile.mkdtemp()
os.environ["CAELUM_PROFILE"] = "test"
os.environ["CAELUM_DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"
os.environ["CAELUM_ENABLE_SIMULATOR"] = "false"

from datetime import datetime, timedelta, timezone  # noqa: E402

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.alerts import engine as engine_mod  # noqa: E402
from app.databases.models import Device  # noqa: E402
from app.databases.session import Base, SessionLocal, engine  # noqa: E402
from app.main import app  # noqa: E402
from app.seed import seed_dev  # noqa: E402

T0 = datetime(2026, 10, 9, 12, 0, 0, tzinfo=timezone.utc)


@pytest.fixture(autouse=True)
def fresh_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    engine_mod.engine = engine_mod.AlertEngine()  # reset in-memory persistence timers
    import app.ingestion.pipeline as pipe
    pipe.engine = engine_mod.engine
    with SessionLocal() as db:
        seed_dev(db)
        for i, aid in enumerate(["ast-01", "ast-02", "ast-03"]):
            db.add(Device(id=f"dev-{i+1}", name=f"Test oximeter {i+1}", category="wearable",
                          adapter="ble_standard", astronaut_id=aid))
        db.commit()
    yield


@pytest.fixture
def db():
    with SessionLocal() as s:
        yield s


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


def token(client, username, password="caelum-dev"):
    r = client.post("/api/v1/auth/login", data={"username": username, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def at(seconds: float) -> datetime:
    return T0 + timedelta(seconds=seconds)
