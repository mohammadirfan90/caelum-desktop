"""Safety requirements for the alert engine, written as executable tests."""
from sqlalchemy import select

from app.alerts.engine import acknowledge, escalation_tick
from app.databases.models import Alert, AlertNotification, Baseline, DownlinkPacket, Observation
from app.ingestion.pipeline import ObservationIn, ingest
from app.medical import audit
from conftest import at


def feed(db, values, param="spo2", unit="%", astro="ast-01", dev="dev-1", step=1.0, start=0.0,
         quality="GOOD", context=None):
    items = [ObservationIn(astronaut_id=astro, device_id=dev, parameter=param, value=v, unit=unit,
                           measured_at=at(start + i * step), quality=quality, context=context)
             for i, v in enumerate(values)]
    return ingest(db, items)


def open_alerts(db, astro=None):
    q = select(Alert).where(Alert.status.in_(["ACTIVE", "ACKNOWLEDGED"]))
    if astro:
        q = q.where(Alert.astronaut_id == astro)
    return db.scalars(q).all()


def test_critical_spo2_requires_persistence(db):
    feed(db, [82] * 15)  # 0..14 s: not yet sustained 15 s
    assert not [a for a in open_alerts(db) if a.level == "critical"]
    feed(db, [82], start=15)
    crit = [a for a in open_alerts(db) if a.rule_id == "spo2.critical"]
    assert len(crit) == 1 and "below 85" in crit[0].why[0]


def test_absolute_limit_not_suppressed_by_wide_baseline(db):
    db.add(Baseline(astronaut_id="ast-01", parameter="heart_rate", median=60, mad=40, n=500,
                    window_days=14, status="VALID"))
    db.commit()
    feed(db, [190] * 31, param="heart_rate", unit="bpm")
    assert any(a.rule_id == "hr.critical.high" for a in open_alerts(db))


def test_alerts_are_per_astronaut(db):
    feed(db, [80] * 16, astro="ast-01", dev="dev-1")
    feed(db, [80] * 16, astro="ast-02", dev="dev-2")
    assert len([a for a in open_alerts(db, "ast-01") if a.level == "critical"]) == 1
    assert len([a for a in open_alerts(db, "ast-02") if a.level == "critical"]) == 1


def test_hysteresis_prevents_flicker_and_resolves_after_clear_period(db):
    feed(db, [82] * 16)
    feed(db, [88] * 120, start=16)  # inside hysteresis band (>=85 but <90): stays open
    assert any(a.rule_id == "spo2.critical" for a in open_alerts(db))
    feed(db, [95] * 62, start=136)  # >= clear threshold for 60 s
    assert not any(a.rule_id == "spo2.critical" for a in open_alerts(db))


def test_data_gap_restarts_persistence(db):
    feed(db, [82] * 10)
    feed(db, [82] * 10, start=60)  # 50 s gap > MAX_SAMPLE_GAP_S
    assert not any(a.rule_id == "spo2.critical" for a in open_alerts(db))


def test_higher_level_supersedes_lower(db):
    feed(db, [88] * 61)  # warning after 60 s
    assert any(a.rule_id == "spo2.warning" for a in open_alerts(db))
    feed(db, [80] * 16, start=61)
    statuses = {a.rule_id: a.status for a in db.scalars(select(Alert))}
    assert statuses["spo2.warning"] == "SUPERSEDED" and statuses["spo2.critical"] == "ACTIVE"


def test_poor_quality_raises_sensor_advisory_not_clinical_alarm(db):
    feed(db, [70] * 30, quality="UNUSABLE")
    levels = {a.level for a in open_alerts(db)}
    assert levels == {"advisory"}
    feed(db, [97], start=31)
    assert not open_alerts(db)


def test_exercise_context_suppresses_resting_tachycardia_only(db):
    feed(db, [140] * 130, param="heart_rate", unit="bpm", context={"activity_level": 0.8})
    assert not open_alerts(db)
    feed(db, [190] * 31, param="heart_rate", unit="bpm", start=130, context={"activity_level": 0.8})
    assert any(a.rule_id == "hr.critical.high" for a in open_alerts(db))


def test_escalation_timeline_and_acknowledgement(db):
    feed(db, [80] * 16)
    alert = next(a for a in open_alerts(db) if a.level == "critical")
    base = alert.created_at
    from datetime import timedelta
    for s in (15, 30, 60):
        escalation_tick(db, base + timedelta(seconds=s))
    audiences = [n.audience for n in db.scalars(select(AlertNotification).where(
        AlertNotification.alert_id == alert.id).order_by(AlertNotification.stage))]
    assert audiences == ["astronaut", "medical_officer", "sound", "crew", "ground"]

    feed(db, [80] * 16, astro="ast-02", dev="dev-2")
    a2 = next(a for a in open_alerts(db, "ast-02") if a.level == "critical")
    acknowledge(db, a2, "chen", "Medical Officer")
    escalation_tick(db, a2.created_at + timedelta(seconds=120))
    n2 = [n.audience for n in db.scalars(select(AlertNotification).where(AlertNotification.alert_id == a2.id))]
    assert n2 == ["astronaut", "medical_officer"]


def test_critical_alert_downlinks_and_mission_control_copy_is_redacted(db):
    feed(db, [80] * 16)
    pkts = db.scalars(select(DownlinkPacket).order_by(DownlinkPacket.sequence_num)).all()
    dests = {p.destination for p in pkts}
    assert {"FLIGHT_SURGEON_SECURE", "MISSION_CONTROL"} <= dests
    mc = next(p for p in pkts if p.destination == "MISSION_CONTROL")
    assert "why" not in mc.payload and "trigger_value" not in mc.payload
    assert [p.sequence_num for p in pkts] == list(range(1, len(pkts) + 1))


def test_implausible_and_bad_units_rejected_not_stored(db):
    r = feed(db, [140], param="spo2")
    assert r.accepted == 0 and "implausible" in r.rejected[0]["reason"]
    r = feed(db, [36.6], param="core_temp", unit="furlongs")
    assert r.accepted == 0 and "cannot be converted" in r.rejected[0]["reason"]
    r = feed(db, [98.6], param="core_temp", unit="°F")
    assert r.accepted == 1
    assert abs(db.scalars(select(Observation)).first().value - 37.0) < 0.01


def test_audit_chain_detects_timestamp_tampering(db):
    audit.log_event(db, "a", "r", "first")
    audit.log_event(db, "a", "r", "second")
    assert audit.verify_chain(db)[0]
    from datetime import datetime, timezone
    from app.databases.models import AuditEntry
    e = db.scalars(select(AuditEntry)).first()
    e.timestamp = datetime(2000, 1, 1, tzinfo=timezone.utc)
    db.commit()
    ok, broken, _ = audit.verify_chain(db)
    assert not ok and broken == e.id
