from datetime import datetime, timedelta, timezone

from app.devices.simulator import SCENARIOS, Simulator
from conftest import token


def test_every_scenario_produces_labelled_catalogue_values():
    now = datetime.now(timezone.utc)
    for sc in SCENARIOS:
        sim = Simulator("ast-01", sc)
        for _ in range(40):
            rows = sim.step(now)
        assert {r["device_id"] for r in rows} == {"sim-01"}
    hyp = Simulator("ast-01", "hypoxia")
    spo2 = [next(r["value"] for r in hyp.step(now) if r["parameter"] == "spo2") for _ in range(50)]
    assert spo2[-1] < 85 < spo2[5]


def test_demo_controls_disabled_without_simulator(client):
    h = token(client, "admin")
    assert client.get("/api/v1/demo/state", headers=h).json()["enabled"] is False
    assert client.post("/api/v1/demo/reset", headers=h).status_code == 404


def test_crewmates_see_crew_escalated_emergency_without_physiology(client):
    from app.alerts.engine import escalation_tick
    from app.databases.session import SessionLocal
    gw = token(client, "gateway")
    t0 = datetime.now(timezone.utc) - timedelta(seconds=40)
    obs = [{"astronaut_id": "ast-01", "device_id": "dev-1", "parameter": "spo2", "value": 80, "unit": "%",
            "measured_at": (t0 + timedelta(seconds=i)).isoformat()} for i in range(17)]
    client.post("/api/v1/ingest/observations", headers=gw, json={"observations": obs})
    assert client.get("/api/v1/alerts/crew", headers=token(client, "lin")).json() == []
    with SessionLocal() as db:
        escalation_tick(db, datetime.now(timezone.utc) + timedelta(seconds=45))
    crew = client.get("/api/v1/alerts/crew", headers=token(client, "lin")).json()
    assert len(crew) == 1 and crew[0]["astronaut_name"] == "Cdr. Ines Varga"
    assert "why" not in crew[0] and "trigger_value" not in crew[0]
