from datetime import datetime, timezone

from conftest import token


def test_requests_without_token_are_rejected(client):
    assert client.get("/api/v1/crew").status_code == 401
    assert client.get("/api/v1/alerts").status_code == 401


def test_wrong_password_rejected(client):
    r = client.post("/api/v1/auth/login", data={"username": "varga", "password": "nope"})
    assert r.status_code == 401


def test_astronaut_sees_only_own_data(client):
    h = token(client, "varga")
    assert [c["id"] for c in client.get("/api/v1/crew", headers=h).json()] == ["ast-01"]
    assert client.get("/api/v1/vitals/latest?astronaut_id=ast-02", headers=h).status_code == 403


def test_no_fake_devices_or_vitals_are_seeded(client):
    h = token(client, "surgeon")
    devices = client.get("/api/v1/devices", headers=h).json()
    assert all(d["link"] == "NO_DATA" for d in devices)
    latest = client.get("/api/v1/vitals/latest?astronaut_id=ast-01", headers=h).json()
    assert all(m["status"] == "NO_DATA" for m in latest["metrics"].values())
    assert client.get("/api/v1/alerts", headers=h).json() == []


def _now():
    return datetime.now(timezone.utc).isoformat()


def test_ingest_validation_and_live_status(client):
    h = token(client, "gateway")
    body = {"observations": [
        {"astronaut_id": "ast-01", "device_id": "dev-1", "parameter": "spo2", "value": 97, "unit": "%",
         "measured_at": _now()},
        {"astronaut_id": "ast-01", "device_id": "nope", "parameter": "spo2", "value": 97, "unit": "%",
         "measured_at": _now()},
        {"astronaut_id": "ast-01", "device_id": "dev-1", "parameter": "spo2", "value": 97, "unit": "%",
         "measured_at": "2099-01-01T00:00:00+00:00"},
    ]}
    r = client.post("/api/v1/ingest/observations", json=body, headers=h).json()
    assert r["accepted"] == 1 and len(r["rejected"]) == 2
    bad = client.post("/api/v1/ingest/observations", headers=h, json={"observations": [
        {"astronaut_id": "ast-01", "device_id": "dev-1", "parameter": "made_up", "value": 1, "unit": "x",
         "measured_at": _now()}]})
    assert bad.status_code == 422
    assert client.get("/api/v1/vitals/latest?astronaut_id=ast-01", headers=h).status_code == 403
    m = client.get("/api/v1/vitals/latest?astronaut_id=ast-01", headers=token(client, "varga")).json()
    assert m["metrics"]["spo2"]["status"] == "LIVE" and m["metrics"]["spo2"]["value"] == 97


def test_ble_endpoint_decodes_standard_pulse_oximeter(client):
    h = token(client, "gateway")
    # PLX continuous: flags 0, SpO2 = 97 (0x0061), PR = 72 (0x0048)
    r = client.post("/api/v1/ingest/ble", headers=h, json={
        "device_id": "dev-1", "characteristic": "2A5F", "payload_hex": "0061004800"})
    assert r.status_code == 200 and r.json()["accepted"] == 2


def test_fhir_round_trip(client):
    h = token(client, "gateway")
    res = {"resourceType": "Observation", "code": {"coding": [{"system": "http://loinc.org", "code": "8867-4"}]},
           "valueQuantity": {"value": 64, "unit": "/min"}, "effectiveDateTime": _now()}
    r = client.post("/api/v1/ingest/fhir", headers=h, json={"astronaut_id": "ast-01", "device_id": "dev-1",
                                                           "resource": res})
    assert r.json()["accepted"] == 1
    b = client.get("/api/v1/fhir/Observation?astronaut_id=ast-01", headers=token(client, "surgeon")).json()
    codes = [c["code"] for c in b["entry"][0]["resource"]["code"]["coding"]]
    assert "8867-4" in codes


def test_mission_control_alert_view_is_redacted(client):
    from datetime import timedelta
    h = token(client, "gateway")
    t0 = datetime.now(timezone.utc) - timedelta(seconds=30)
    obs = [{"astronaut_id": "ast-01", "device_id": "dev-1", "parameter": "spo2", "value": 80, "unit": "%",
            "measured_at": (t0 + timedelta(seconds=i)).isoformat()} for i in range(17)]
    assert client.post("/api/v1/ingest/observations", headers=h, json={"observations": obs}).json()["alerts"]
    mc = client.get("/api/v1/alerts", headers=token(client, "mcc")).json()[0]
    assert mc["trigger_value"] is None and "restricted" in mc["why"][0]
    surgeon = client.get("/api/v1/alerts", headers=token(client, "surgeon")).json()[0]
    assert surgeon["trigger_value"] == 80
    # only the affected astronaut or medical roles may acknowledge
    assert client.post(f"/api/v1/alerts/{mc['id']}/acknowledge", headers=token(client, "lin")).status_code == 403
    ack = client.post(f"/api/v1/alerts/{mc['id']}/acknowledge", headers=token(client, "varga"))
    assert ack.json()["status"] == "ACKNOWLEDGED"


def test_websocket_requires_token(client):
    import pytest
    from starlette.websockets import WebSocketDisconnect
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect("/ws/telemetry") as ws:
            ws.receive_text()
    t = token(client, "varga")["Authorization"].split()[1]
    with client.websocket_connect(f"/ws/telemetry?token={t}") as ws:
        assert '"hello"' in ws.receive_text()
