import math

import numpy as np

from app.signal_processing.ecg import ECGProcessor
from app.signal_processing.hrv import HRVProcessor
from app.signal_processing.sqi import SignalQualityAssessor


def synth_ecg(hr=72, seconds=30, fs=250, noise=0.1, wander=0.3, seed=1):
    rng = np.random.default_rng(seed)
    t = np.arange(0, seconds, 1 / fs)
    period = 60 / hr
    ph = (t % period) / period
    v = (0.15 * np.exp(-((ph - 0.18) ** 2) / 0.001) - 0.18 * np.exp(-((ph - 0.35) ** 2) / 0.0003)
         + 1.25 * np.exp(-((ph - 0.38) ** 2) / 0.0002) - 0.28 * np.exp(-((ph - 0.41) ** 2) / 0.0004)
         + 0.28 * np.exp(-((ph - 0.62) ** 2) / 0.004))
    return v + wander * np.sin(2 * math.pi * 0.3 * t) + noise * rng.standard_normal(len(t))


def test_qrs_detection_robust_to_noise_and_baseline_wander():
    p = ECGProcessor(250)
    for hr in (48, 72, 120):
        peaks = p.pan_tompkins_qrs_detect(synth_ecg(hr=hr))
        expected = 30 * hr / 60
        assert abs(len(peaks) - expected) <= 2, (hr, len(peaks))
        assert abs(p.calculate_instantaneous_heart_rate(p.compute_rr_intervals(peaks)) - hr) < 3


def test_no_data_returns_none_not_zero():
    p = ECGProcessor(250)
    assert p.calculate_instantaneous_heart_rate(np.array([])) is None
    assert HRVProcessor.calculate_time_domain(np.array([800.0]))["rmssd"] is None


def test_hrv_time_domain():
    rr = np.array([800, 810, 790, 805, 795, 800], dtype=float)
    r = HRVProcessor.calculate_time_domain(rr)
    assert r["valid_count"] == 6 and 5 < r["rmssd"] < 20


def test_ppg_quality_distinguishes_pulse_from_noise():
    fs, t = 75, np.arange(0, 10, 1 / 75)
    clean = np.sin(2 * np.pi * 1.2 * t)
    noise = np.random.default_rng(0).standard_normal(len(t))
    assert SignalQualityAssessor.evaluate_ppg_quality(clean, fs)[0] == "GOOD"
    assert SignalQualityAssessor.evaluate_ppg_quality(noise, fs)[0] in ("POOR", "DEGRADED")
    assert SignalQualityAssessor.evaluate_ppg_quality(np.zeros(750), fs)[0] == "UNUSABLE"
