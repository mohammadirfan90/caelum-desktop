"""Tamper-evident, hash-chained audit log.

Each entry hashes (prev_hash, timestamp, actor, role, action, target, details) with
HMAC-SHA256 keyed by the server secret, so editing ANY field (including the timestamp)
or recomputing hashes without the key is detected. Writes are serialized with a lock.
"""
import hashlib
import hmac
import json
import threading
from datetime import datetime
from typing import Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config.settings import settings
from app.core_time import as_utc, utc_now
from app.databases.models import AuditEntry

GENESIS_HASH = "0" * 64
_lock = threading.Lock()


def _digest(prev: str, ts: datetime, actor: str, role: str, action: str,
            target: Optional[str], details: Optional[dict]) -> str:
    body = json.dumps([prev, as_utc(ts).isoformat(), actor, role, action, target or "",
                       details or {}], sort_keys=True, separators=(",", ":"), default=str)
    return hmac.new(settings.SECRET_KEY.encode(), body.encode(), hashlib.sha256).hexdigest()


def log_event(db: Session, actor: str, role: str, action: str, target_id: Optional[str] = None,
              details: Optional[dict] = None, commit: bool = True) -> AuditEntry:
    with _lock:
        last = db.scalars(select(AuditEntry).order_by(AuditEntry.id.desc()).limit(1)).first()
        prev = last.current_hash if last else GENESIS_HASH
        ts = utc_now()
        entry = AuditEntry(timestamp=ts, actor=actor, role=role, action=action, target_id=target_id,
                           details=details, prev_hash=prev,
                           current_hash=_digest(prev, ts, actor, role, action, target_id, details))
        db.add(entry)
        if commit:
            db.commit()
        else:
            db.flush()
        return entry


def verify_chain(db: Session) -> tuple[bool, Optional[int], list[dict]]:
    expected_prev, broken, out = GENESIS_HASH, None, []
    for e in db.scalars(select(AuditEntry).order_by(AuditEntry.id.asc())):
        ok = e.prev_hash == expected_prev and hmac.compare_digest(
            e.current_hash,
            _digest(e.prev_hash, e.timestamp, e.actor, e.role, e.action, e.target_id, e.details))
        if not ok and broken is None:
            broken = e.id
        out.append({"id": e.id, "timestamp": as_utc(e.timestamp).isoformat(), "actor": e.actor,
                    "role": e.role, "action": e.action, "target_id": e.target_id,
                    "details": e.details, "prev_hash": e.prev_hash,
                    "current_hash": e.current_hash, "valid": ok})
        expected_prev = e.current_hash
    return broken is None, broken, out
