"""Runtime configuration. All values come from environment variables prefixed CAELUM_."""
import secrets
import warnings
from functools import lru_cache
from typing import Literal

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

Profile = Literal["local_dev", "test", "onboard", "ground"]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="CAELUM_", env_file=".env", extra="ignore")

    PROJECT_NAME: str = "CAELUM Crew Health Monitor"
    VERSION: str = "3.1.0"
    API_V1_STR: str = "/api/v1"
    PROFILE: Profile = "local_dev"

    # Security: no default secret. Dev/test get an ephemeral random key; onboard/ground must set one.
    SECRET_KEY: str = ""
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 12 * 60
    DEV_PASSWORD: str = "caelum-dev"  # used ONLY to seed demo users in local_dev/test

    DATABASE_URL: str = "sqlite:///./caelum_onboard.db"
    CORS_ORIGINS: list[str] = ["http://localhost:3000", "http://127.0.0.1:3000"]

    # Simulator is a clearly-labelled data source; never enabled implicitly outside local_dev.
    ENABLE_SIMULATOR: bool = False
    SIMULATOR_SCENARIO: str = "normal"
    # Demo timing (local_dev only): multiplies long persistence/clear windows so slow rules
    # (fever, AF, CO2) can be shown in a pitch. Always reported in /health and in the UI.
    DEMO_TIME_SCALE: float = 1.0
    ESCALATION_TICK_S: float = 1.0
    STALE_AFTER_S: float = 30.0  # latest value older than this is reported STALE

    @property
    def is_dev(self) -> bool:
        return self.PROFILE in ("local_dev", "test")

    @property
    def time_scale(self) -> float:
        return self.DEMO_TIME_SCALE if self.is_dev else 1.0

    @model_validator(mode="after")
    def _check_secret(self) -> "Settings":
        if not self.SECRET_KEY:
            if not self.is_dev:
                raise ValueError("CAELUM_SECRET_KEY must be set for onboard/ground profiles")
            self.SECRET_KEY = secrets.token_urlsafe(48)
            warnings.warn("CAELUM_SECRET_KEY not set: using an ephemeral dev key", stacklevel=2)
        elif len(self.SECRET_KEY) < 32:
            raise ValueError("CAELUM_SECRET_KEY must be at least 32 characters")
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
