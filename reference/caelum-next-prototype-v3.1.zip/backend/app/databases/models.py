"""Persistent data model. Every measurement carries provenance (device, time, quality, simulated)."""
import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.databases.session import Base


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:16]}"


class Astronaut(Base):
    __tablename__ = "astronauts"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(128))
    initials: Mapped[str] = mapped_column(String(8))
    role: Mapped[str] = mapped_column(String(64))
    mission: Mapped[str] = mapped_column(String(128))
    crew: Mapped[str] = mapped_column(String(64))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class User(Base):
    __tablename__ = "users"
    username: Mapped[str] = mapped_column(String(64), primary_key=True)
    full_name: Mapped[str] = mapped_column(String(128))
    role: Mapped[str] = mapped_column(String(32))
    hashed_password: Mapped[str] = mapped_column(String(128))
    astronaut_id: Mapped[Optional[str]] = mapped_column(ForeignKey("astronauts.id"), nullable=True)
    disabled: Mapped[bool] = mapped_column(Boolean, default=False)


class Device(Base):
    __tablename__ = "devices"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(128))
    category: Mapped[str] = mapped_column(String(64))  # wearable, clinical, imaging, vehicle_bridge
    adapter: Mapped[str] = mapped_column(String(64))  # ble_standard, simulator, fhir, ...
    model: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    vendor: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    serial: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    firmware: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    accuracy_class: Mapped[str] = mapped_column(String(32), default="wearable")  # clinical|wearable|estimate
    calibration_due: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    is_simulated: Mapped[bool] = mapped_column(Boolean, default=False)
    astronaut_id: Mapped[Optional[str]] = mapped_column(ForeignKey("astronauts.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(32), default="DISCONNECTED")
    battery_level: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    last_seen: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)


class Observation(Base):
    __tablename__ = "observations"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    astronaut_id: Mapped[str] = mapped_column(ForeignKey("astronauts.id"), index=True)
    device_id: Mapped[str] = mapped_column(ForeignKey("devices.id"), index=True)
    parameter: Mapped[str] = mapped_column(String(64), index=True)
    value: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(32))
    measured_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    quality: Mapped[str] = mapped_column(String(16), default="GOOD")
    classification: Mapped[str] = mapped_column(String(16), default="measured")
    simulated: Mapped[bool] = mapped_column(Boolean, default=False)
    context: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    __table_args__ = (Index("ix_obs_astro_param_time", "astronaut_id", "parameter", "measured_at"),)


class Baseline(Base):
    __tablename__ = "baselines"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    astronaut_id: Mapped[str] = mapped_column(ForeignKey("astronauts.id"), index=True)
    parameter: Mapped[str] = mapped_column(String(64))
    median: Mapped[float] = mapped_column(Float)
    mad: Mapped[float] = mapped_column(Float)
    n: Mapped[int] = mapped_column(Integer)
    window_days: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(32))  # VALID | INSUFFICIENT_DATA
    method: Mapped[str] = mapped_column(String(64), default="median/MAD, quality GOOD|DEGRADED")
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class Alert(Base):
    __tablename__ = "alerts"
    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("alt"))
    astronaut_id: Mapped[str] = mapped_column(ForeignKey("astronauts.id"), index=True)
    rule_id: Mapped[str] = mapped_column(String(64), index=True)
    rule_version: Mapped[str] = mapped_column(String(32))
    parameter: Mapped[str] = mapped_column(String(64))
    module: Mapped[str] = mapped_column(String(32))
    level: Mapped[str] = mapped_column(String(16))  # observe | warning | critical | advisory
    title: Mapped[str] = mapped_column(String(256))
    why: Mapped[list] = mapped_column(JSON, default=list)
    action: Mapped[str] = mapped_column(Text, default="")
    trigger_value: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    sources: Mapped[list] = mapped_column(JSON, default=list)
    simulated: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(16), default="ACTIVE", index=True)
    # ACTIVE -> ACKNOWLEDGED -> RESOLVED ; ACTIVE -> SUPERSEDED
    escalation_stage: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    acknowledged_by: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    acknowledged_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)


class AlertNotification(Base):
    __tablename__ = "alert_notifications"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    alert_id: Mapped[str] = mapped_column(ForeignKey("alerts.id"), index=True)
    audience: Mapped[str] = mapped_column(String(32))  # astronaut|medical_officer|crew|ground|sound
    stage: Mapped[int] = mapped_column(Integer)
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class AuditEntry(Base):
    __tablename__ = "audit_entries"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    actor: Mapped[str] = mapped_column(String(64))
    role: Mapped[str] = mapped_column(String(64))
    action: Mapped[str] = mapped_column(String(256))
    target_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    details: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    prev_hash: Mapped[str] = mapped_column(String(64))
    current_hash: Mapped[str] = mapped_column(String(64))


class DownlinkPacket(Base):
    __tablename__ = "downlink_packets"
    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("pkt"))
    sequence_num: Mapped[int] = mapped_column(Integer, unique=True)
    priority: Mapped[str] = mapped_column(String(32), default="ROUTINE")
    destination: Mapped[str] = mapped_column(String(64), default="MISSION_CONTROL")
    payload: Mapped[dict] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(32), default="QUEUED")
    retry_count: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    sent_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)


class MedicalRecord(Base):
    __tablename__ = "medical_records"
    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("rec"))
    astronaut_id: Mapped[str] = mapped_column(ForeignKey("astronauts.id"), index=True)
    record_type: Mapped[str] = mapped_column(String(64))
    title: Mapped[str] = mapped_column(String(256))
    data: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
