"""Single ingestion path for every data source: validate -> normalize -> store -> evaluate -> publish.

No default values are ever substituted for missing data. Implausible values are rejected with
a reason (they usually indicate a sensor fault) and reported back to the caller.
"""
import math
from datetime import datetime, timedelta
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, field_validator
from sqlalchemy.orm import Session

from app.alerts.engine import alert_payload, engine
from app.baselines.engine import get as get_baseline
from app.core_time import as_utc, utc_now
from app.databases.models import Astronaut, Device, Observation
from app.domain.parameters import PARAMETERS, to_canonical
from app.realtime.bus import bus

Quality = Literal["GOOD", "DEGRADED", "POOR", "UNUSABLE"]


class ObservationIn(BaseModel):
    astronaut_id: str
    device_id: str
    parameter: str
    value: float
    unit: str
    measured_at: datetime
    quality: Quality = "GOOD"
    classification: Literal["measured", "estimated", "derived"] = "measured"
    context: Optional[dict[str, Any]] = None

    @field_validator("parameter")
    @classmethod
    def _known(cls, v: str) -> str:
        if v not in PARAMETERS:
            raise ValueError(f"unknown parameter '{v}'")
        return v

    @field_validator("value")
    @classmethod
    def _finite(cls, v: float) -> float:
        if not math.isfinite(v):
            raise ValueError("value must be finite")
        return v

    @field_validator("measured_at")
    @classmethod
    def _tz(cls, v: datetime) -> datetime:
        if v.tzinfo is None:
            raise ValueError("measured_at must include a timezone (use UTC)")
        return as_utc(v)


class IngestResult(BaseModel):
    accepted: int = 0
    rejected: list[dict[str, Any]] = Field(default_factory=list)
    alerts: list[dict[str, Any]] = Field(default_factory=list)


def ingest(db: Session, items: list[ObservationIn]) -> IngestResult:
    res = IngestResult()
    now = utc_now()
    for i, item in enumerate(sorted(items, key=lambda x: x.measured_at)):
        reason = _reject_reason(db, item, now)
        if reason:
            res.rejected.append({"index": i, "parameter": item.parameter, "reason": reason})
            continue
        device = db.get(Device, item.device_id)
        spec = PARAMETERS[item.parameter]
        try:
            value = to_canonical(item.parameter, item.value, item.unit)
        except ValueError as exc:
            res.rejected.append({"index": i, "parameter": item.parameter, "reason": str(exc)})
            continue
        lo, hi = spec.plausible
        if not lo <= value <= hi:
            res.rejected.append({"index": i, "parameter": item.parameter,
                                 "reason": f"implausible value {value:g} {spec.unit} (sensor fault?)"})
            continue
        obs = Observation(astronaut_id=item.astronaut_id, device_id=item.device_id,
                          parameter=item.parameter, value=value, unit=spec.unit,
                          measured_at=item.measured_at, received_at=now, quality=item.quality,
                          classification=item.classification, simulated=device.is_simulated,
                          context=item.context)
        db.add(obs)
        device.last_seen, device.status = now, "STREAMING"
        db.commit()
        res.accepted += 1
        bus.publish({"type": "observation", "astronaut_id": obs.astronaut_id,
                     "parameter": obs.parameter, "value": obs.value, "unit": obs.unit,
                     "measured_at": obs.measured_at.isoformat(), "quality": obs.quality,
                     "device_id": obs.device_id, "simulated": obs.simulated})
        for alert in engine.evaluate(db, obs, get_baseline(db, obs.astronaut_id, obs.parameter)):
            payload = alert_payload(alert)
            res.alerts.append(payload)
            bus.publish(payload)
    return res


def _reject_reason(db: Session, item: ObservationIn, now: datetime) -> Optional[str]:
    if db.get(Astronaut, item.astronaut_id) is None:
        return "unknown astronaut"
    device = db.get(Device, item.device_id)
    if device is None:
        return "unregistered device (register it first)"
    if device.astronaut_id and device.astronaut_id != item.astronaut_id:
        return "device is assigned to a different astronaut"
    if item.measured_at > now + timedelta(seconds=5):
        return "timestamp in the future (check device clock sync)"
    return None
