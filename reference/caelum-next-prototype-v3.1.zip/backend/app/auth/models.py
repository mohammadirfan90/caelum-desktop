from enum import Enum
from typing import Optional

from pydantic import BaseModel


class Role(str, Enum):
    ASTRONAUT = "Astronaut"
    MEDICAL_OFFICER = "Medical Officer"  # crew medical officer onboard
    FLIGHT_SURGEON = "Flight Surgeon"  # ground, full medical access
    MISSION_CONTROL = "Mission Control"  # ground ops, operational status only
    DEVICE_GATEWAY = "Device Gateway"  # machine identity allowed to ingest data
    ADMINISTRATOR = "Administrator"


MEDICAL_ROLES = {Role.MEDICAL_OFFICER, Role.FLIGHT_SURGEON, Role.ADMINISTRATOR}


class CurrentUser(BaseModel):
    username: str
    full_name: str
    role: Role
    astronaut_id: Optional[str] = None
