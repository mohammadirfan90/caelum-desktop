from typing import Iterable, Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.auth.models import MEDICAL_ROLES, CurrentUser, Role
from app.auth.security import decode_access_token
from app.databases.models import User
from app.databases.session import get_db

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)

_UNAUTH = HTTPException(status.HTTP_401_UNAUTHORIZED, "Not authenticated",
                        headers={"WWW-Authenticate": "Bearer"})


def user_from_token(token: Optional[str], db: Session) -> CurrentUser:
    if not token:
        raise _UNAUTH
    payload = decode_access_token(token)
    if not payload:
        raise _UNAUTH
    user = db.get(User, payload["sub"])
    if not user or user.disabled:
        raise _UNAUTH
    return CurrentUser(username=user.username, full_name=user.full_name, role=Role(user.role),
                       astronaut_id=user.astronaut_id)


def get_current_user(token: Optional[str] = Depends(oauth2_scheme),
                     db: Session = Depends(get_db)) -> CurrentUser:
    return user_from_token(token, db)


def require_roles(*roles: Role):
    allowed = set(roles)

    def checker(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if user.role not in allowed:
            raise HTTPException(status.HTTP_403_FORBIDDEN,
                                f"Requires one of: {sorted(r.value for r in allowed)}")
        return user
    return checker


def ensure_can_read_astronaut(user: CurrentUser, astronaut_id: str) -> None:
    """Astronauts see only themselves; medical roles and mission control see all crew."""
    if user.role == Role.ASTRONAUT and user.astronaut_id != astronaut_id:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Astronauts may only access their own data")
    if user.role == Role.DEVICE_GATEWAY:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Device identities cannot read health data")


def is_medical(user: CurrentUser) -> bool:
    return user.role in MEDICAL_ROLES


def any_role(user: CurrentUser, roles: Iterable[Role]) -> bool:
    return user.role in set(roles)
