from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.alerts import engine as alert_engine
from app.auth.dependencies import ensure_can_read_astronaut, get_current_user, is_medical
from app.auth.models import CurrentUser, Role
from app.databases.models import Alert, AlertNotification, Astronaut
from app.databases.session import get_db
from app.realtime.bus import bus

router = APIRouter(prefix="/alerts")


class AlertOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    astronaut_id: str
    rule_id: str
    rule_version: str
    parameter: str
    module: str
    level: str
    title: str
    why: list[str]
    action: str
    trigger_value: Optional[float]
    sources: list[dict]
    simulated: bool
    status: str
    escalation_stage: int
    created_at: datetime
    acknowledged_by: Optional[str]
    acknowledged_at: Optional[datetime]
    resolved_at: Optional[datetime]


def _redact(a: Alert, user: CurrentUser) -> AlertOut:
    out = AlertOut.model_validate(a)
    if user.role == Role.MISSION_CONTROL:  # operational view: status only, no physiology
        out.why, out.trigger_value, out.action = ["Medical details restricted to medical roles."], None, ""
    return out


@router.get("", response_model=list[AlertOut])
def list_alerts(status: Optional[str] = None, astronaut_id: Optional[str] = None,
                user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == Role.ASTRONAUT:
        astronaut_id = user.astronaut_id
    elif astronaut_id:
        ensure_can_read_astronaut(user, astronaut_id)
    q = select(Alert).order_by(Alert.created_at.desc()).limit(500)
    if status:
        q = q.where(Alert.status == status.upper())
    if astronaut_id:
        q = q.where(Alert.astronaut_id == astronaut_id)
    return [_redact(a, user) for a in db.scalars(q).all()]


@router.get("/crew")
def crew_emergencies(user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_db)):
    """Open alerts that have escalated to the whole crew. Visible to every crew member, so a
    crewmate can respond when the affected astronaut cannot. Physiology details are omitted."""
    if user.role == Role.DEVICE_GATEWAY:
        raise HTTPException(403, "Device identities cannot read alerts")
    crew_alert_ids = set(db.scalars(select(AlertNotification.alert_id).where(
        AlertNotification.audience == "crew")).all())
    rows = db.scalars(select(Alert).where(Alert.status == "ACTIVE", Alert.id.in_(crew_alert_ids))
                      .order_by(Alert.created_at.desc())).all()
    names = {a.id: a.name for a in db.scalars(select(Astronaut)).all()}
    return [{"id": a.id, "astronaut_id": a.astronaut_id, "astronaut_name": names.get(a.astronaut_id),
             "level": a.level, "title": a.title, "action": a.action, "created_at": a.created_at,
             "simulated": a.simulated} for a in rows]


@router.post("/{alert_id}/acknowledge", response_model=AlertOut)
def acknowledge(alert_id: str, user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_db)):
    a = db.get(Alert, alert_id)
    if not a:
        raise HTTPException(404, "Alert not found")
    own = user.role == Role.ASTRONAUT and user.astronaut_id == a.astronaut_id
    if not (own or is_medical(user)):
        raise HTTPException(403, "Only the affected astronaut or a medical role can acknowledge")
    alert_engine.acknowledge(db, a, user.username, user.role.value)
    bus.publish(alert_engine.alert_payload(a))
    return _redact(a, user)


@router.get("/{alert_id}/notifications")
def notifications(alert_id: str, user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_db)):
    a = db.get(Alert, alert_id)
    if not a:
        raise HTTPException(404, "Alert not found")
    ensure_can_read_astronaut(user, a.astronaut_id)
    rows = db.scalars(select(AlertNotification).where(AlertNotification.alert_id == alert_id)
                      .order_by(AlertNotification.stage)).all()
    return [{"audience": n.audience, "stage": n.stage, "at": n.at} for n in rows]
