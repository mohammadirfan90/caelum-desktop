"""Live event stream. Clients authenticate with ?token=<JWT>; events are filtered per role."""
import asyncio
import json

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, status

from app.auth.dependencies import user_from_token
from app.auth.models import Role
from app.databases.session import SessionLocal
from app.realtime.bus import bus

router = APIRouter()


@router.websocket("/ws/telemetry")
async def telemetry(ws: WebSocket):
    token = ws.query_params.get("token")
    db = SessionLocal()
    try:
        user = user_from_token(token, db)
    except Exception:
        await ws.close(code=status.WS_1008_POLICY_VIOLATION)
        return
    finally:
        db.close()
    if user.role == Role.DEVICE_GATEWAY:
        await ws.close(code=status.WS_1008_POLICY_VIOLATION)
        return
    await ws.accept()
    q = bus.subscribe()
    try:
        await ws.send_text(json.dumps({"type": "hello", "user": user.username, "role": user.role.value}))
        while True:
            try:
                ev = await asyncio.wait_for(q.get(), timeout=5.0)
            except asyncio.TimeoutError:
                await ws.send_text(json.dumps({"type": "heartbeat"}))
                continue
            if user.role == Role.ASTRONAUT and ev.get("astronaut_id") != user.astronaut_id:
                # crewmates are told only that a crew-wide escalation happened (no physiology)
                if not (ev.get("type") == "escalation" and ev.get("audience") == "crew") and ev.get("type") != "demo":
                    continue
            if user.role == Role.MISSION_CONTROL:
                if ev.get("type") == "observation":
                    continue
                ev = {k: ev[k] for k in ("type", "alert_id", "astronaut_id", "level", "status",
                                         "module", "created_at", "simulated") if k in ev}
            await ws.send_text(json.dumps(ev, default=str))
    except WebSocketDisconnect:
        pass
    finally:
        bus.unsubscribe(q)
