from fastapi import APIRouter

from app.api.v1 import alerts, audit, auth, crew, demo, devices, health, ingest, interop, models, vitals

api_router = APIRouter()
for module, tag in [(health, "Health"), (auth, "Auth"), (crew, "Crew"), (devices, "Devices"),
                    (ingest, "Ingestion"), (vitals, "Vitals"), (alerts, "Alerts"), (audit, "Audit"),
                    (interop, "Interoperability"), (models, "Models"), (demo, "Demo")]:
    api_router.include_router(module.router, tags=[tag])
