from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user, require_roles
from app.auth.models import CurrentUser, Role
from app.config.settings import settings
from app.core_time import as_utc, utc_now
from app.databases.models import Device
from app.databases.session import get_db
from app.devices.registry import ADAPTERS
from app.medical import audit

router = APIRouter(prefix="/devices")


class DeviceIn(BaseModel):
    id: str
    name: str
    category: str
    adapter: str
    model: Optional[str] = None
    vendor: Optional[str] = None
    serial: Optional[str] = None
    firmware: Optional[str] = None
    accuracy_class: str = "wearable"
    calibration_due: Optional[datetime] = None
    astronaut_id: Optional[str] = None


class DeviceOut(DeviceIn):
    model_config = ConfigDict(from_attributes=True)
    is_simulated: bool
    status: str
    battery_level: Optional[float] = None
    last_seen: Optional[datetime] = None
    link: str = "NO_DATA"


def _out(d: Device) -> DeviceOut:
    out = DeviceOut.model_validate(d)
    if d.last_seen is None:
        out.link = "NO_DATA"
    else:
        age = (utc_now() - as_utc(d.last_seen)).total_seconds()
        out.link = "LIVE" if age <= settings.STALE_AFTER_S else "STALE"
    return out


@router.get("", response_model=list[DeviceOut])
def list_devices(_: CurrentUser = Depends(get_current_user), db: Session = Depends(get_db)):
    return [_out(d) for d in db.scalars(select(Device)).all()]


@router.get("/adapters")
def list_adapters(_: CurrentUser = Depends(get_current_user)):
    return ADAPTERS


@router.post("", response_model=DeviceOut, status_code=201)
def register_device(body: DeviceIn, user: CurrentUser = Depends(
        require_roles(Role.ADMINISTRATOR, Role.MEDICAL_OFFICER)), db: Session = Depends(get_db)):
    if body.adapter not in {a["id"] for a in ADAPTERS}:
        raise HTTPException(422, f"unknown adapter '{body.adapter}'")
    if body.adapter == "simulator":
        raise HTTPException(422, "simulator devices are created by the server only")
    if db.get(Device, body.id):
        raise HTTPException(409, "device id already registered")
    d = Device(**body.model_dump(), is_simulated=False)
    db.add(d)
    audit.log_event(db, user.username, user.role.value, f"Device registered: {body.name}", body.id,
                    commit=False)
    db.commit()
    return _out(d)
