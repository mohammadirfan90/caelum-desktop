from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.auth.dependencies import ensure_can_read_astronaut, get_current_user, require_roles
from app.auth.models import CurrentUser, Role
from app.baselines import engine as baselines
from app.config.settings import settings
from app.core_time import as_utc, utc_now
from app.databases.models import Observation
from app.databases.session import get_db
from app.domain.parameters import PARAMETERS

router = APIRouter(prefix="/vitals")


@router.get("/parameters")
def parameters(_: CurrentUser = Depends(get_current_user)):
    return [p.__dict__ for p in PARAMETERS.values()]


@router.get("/latest")
def latest(astronaut_id: str, user: CurrentUser = Depends(get_current_user),
           db: Session = Depends(get_db)):
    ensure_can_read_astronaut(user, astronaut_id)
    now, out = utc_now(), {}
    for key, spec in PARAMETERS.items():
        o = db.scalars(select(Observation).where(Observation.astronaut_id == astronaut_id,
                                                 Observation.parameter == key)
                       .order_by(Observation.measured_at.desc()).limit(1)).first()
        if o is None:
            out[key] = {"status": "NO_DATA", "label": spec.label, "unit": spec.unit}
            continue
        age = (now - as_utc(o.measured_at)).total_seconds()
        out[key] = {"status": "LIVE" if age <= settings.STALE_AFTER_S else "STALE",
                    "age_s": round(age, 1), "value": o.value, "unit": o.unit, "label": spec.label,
                    "measured_at": as_utc(o.measured_at).isoformat(), "quality": o.quality,
                    "classification": o.classification, "device_id": o.device_id,
                    "simulated": o.simulated}
    return {"astronaut_id": astronaut_id, "server_time": now.isoformat(), "metrics": out}


@router.get("/history")
def history(astronaut_id: str, parameter: str, minutes: int = Query(60, ge=1, le=60 * 24 * 30),
            user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_db)):
    ensure_can_read_astronaut(user, astronaut_id)
    if parameter not in PARAMETERS:
        raise HTTPException(422, "unknown parameter")
    since = utc_now() - timedelta(minutes=minutes)
    rows = db.scalars(select(Observation).where(
        Observation.astronaut_id == astronaut_id, Observation.parameter == parameter,
        Observation.measured_at >= since).order_by(Observation.measured_at).limit(20000)).all()
    return {"parameter": parameter, "unit": PARAMETERS[parameter].unit,
            "points": [{"t": as_utc(o.measured_at).isoformat(), "v": o.value, "q": o.quality,
                        "sim": o.simulated} for o in rows]}


@router.get("/baselines")
def get_baselines(astronaut_id: str, user: CurrentUser = Depends(get_current_user),
                  db: Session = Depends(get_db)):
    ensure_can_read_astronaut(user, astronaut_id)
    out = []
    for key in PARAMETERS:
        b = baselines.get(db, astronaut_id, key)
        out.append({"parameter": key, "label": PARAMETERS[key].label, "unit": PARAMETERS[key].unit,
                    "status": b.status if b else "INSUFFICIENT_DATA", "median": b.median if b else None,
                    "mad": b.mad if b else None, "n": b.n if b else 0,
                    "required_n": baselines.MIN_SAMPLES})
    return out


@router.post("/baselines/recompute")
def recompute(astronaut_id: str, window_days: int = Query(14, ge=1, le=120),
              _: CurrentUser = Depends(require_roles(Role.MEDICAL_OFFICER, Role.FLIGHT_SURGEON,
                                                     Role.ADMINISTRATOR)),
              db: Session = Depends(get_db)):
    return [{"parameter": k, "status": b.status, "n": b.n}
            for k in PARAMETERS for b in [baselines.recompute(db, astronaut_id, k, window_days)]]
