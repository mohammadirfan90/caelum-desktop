"""Presenter controls for demonstrations. Available only in local_dev with the simulator on."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import delete
from sqlalchemy.orm import Session

from app.alerts import engine as alert_engine
from app.auth.dependencies import get_current_user
from app.auth.models import CurrentUser
from app.config.settings import settings
from app.databases.models import Alert, AlertNotification, Baseline, DownlinkPacket, Observation
from app.databases.session import get_db
from app.devices.simulator import SCENARIOS, fleet
from app.medical import audit
from app.realtime.bus import bus

router = APIRouter(prefix="/demo")


def _enabled():
    if not (settings.is_dev and settings.ENABLE_SIMULATOR):
        raise HTTPException(404, "Demo controls are disabled (local_dev + simulator only)")


@router.get("/state")
def state(_: CurrentUser = Depends(get_current_user)):
    enabled = settings.is_dev and settings.ENABLE_SIMULATOR
    return {"enabled": enabled, "time_scale": settings.time_scale, "crew": fleet.state(),
            "scenarios": [{"id": k, "label": v[0], "description": v[1], "expect": v[2]}
                          for k, v in SCENARIOS.items()]}


class ScenarioIn(BaseModel):
    astronaut_id: str
    scenario: str


@router.post("/scenario")
def set_scenario(body: ScenarioIn, user: CurrentUser = Depends(get_current_user),
                 db: Session = Depends(get_db)):
    _enabled()
    sim = fleet.sims.get(body.astronaut_id)
    if sim is None:
        raise HTTPException(404, "No simulator for this astronaut")
    try:
        sim.set_scenario(body.scenario)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    audit.log_event(db, user.username, user.role.value, f"Demo scenario set: {body.scenario}",
                    body.astronaut_id)
    bus.publish({"type": "demo", "astronaut_id": body.astronaut_id, "scenario": body.scenario})
    return fleet.state()


@router.post("/reset")
def reset(user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_db)):
    _enabled()
    for model in (AlertNotification, Alert, DownlinkPacket, Observation, Baseline):
        db.execute(delete(model))
    db.commit()
    alert_engine.engine.reset()
    for sim in fleet.sims.values():
        sim.set_scenario("normal")
    audit.log_event(db, user.username, user.role.value, "Demo reset: data cleared")
    bus.publish({"type": "demo", "scenario": "reset"})
    return fleet.state()
