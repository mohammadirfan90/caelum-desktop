from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.auth.dependencies import ensure_can_read_astronaut, get_current_user
from app.auth.models import CurrentUser, Role
from app.databases.models import Astronaut
from app.databases.session import get_db

router = APIRouter(prefix="/crew")


class AstronautOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    initials: str
    role: str
    mission: str
    crew: str


@router.get("", response_model=list[AstronautOut])
def list_crew(user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Astronaut).where(Astronaut.is_active.is_(True))).all()
    if user.role == Role.ASTRONAUT:
        rows = [r for r in rows if r.id == user.astronaut_id]
    return rows


@router.get("/{astronaut_id}", response_model=AstronautOut)
def get_member(astronaut_id: str, user: CurrentUser = Depends(get_current_user),
               db: Session = Depends(get_db)):
    ensure_can_read_astronaut(user, astronaut_id)
    a = db.get(Astronaut, astronaut_id)
    if not a:
        raise HTTPException(404, "Astronaut not found")
    return a
