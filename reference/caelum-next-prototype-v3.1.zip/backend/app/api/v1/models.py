from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from app.auth.dependencies import get_current_user
from app.auth.models import CurrentUser
from app.ml.inference import MODELS, fatigue_heuristic

router = APIRouter(prefix="/models")


class FatigueIn(BaseModel):
    sleep_duration_hours: float = Field(ge=0, le=24)
    hrv_rmssd: float = Field(gt=0, le=300)
    reaction_time_ms: float = Field(gt=0, le=5000)


@router.get("")
def list_models(_: CurrentUser = Depends(get_current_user)):
    return MODELS


@router.post("/fatigue")
def fatigue(body: FatigueIn, _: CurrentUser = Depends(get_current_user)):
    return fatigue_heuristic(body.sleep_duration_hours, body.hrv_rmssd, body.reaction_time_ms)
