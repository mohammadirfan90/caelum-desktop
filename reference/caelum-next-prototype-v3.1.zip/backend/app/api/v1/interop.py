import sys
from pathlib import Path

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.auth.dependencies import ensure_can_read_astronaut, get_current_user, require_roles
from app.auth.models import CurrentUser, Role
from app.communications import queue as downlink
from app.databases.models import Device, Observation
from app.databases.session import get_db

sys.path.insert(0, str(Path(__file__).resolve().parents[4]))
from interoperability.fhir.adapter import FHIRAdapter  # noqa: E402
from interoperability.ground.openmct_provider import dictionary  # noqa: E402

router = APIRouter()


@router.get("/fhir/Observation")
def fhir_observations(astronaut_id: str, parameter: str | None = None, limit: int = Query(100, le=1000),
                      user: CurrentUser = Depends(require_roles(Role.MEDICAL_OFFICER, Role.FLIGHT_SURGEON,
                                                                Role.ADMINISTRATOR)),
                      db: Session = Depends(get_db)):
    ensure_can_read_astronaut(user, astronaut_id)
    q = select(Observation).where(Observation.astronaut_id == astronaut_id)
    if parameter:
        q = q.where(Observation.parameter == parameter)
    rows = db.scalars(q.order_by(Observation.measured_at.desc()).limit(limit)).all()
    devices = {d.id: d for d in db.scalars(select(Device)).all()}
    return FHIRAdapter.bundle([FHIRAdapter.observation(o, devices.get(o.device_id)) for o in rows])


@router.get("/downlink/queue")
def downlink_queue(_: CurrentUser = Depends(require_roles(Role.FLIGHT_SURGEON, Role.MISSION_CONTROL,
                                                          Role.ADMINISTRATOR)),
                   db: Session = Depends(get_db)):
    return [{"id": p.id, "seq": p.sequence_num, "priority": p.priority, "destination": p.destination,
             "status": p.status, "created_at": p.created_at, "payload": p.payload}
            for p in downlink.pending(db, 200)]


@router.get("/openmct/dictionary")
def openmct_dictionary(_: CurrentUser = Depends(get_current_user)):
    return dictionary()
