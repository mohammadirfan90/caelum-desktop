from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user
from app.auth.models import CurrentUser
from app.auth.security import create_access_token, verify_password
from app.databases.models import User
from app.databases.session import get_db
from app.medical import audit

router = APIRouter(prefix="/auth")


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: CurrentUser


@router.post("/login", response_model=TokenOut)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.get(User, form.username)
    if not user or user.disabled or not verify_password(form.password, user.hashed_password):
        audit.log_event(db, form.username[:64], "unknown", "Failed login")
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect username or password")
    audit.log_event(db, user.username, user.role, "Login")
    cu = CurrentUser(username=user.username, full_name=user.full_name, role=user.role,
                     astronaut_id=user.astronaut_id)
    return TokenOut(access_token=create_access_token(user.username, user.role), user=cu)


@router.get("/me", response_model=CurrentUser)
def me(user: CurrentUser = Depends(get_current_user)):
    return user
