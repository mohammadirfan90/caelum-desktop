from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.auth.dependencies import require_roles
from app.auth.models import CurrentUser, Role
from app.core_time import utc_now
from app.databases.models import Device
from app.databases.session import get_db
from app.devices import ble_health
from app.devices.fhir_import import observation_to_items
from app.ingestion.pipeline import IngestResult, ObservationIn, ingest

router = APIRouter(prefix="/ingest")
ingestors = require_roles(Role.DEVICE_GATEWAY, Role.ADMINISTRATOR, Role.MEDICAL_OFFICER)


class Batch(BaseModel):
    observations: list[ObservationIn] = Field(max_length=2000)


@router.post("/observations", response_model=IngestResult)
def ingest_observations(body: Batch, _: CurrentUser = Depends(ingestors), db: Session = Depends(get_db)):
    return ingest(db, body.observations)


class BlePayload(BaseModel):
    device_id: str
    characteristic: str  # e.g. "2A5F" or full SIG UUID
    payload_hex: str
    received_at: Optional[datetime] = None


@router.post("/ble", response_model=IngestResult)
def ingest_ble(body: BlePayload, _: CurrentUser = Depends(ingestors), db: Session = Depends(get_db)):
    device = db.get(Device, body.device_id)
    if not device or device.adapter != "ble_standard":
        raise HTTPException(422, "device not registered with adapter 'ble_standard'")
    if not device.astronaut_id:
        raise HTTPException(422, "device must be assigned to an astronaut")
    try:
        readings = ble_health.decode(body.characteristic, bytes.fromhex(body.payload_hex))
    except (ValueError, IndexError) as exc:
        raise HTTPException(422, f"cannot decode payload: {exc}") from exc
    when = body.received_at or utc_now()
    items = [ObservationIn(astronaut_id=device.astronaut_id, device_id=device.id,
                           parameter=r.parameter, value=r.value, unit=r.unit,
                           measured_at=r.measured_at or when, quality=r.quality,
                           context=r.context or None) for r in readings]
    return ingest(db, items)


class FhirPayload(BaseModel):
    astronaut_id: str
    device_id: str
    resource: dict


@router.post("/fhir", response_model=IngestResult)
def ingest_fhir(body: FhirPayload, _: CurrentUser = Depends(ingestors), db: Session = Depends(get_db)):
    try:
        items = [ObservationIn(**x) for x in observation_to_items(body.resource, body.astronaut_id,
                                                                    body.device_id)]
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    return ingest(db, items)
