from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.auth.dependencies import require_roles
from app.auth.models import CurrentUser, Role
from app.databases.session import get_db
from app.medical import audit

router = APIRouter(prefix="/audit")
readers = require_roles(Role.MEDICAL_OFFICER, Role.FLIGHT_SURGEON, Role.ADMINISTRATOR)


@router.get("")
def get_log(_: CurrentUser = Depends(readers), db: Session = Depends(get_db)):
    ok, broken, entries = audit.verify_chain(db)
    return {"chain_intact": ok, "broken_entry_id": broken, "total": len(entries), "entries": entries[-500:]}


@router.post("/verify")
def verify(_: CurrentUser = Depends(readers), db: Session = Depends(get_db)):
    ok, broken, entries = audit.verify_chain(db)
    return {"chain_intact": ok, "broken_entry_id": broken, "verified": len(entries)}
