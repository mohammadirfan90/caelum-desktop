from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.alerts.rules import RULES_VERSION
from app.config.settings import settings
from app.databases.session import get_db

router = APIRouter()


@router.get("/health")
def health(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
        database = "HEALTHY"
    except Exception as exc:  # pragma: no cover
        database = f"UNHEALTHY: {exc.__class__.__name__}"
    return {"status": "ONLINE", "version": settings.VERSION, "profile": settings.PROFILE,
            "database": database, "rules_version": RULES_VERSION,
            "simulator_enabled": settings.ENABLE_SIMULATOR, "demo_time_scale": settings.time_scale,
            "clinical_use": "NOT APPROVED: research and demonstration software"}
