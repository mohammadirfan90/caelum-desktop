"""Single source of truth for every physiological and environmental parameter.

Units are canonical (UCUM where possible). LOINC codes are given only where a correct code
exists; None means "no standard code — export as a local code". Plausible ranges reject
physically impossible values (sensor faults), they are NOT clinical limits.
"""
from dataclasses import dataclass
from typing import Literal, Optional

Category = Literal["vital-signs", "derived", "environment", "context"]


@dataclass(frozen=True)
class ParamSpec:
    key: str
    label: str
    unit: str
    ucum: str
    category: Category
    plausible: tuple[float, float]
    loinc: Optional[str] = None
    loinc_display: Optional[str] = None
    mdc: Optional[str] = None  # IEEE 11073-10101 reference id


PARAMETERS: dict[str, ParamSpec] = {p.key: p for p in [
    ParamSpec("heart_rate", "Heart rate", "bpm", "/min", "vital-signs", (20, 300),
              "8867-4", "Heart rate", "MDC_ECG_HEART_RATE"),
    ParamSpec("pulse_rate", "Pulse rate (PPG)", "bpm", "/min", "vital-signs", (20, 300),
              "8867-4", "Heart rate", "MDC_PULS_OXIM_PULS_RATE"),
    ParamSpec("spo2", "Oxygen saturation (SpO2)", "%", "%", "vital-signs", (40, 100),
              "59408-5", "Oxygen saturation in Arterial blood by Pulse oximetry",
              "MDC_PULS_OXIM_SAT_O2"),
    ParamSpec("respiration_rate", "Respiratory rate", "/min", "/min", "vital-signs", (2, 80),
              "9279-1", "Respiratory rate", "MDC_RESP_RATE"),
    ParamSpec("core_temp", "Core body temperature (estimated)", "°C", "Cel", "vital-signs",
              (30, 44), "8310-5", "Body temperature", "MDC_TEMP_BODY"),
    ParamSpec("skin_temp", "Skin temperature", "°C", "Cel", "vital-signs", (20, 42),
              None, None, "MDC_TEMP_SKIN"),
    ParamSpec("bp_systolic", "Systolic blood pressure", "mmHg", "mm[Hg]", "vital-signs",
              (50, 260), "8480-6", "Systolic blood pressure", "MDC_PRESS_BLD_NONINV_SYS"),
    ParamSpec("bp_diastolic", "Diastolic blood pressure", "mmHg", "mm[Hg]", "vital-signs",
              (20, 160), "8462-4", "Diastolic blood pressure", "MDC_PRESS_BLD_NONINV_DIA"),
    ParamSpec("hrv_rmssd", "Heart-rate variability (RMSSD)", "ms", "ms", "derived", (1, 300)),
    ParamSpec("eda", "Electrodermal activity", "µS", "uS", "derived", (0, 100)),
    ParamSpec("af_probability", "Atrial-fibrillation probability", "1", "1", "derived", (0, 1)),
    ParamSpec("activity_level", "Activity level", "1", "1", "context", (0, 1)),
    ParamSpec("cabin_co2", "Cabin CO2 partial pressure", "mmHg", "mm[Hg]", "environment", (0, 60)),
    ParamSpec("cabin_o2", "Cabin O2 partial pressure", "kPa", "kPa", "environment", (0, 60)),
    ParamSpec("cabin_pressure", "Cabin total pressure", "kPa", "kPa", "environment", (0, 120)),
    ParamSpec("radiation_dose_rate", "Radiation dose rate", "µSv/h", "uSv/h", "environment",
              (0, 100000)),
]}

# value_in_canonical = f(value_in_given_unit)
UNIT_CONVERSIONS: dict[tuple[str, str], callable] = {
    ("°F", "°C"): lambda v: (v - 32.0) * 5.0 / 9.0,
    ("K", "°C"): lambda v: v - 273.15,
    ("kPa", "mmHg"): lambda v: v * 7.50062,
    ("mmHg", "kPa"): lambda v: v / 7.50062,
    ("ppm", "mmHg"): lambda v: v * 760.0 / 1e6,  # assumes 1 atm cabin; flagged in provenance
    ("1/min", "bpm"): lambda v: v,
    ("/min", "bpm"): lambda v: v,
    ("bpm", "/min"): lambda v: v,
    ("fraction", "%"): lambda v: v * 100.0,
}


def to_canonical(parameter: str, value: float, unit: str) -> float:
    spec = PARAMETERS[parameter]
    if unit == spec.unit:
        return value
    conv = UNIT_CONVERSIONS.get((unit, spec.unit))
    if conv is None:
        raise ValueError(f"unit '{unit}' cannot be converted to '{spec.unit}' for {parameter}")
    return conv(value)
