"""Alert engine: persistence, hysteresis, per-astronaut state, supersession and escalation."""
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.alerts.rules import (BASELINE_PARAMS, BASELINE_PERSIST_S, BASELINE_Z_CLEAR,
                              BASELINE_Z_TRIGGER, ESCALATION, LEVEL_RANK, MAX_SAMPLE_GAP_S,
                              RULES, RULES_VERSION, Rule)
from app.communications import queue as downlink
from app.config.settings import settings
from app.core_time import as_utc, utc_now
from app.databases.models import Alert, AlertNotification, Baseline, Device, Observation
from app.domain.parameters import PARAMETERS
from app.medical import audit


def scaled(seconds: float) -> float:
    """Demo timing shortens only windows longer than 60 s; critical timings stay real."""
    return seconds if seconds <= 60 else max(60.0, seconds * settings.time_scale)


@dataclass
class _Timer:
    start: datetime
    last: datetime


class AlertEngine:
    def reset(self) -> None:
        self._pending.clear()
        self._clearing.clear()

    def __init__(self, rules: list[Rule] = RULES):
        self.by_param: dict[str, list[Rule]] = {}
        for r in rules:
            self.by_param.setdefault(r.parameter, []).append(r)
        self._pending: dict[tuple[str, str], _Timer] = {}
        self._clearing: dict[tuple[str, str], _Timer] = {}

    # ---------------------------------------------------------------- timers
    @staticmethod
    def _advance(store: dict, key, t: datetime) -> datetime:
        cur = store.get(key)
        if cur is None or (t - cur.last).total_seconds() > MAX_SAMPLE_GAP_S:
            store[key] = _Timer(t, t)
            return t
        if t > cur.last:
            cur.last = t
        return cur.start

    # ---------------------------------------------------------------- queries
    @staticmethod
    def _open_alert(db: Session, astronaut_id: str, rule_id: str) -> Optional[Alert]:
        return db.scalars(select(Alert).where(
            Alert.astronaut_id == astronaut_id, Alert.rule_id == rule_id,
            Alert.status.in_(["ACTIVE", "ACKNOWLEDGED"]))).first()

    @staticmethod
    def _open_for_parameter(db: Session, astronaut_id: str, parameter: str) -> list[Alert]:
        return list(db.scalars(select(Alert).where(
            Alert.astronaut_id == astronaut_id, Alert.parameter == parameter,
            Alert.status.in_(["ACTIVE", "ACKNOWLEDGED"]))))

    # ---------------------------------------------------------------- main entry
    def evaluate(self, db: Session, obs: Observation, baseline: Optional[Baseline] = None) -> list[Alert]:
        t = as_utc(obs.measured_at)
        events: list[Alert] = []
        sensor_rule = f"sensor.{obs.device_id}"
        if obs.quality in ("POOR", "UNUSABLE"):
            if not self._open_alert(db, obs.astronaut_id, sensor_rule):
                events.append(self._create(db, obs, t, rule_id=sensor_rule, level="advisory",
                                           module="SENSOR", title="Sensor signal unusable",
                                           why=[f"{obs.parameter} from device {obs.device_id} reported quality {obs.quality}.",
                                                "Clinical rules are paused for this signal until quality recovers."],
                                           action="Check sensor contact, fit and battery."))
            return events
        open_sensor = self._open_alert(db, obs.astronaut_id, sensor_rule)
        if open_sensor:
            events.append(self._resolve(db, open_sensor, "signal quality recovered"))

        activity = float((obs.context or {}).get("activity_level", 0.0))
        for rule in self.by_param.get(obs.parameter, []):
            key = (obs.astronaut_id, rule.id)
            open_alert = self._open_alert(db, obs.astronaut_id, rule.id)
            suppressed = rule.skip_if_activity_above is not None and activity > rule.skip_if_activity_above
            if not suppressed and rule.breached(obs.value):
                self._clearing.pop(key, None)
                start = self._advance(self._pending, key, t)
                held = (t - start).total_seconds()
                if open_alert is None and held >= scaled(rule.persist_s):
                    created = self._raise_rule(db, rule, obs, t, held)
                    if created:
                        events.append(created)
            else:
                self._pending.pop(key, None)
                if open_alert is not None and rule.cleared(obs.value):
                    start = self._advance(self._clearing, key, t)
                    if (t - start).total_seconds() >= scaled(rule.clear_persist_s):
                        self._clearing.pop(key, None)
                        events.append(self._resolve(db, open_alert, f"{obs.parameter} back within limits"))
                else:
                    self._clearing.pop(key, None)
        events += self._baseline(db, obs, baseline, t)
        return events

    # ---------------------------------------------------------------- baseline (observe only)
    def _baseline(self, db, obs, baseline, t) -> list[Alert]:
        if (baseline is None or baseline.status != "VALID" or obs.parameter not in BASELINE_PARAMS
                or baseline.mad <= 0):
            return []
        z = (obs.value - baseline.median) / (1.4826 * baseline.mad)
        rule_id, key = f"baseline.{obs.parameter}", (obs.astronaut_id, f"baseline.{obs.parameter}")
        open_alert = self._open_alert(db, obs.astronaut_id, rule_id)
        if abs(z) >= BASELINE_Z_TRIGGER:
            self._clearing.pop(key, None)
            start = self._advance(self._pending, key, t)
            if open_alert is None and (t - start).total_seconds() >= scaled(BASELINE_PERSIST_S):
                label = PARAMETERS[obs.parameter].label
                return [self._create(db, obs, t, rule_id=rule_id, level="observe", module="TREND",
                                     title=f"{label} outside your personal normal",
                                     why=[f"{label} {obs.value:g} vs personal median {baseline.median:g} "
                                          f"(robust z = {z:+.1f}) for over {BASELINE_PERSIST_S/60:.0f} min.",
                                          f"Baseline from {baseline.n} samples over {baseline.window_days} days."],
                                     action="Review in the app; repeat a resting check later.")]
        else:
            self._pending.pop(key, None)
            if open_alert and abs(z) <= BASELINE_Z_CLEAR:
                start = self._advance(self._clearing, key, t)
                if (t - start).total_seconds() >= scaled(BASELINE_PERSIST_S):
                    self._clearing.pop(key, None)
                    return [self._resolve(db, open_alert, "back within personal normal")]
        return []

    # ---------------------------------------------------------------- create / resolve
    def _raise_rule(self, db, rule: Rule, obs: Observation, t: datetime, held: float) -> Optional[Alert]:
        rank = LEVEL_RANK[rule.level]
        for other in self._open_for_parameter(db, obs.astronaut_id, rule.parameter):
            if LEVEL_RANK[other.level] >= rank:
                return None  # an equal/higher alert already covers this parameter
            other.status = "SUPERSEDED"
            other.resolved_at = t
        spec = PARAMETERS[rule.parameter]
        why = [f"{spec.label} {obs.value:g} {spec.unit} {'below' if rule.op == '<' else 'above'} "
               f"{rule.threshold:g} {spec.unit} for {held:.0f} s (rule {rule.id}, v{RULES_VERSION}).",
               "Absolute safety limit: evaluated regardless of personal baseline."]
        return self._create(db, obs, t, rule_id=rule.id, level=rule.level, module=rule.module,
                            title=rule.title, why=why, action=rule.action)

    def _create(self, db, obs: Observation, t, *, rule_id, level, module, title, why, action) -> Alert:
        device = db.get(Device, obs.device_id)
        sources = [{"kind": "device", "device_id": obs.device_id,
                    "label": device.name if device else obs.device_id,
                    "accuracy_class": device.accuracy_class if device else "unknown",
                    "simulated": bool(obs.simulated)}]
        if obs.simulated:
            why = [*why, "SIMULATED DATA: generated by the simulator, not a real measurement."]
        alert = Alert(astronaut_id=obs.astronaut_id, rule_id=rule_id, rule_version=RULES_VERSION,
                      parameter=obs.parameter, module=module, level=level, title=title, why=why,
                      action=action, trigger_value=obs.value, sources=sources,
                      simulated=bool(obs.simulated), created_at=t)
        db.add(alert)
        db.flush()
        audit.log_event(db, "alert-engine", "System", f"Alert raised: {title}", alert.id,
                        {"level": level, "rule": rule_id, "value": obs.value}, commit=False)
        payload = alert_payload(alert)
        if level in ("warning", "critical"):
            downlink.enqueue(db, payload, "CRITICAL" if level == "critical" else "ROUTINE",
                             "FLIGHT_SURGEON_SECURE", commit=False)
        if level == "critical":
            downlink.enqueue(db, payload, "CRITICAL", "MISSION_CONTROL", commit=False)
        notify_due(db, alert, t)
        db.commit()
        return alert

    @staticmethod
    def _resolve(db, alert: Alert, reason: str) -> Alert:
        alert.status, alert.resolved_at = "RESOLVED", utc_now()
        audit.log_event(db, "alert-engine", "System", f"Alert resolved: {reason}", alert.id, commit=False)
        db.commit()
        return alert


def alert_payload(a: Alert) -> dict:
    return {"type": "alert", "alert_id": a.id, "astronaut_id": a.astronaut_id, "level": a.level,
            "status": a.status, "module": a.module, "created_at": as_utc(a.created_at).isoformat(),
            "title": a.title, "why": a.why, "parameter": a.parameter,
            "trigger_value": a.trigger_value, "sources": a.sources, "simulated": a.simulated}


def notify_due(db: Session, alert: Alert, now: datetime) -> list[AlertNotification]:
    """Emit every escalation step that is due. Only ACTIVE (unacknowledged) alerts escalate."""
    if alert.status != "ACTIVE":
        return []
    plan = ESCALATION[alert.level]
    now = as_utc(now)
    elapsed = (now - as_utc(alert.created_at)).total_seconds()
    out = []
    while alert.escalation_stage < len(plan) and elapsed >= scaled(plan[alert.escalation_stage][0]):
        audience = plan[alert.escalation_stage][1]
        n = AlertNotification(alert_id=alert.id, audience=audience, stage=alert.escalation_stage, at=now)
        db.add(n)
        out.append(n)
        if audience == "ground":
            downlink.enqueue(db, {**alert_payload(alert), "type": "escalation"}, "CRITICAL",
                             "FLIGHT_SURGEON_SECURE", commit=False)
        alert.escalation_stage += 1
    return out


def escalation_tick(db: Session, now: Optional[datetime] = None) -> list[AlertNotification]:
    now = as_utc(now) if now else utc_now()
    out = []
    for alert in db.scalars(select(Alert).where(Alert.status == "ACTIVE")):
        out += notify_due(db, alert, now)
    if out:
        db.commit()
    return out


def acknowledge(db: Session, alert: Alert, actor: str, role: str) -> Alert:
    if alert.status != "ACTIVE":
        return alert
    alert.status, alert.acknowledged_by, alert.acknowledged_at = "ACKNOWLEDGED", actor, utc_now()
    audit.log_event(db, actor, role, "Alert acknowledged", alert.id, commit=False)
    if alert.level in ("warning", "critical"):
        downlink.enqueue(db, {**alert_payload(alert), "type": "acknowledgement"}, "ROUTINE",
                         "FLIGHT_SURGEON_SECURE", commit=False)
    db.commit()
    return alert


engine = AlertEngine()
