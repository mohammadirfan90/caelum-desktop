"""Clinical alert rules.

SAFETY PRINCIPLES
1. Absolute limits are ALWAYS evaluated. A personal baseline can add an early 'observe' alert
   but can never suppress, delay or downgrade an absolute-limit alert.
2. Every rule needs persistence (sustained breach) to fire and hysteresis (a separate clear
   threshold held for a clear period) to resolve, to prevent alarm flicker and fatigue.
3. Thresholds below are ENGINEERING PLACEHOLDERS (status: DRAFT). They must be reviewed and
   signed off by a flight surgeon before any operational use. Change RULES_VERSION on every edit.
"""
from dataclasses import dataclass
from typing import Literal, Optional

RULES_VERSION = "3.0.0-draft"
LEVEL_RANK = {"advisory": 0, "observe": 1, "warning": 2, "critical": 3}


@dataclass(frozen=True)
class Rule:
    id: str
    parameter: str
    level: Literal["observe", "warning", "critical"]
    op: Literal["<", ">"]
    threshold: float
    persist_s: float
    clear_threshold: float
    clear_persist_s: float
    module: str
    title: str
    action: str
    skip_if_activity_above: Optional[float] = None  # suppress e.g. tachycardia during exercise

    def breached(self, v: float) -> bool:
        return v < self.threshold if self.op == "<" else v > self.threshold

    def cleared(self, v: float) -> bool:
        return v >= self.clear_threshold if self.op == "<" else v <= self.clear_threshold


RULES: list[Rule] = [
    Rule("spo2.critical", "spo2", "critical", "<", 85, 15, 90, 60, "RESPIRATORY",
         "Severe low blood oxygen",
         "Start the low-oxygen protocol: check cabin O2, give oxygen, confirm with the clinical pulse oximeter."),
    Rule("spo2.warning", "spo2", "warning", "<", 90, 60, 92, 60, "RESPIRATORY",
         "Low blood oxygen",
         "Check sensor fit and cabin O2; confirm with the clinical pulse oximeter."),
    Rule("hr.critical.high", "heart_rate", "critical", ">", 180, 30, 160, 60, "CARDIO",
         "Extreme heart rate", "Stop all activity, record a 12-lead ECG, contact the flight surgeon."),
    Rule("hr.warning.high", "heart_rate", "warning", ">", 130, 120, 120, 120, "CARDIO",
         "High heart rate at rest", "Rest, re-check in 5 minutes, record a 12-lead ECG if it persists.",
         skip_if_activity_above=0.3),
    Rule("hr.critical.low", "heart_rate", "critical", "<", 40, 30, 45, 60, "CARDIO",
         "Very low heart rate", "Check responsiveness, record a 12-lead ECG, contact the flight surgeon."),
    Rule("rr.warning.high", "respiration_rate", "warning", ">", 30, 120, 25, 120, "RESPIRATORY",
         "Fast breathing", "Check symptoms and cabin CO2."),
    Rule("rr.critical.low", "respiration_rate", "critical", "<", 6, 30, 8, 60, "RESPIRATORY",
         "Very slow breathing", "Check responsiveness and airway immediately."),
    Rule("temp.warning", "core_temp", "warning", ">", 38.0, 600, 37.7, 600, "THERMAL",
         "Fever or heat strain", "Stop exercise, symptom check, follow the fever protocol."),
    Rule("temp.critical", "core_temp", "critical", ">", 39.5, 300, 39.0, 300, "THERMAL",
         "High body temperature", "Begin cooling, medical officer assessment, contact flight surgeon."),
    Rule("af.warning", "af_probability", "warning", ">", 0.8, 300, 0.5, 600, "CARDIO",
         "Possible atrial fibrillation",
         "Avoid heavy exercise and record a 12-lead ECG with the onboard kit."),
    Rule("co2.warning", "cabin_co2", "warning", ">", 4.0, 900, 3.5, 900, "ENVIRONMENT",
         "Cabin CO2 elevated", "Check CO2 removal system status; watch for headache and fatigue."),
    Rule("o2.critical", "cabin_o2", "critical", "<", 16.0, 30, 17.0, 60, "ENVIRONMENT",
         "Low cabin oxygen", "Follow the cabin atmosphere emergency procedure."),
]

# Baseline deviation (robust z = (x - median) / (1.4826 * MAD)). Observe-level only.
BASELINE_PARAMS = {"heart_rate", "hrv_rmssd", "respiration_rate", "core_temp", "spo2"}
BASELINE_Z_TRIGGER, BASELINE_Z_CLEAR, BASELINE_PERSIST_S = 4.0, 2.5, 600.0

# Escalation plan: (seconds after alert creation, audience). Stops when acknowledged.
ESCALATION: dict[str, list[tuple[float, str]]] = {
    "critical": [(0, "astronaut"), (0, "medical_officer"), (15, "sound"), (30, "crew"), (60, "ground")],
    "warning": [(0, "astronaut"), (0, "medical_officer"), (60, "crew")],
    "observe": [(0, "astronaut"), (3600, "astronaut"), (86400, "medical_officer")],
    "advisory": [(0, "astronaut")],
}

MAX_SAMPLE_GAP_S = 30.0  # a data gap longer than this restarts persistence timing
