"""Personal baselines using robust statistics (median / MAD) over good-quality, non-simulated data."""
from datetime import timedelta
from typing import Optional

import numpy as np
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core_time import utc_now
from app.databases.models import Baseline, Observation

MIN_SAMPLES = 30


def recompute(db: Session, astronaut_id: str, parameter: str, window_days: int = 14,
              include_simulated: bool = False) -> Baseline:
    since = utc_now() - timedelta(days=window_days)
    q = select(Observation.value).where(
        Observation.astronaut_id == astronaut_id, Observation.parameter == parameter,
        Observation.measured_at >= since, Observation.quality.in_(["GOOD", "DEGRADED"]))
    if not include_simulated:
        q = q.where(Observation.simulated.is_(False))
    values = np.array(db.scalars(q).all(), dtype=float)
    b = get(db, astronaut_id, parameter) or Baseline(astronaut_id=astronaut_id, parameter=parameter,
                                                       median=0.0, mad=0.0, n=0, window_days=window_days,
                                                       status="INSUFFICIENT_DATA")
    b.n, b.window_days, b.updated_at = int(values.size), window_days, utc_now()
    if values.size < MIN_SAMPLES:
        b.status = "INSUFFICIENT_DATA"
    else:
        med = float(np.median(values))
        b.median, b.mad, b.status = med, float(np.median(np.abs(values - med))), "VALID"
    db.add(b)
    db.commit()
    return b


def get(db: Session, astronaut_id: str, parameter: str) -> Optional[Baseline]:
    return db.scalars(select(Baseline).where(Baseline.astronaut_id == astronaut_id,
                                             Baseline.parameter == parameter)).first()
