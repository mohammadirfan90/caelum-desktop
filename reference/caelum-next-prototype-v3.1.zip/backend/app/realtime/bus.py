"""In-process publish/subscribe used to push observations and alerts to WebSocket clients."""
import asyncio
from typing import Any


class EventBus:
    def __init__(self) -> None:
        self._subs: set[asyncio.Queue] = set()
        self._loop: asyncio.AbstractEventLoop | None = None

    def bind_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        self._loop = loop

    def subscribe(self, maxsize: int = 1000) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self._subs.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self._subs.discard(q)

    def _put(self, event: dict[str, Any]) -> None:
        for q in list(self._subs):
            if q.full():  # slow client: drop its oldest event rather than block producers
                q.get_nowait()
            q.put_nowait(event)

    def publish(self, event: dict[str, Any]) -> None:
        """Thread-safe: may be called from request threads or the event loop."""
        if self._loop is None:
            return
        try:
            running = asyncio.get_running_loop()
        except RuntimeError:
            running = None
        if running is self._loop:
            self._put(event)
        else:
            self._loop.call_soon_threadsafe(self._put, event)


bus = EventBus()
