"""Model registry. The fatigue score below is a HAND-WEIGHTED HEURISTIC, not a trained or
validated model; it is exposed only so the UI can show the explanation format."""
from datetime import datetime, timezone

import numpy as np

MODELS = {
    "fatigue_heuristic_v0": {"validation_status": "NOT_VALIDATED", "type": "heuristic",
                             "inputs": ["sleep_duration_hours", "hrv_rmssd", "reaction_time_ms"]},
}


def fatigue_heuristic(sleep_h: float, rmssd: float, reaction_ms: float) -> dict:
    sleep_def = max(0.0, (7.5 - sleep_h) / 4.0)
    hrv_pen = max(0.0, (45.0 - rmssd) / 35.0)
    pvt_pen = max(0.0, (reaction_ms - 240.0) / 100.0)
    score = float(np.clip(0.4 * sleep_def + 0.35 * hrv_pen + 0.25 * pvt_pen, 0, 1))
    return {"model_id": "fatigue_heuristic_v0", **MODELS["fatigue_heuristic_v0"],
            "timestamp": datetime.now(timezone.utc).isoformat(), "score": round(score, 2),
            "contributions": {"sleep_deficit": round(sleep_def, 2), "low_hrv": round(hrv_pen, 2),
                              "slow_reaction": round(pvt_pen, 2)},
            "notice": "Heuristic for interface demonstration. Not for operational decisions."}
