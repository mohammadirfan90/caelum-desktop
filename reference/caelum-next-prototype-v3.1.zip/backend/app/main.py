import asyncio
import contextlib
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.alerts.engine import escalation_tick
from app.api.v1.router import api_router
from app.api.v1.telemetry_ws import router as ws_router
from app.config.settings import settings
from app.core_time import utc_now
from app.databases import models  # noqa: F401  (register tables)
from app.databases.session import Base, SessionLocal, engine
from app.devices.simulator import fleet
from app.ingestion.pipeline import ObservationIn, ingest
from app.realtime.bus import bus
from app.seed import seed_dev

log = logging.getLogger("caelum")


async def _escalation_loop():
    while True:
        await asyncio.sleep(settings.ESCALATION_TICK_S)
        try:
            def run():
                with SessionLocal() as db:
                    from app.databases.models import Alert
                    out = []
                    for n in escalation_tick(db):
                        a = db.get(Alert, n.alert_id)
                        out.append((n.alert_id, a.astronaut_id if a else None, a.level if a else None,
                                    n.audience, n.stage))
                    return out
            for alert_id, astro, level, audience, stage in await asyncio.to_thread(run):
                bus.publish({"type": "escalation", "alert_id": alert_id, "astronaut_id": astro,
                             "level": level, "audience": audience, "stage": stage})
        except Exception:  # never let the safety loop die silently
            log.exception("escalation tick failed")


async def _simulator_loop():
    fleet.ensure(["ast-01", "ast-02", "ast-03"])
    fleet.sims["ast-01"].set_scenario(settings.SIMULATOR_SCENARIO)
    while True:
        await asyncio.sleep(1.0)
        try:
            now = utc_now()
            items = [ObservationIn(**x) for sim in fleet.sims.values() for x in sim.step(now)]

            def run():
                with SessionLocal() as db:
                    ingest(db, items)
            await asyncio.to_thread(run)
        except Exception:
            log.exception("simulator step failed")


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        seed_dev(db)
    bus.bind_loop(asyncio.get_running_loop())
    tasks = [asyncio.create_task(_escalation_loop())]
    if settings.ENABLE_SIMULATOR and settings.is_dev:
        tasks.append(asyncio.create_task(_simulator_loop()))
    yield
    for t in tasks:
        t.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await t


app = FastAPI(title=settings.PROJECT_NAME, version=settings.VERSION, lifespan=lifespan,
              openapi_url=f"{settings.API_V1_STR}/openapi.json",
              description="Advisory crew health monitoring. Not approved for clinical use.")
app.add_middleware(CORSMiddleware, allow_origins=settings.CORS_ORIGINS, allow_credentials=True,
                   allow_methods=["GET", "POST", "PATCH", "DELETE"],
                   allow_headers=["Authorization", "Content-Type"])
app.include_router(api_router, prefix=settings.API_V1_STR)
app.include_router(ws_router)


@app.get("/")
def root():
    return {"platform": settings.PROJECT_NAME, "version": settings.VERSION, "docs": "/docs"}
