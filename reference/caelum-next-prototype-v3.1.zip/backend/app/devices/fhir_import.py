"""Import HL7 FHIR R4 Observation resources into the ingestion format."""
from datetime import datetime

from app.domain.parameters import PARAMETERS

_BY_LOINC: dict[str, str] = {}
for _p in PARAMETERS.values():
    if _p.loinc and _p.loinc not in _BY_LOINC:
        _BY_LOINC[_p.loinc] = _p.key
_BY_LOINC["2708-6"] = "spo2"  # legacy SpO2 code still sent by some systems


def observation_to_items(resource: dict, astronaut_id: str, device_id: str) -> list[dict]:
    if resource.get("resourceType") != "Observation":
        raise ValueError("not a FHIR Observation")
    codes = [c.get("code") for c in resource.get("code", {}).get("coding", [])
             if c.get("system") == "http://loinc.org"]
    param = next((_BY_LOINC[c] for c in codes if c in _BY_LOINC), None)
    if param is None:
        raise ValueError(f"no supported LOINC code in {codes}")
    vq = resource.get("valueQuantity") or {}
    if "value" not in vq:
        raise ValueError("Observation has no valueQuantity.value")
    when = resource.get("effectiveDateTime") or resource.get("issued")
    if not when:
        raise ValueError("Observation has no effectiveDateTime")
    unit = vq.get("unit") or PARAMETERS[param].unit
    unit = {"/min": PARAMETERS[param].unit, "Cel": "°C", "mm[Hg]": "mmHg"}.get(unit, unit)
    return [{"astronaut_id": astronaut_id, "device_id": device_id, "parameter": param,
             "value": float(vq["value"]), "unit": unit,
             "measured_at": datetime.fromisoformat(when.replace("Z", "+00:00")),
             "classification": "measured"}]
