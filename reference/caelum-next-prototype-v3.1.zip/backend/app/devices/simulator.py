"""Physiological simulator. Every observation it creates is stored with simulated=True and every
alert it causes is labelled SIMULATED. Development and demonstration only.

Scenarios start 10 s after they are selected, so a presenter can narrate the onset."""
import math
import random
from datetime import datetime

ONSET_S = 10
SCENARIOS = {
    "normal": ("Normal day", "All vitals within personal range.", "No alerts."),
    "hypoxia": ("Oxygen dropping", "SpO2 falls about 0.5 % per second from 97 %, heart rate rises.",
                "Critical SpO2 alert ~50 s after start, then sound, crew and ground escalation."),
    "tachycardia": ("Extreme heart rate", "Heart rate jumps to ~185 bpm at rest.",
                    "Critical heart-rate alert ~40 s after start."),
    "bradycardia": ("Very low heart rate", "Heart rate drops to ~36 bpm.",
                    "Critical low heart-rate alert ~40 s after start."),
    "fever": ("Fever developing", "Core temperature climbs toward 39.8 °C.",
              "Fever warning, later high-temperature critical (persistence shortened in demo timing)."),
    "af": ("Irregular heartbeat", "Rhythm model reports atrial-fibrillation probability 0.92.",
           "AF warning asking for a 12-lead ECG (persistence shortened in demo timing)."),
    "co2": ("Cabin CO2 rising", "Cabin CO2 rises to 6 mmHg.",
            "Environment warning (persistence shortened in demo timing)."),
    "sensor_fault": ("Loose sensor", "Heart-rate and SpO2 signals become unusable.",
                     "Sensor advisory only: no false clinical alarm."),
}


def device_id_for(astronaut_id: str) -> str:
    return f"sim-{astronaut_id.split('-')[-1]}"


class Simulator:
    def __init__(self, astronaut_id: str, scenario: str = "normal", seed: int = 7):
        self.astronaut_id = astronaut_id
        self.rng = random.Random(seed + hash(astronaut_id) % 1000)
        self.base_hr = 58 + self.rng.random() * 8
        self.set_scenario(scenario)

    def set_scenario(self, scenario: str) -> None:
        if scenario not in SCENARIOS:
            raise ValueError(f"scenario must be one of {list(SCENARIOS)}")
        self.scenario, self.t = scenario, 0

    def step(self, now: datetime) -> list[dict]:
        self.t += 1
        t, g, s = self.t, self.rng.gauss, self.scenario
        on = t - ONSET_S
        hr = self.base_hr + 3 * math.sin(t / 40) + g(0, 1.0)
        spo2, temp, rr, af, co2 = 97.4 + g(0, 0.3), 36.8 + g(0, 0.03), 14 + g(0, 0.6), 0.03, 2.6 + g(0, 0.04)
        quality = "GOOD"
        if on > 0:
            if s == "hypoxia":
                spo2 = max(79.0, 97.4 - on * 0.5) + g(0, 0.3)
                hr += min(28, on * 0.6)
                rr += min(10, on * 0.2)
            elif s == "tachycardia":
                hr = 185 + g(0, 2)
            elif s == "bradycardia":
                hr = 36 + g(0, 0.8)
            elif s == "fever":
                temp = min(39.8, 36.8 + on * 0.05) + g(0, 0.02)
                hr += min(20, on * 0.3)
            elif s == "af":
                af = 0.92
                hr = 105 + g(0, 12)
            elif s == "co2":
                co2 = min(6.0, 2.6 + on * 0.1) + g(0, 0.03)
            elif s == "sensor_fault":
                quality = "UNUSABLE"
        vals = {"heart_rate": (hr, "bpm"), "spo2": (min(100.0, spo2), "%"),
                "respiration_rate": (rr, "/min"), "core_temp": (temp, "°C"),
                "skin_temp": (34.6 + g(0, 0.1), "°C"), "hrv_rmssd": (max(5, 48 + g(0, 4)), "ms"),
                "af_probability": (af, "1"), "activity_level": (0.05, "1"),
                "cabin_co2": (co2, "mmHg"), "cabin_o2": (21.2 + g(0, 0.04), "kPa")}
        return [{"astronaut_id": self.astronaut_id, "device_id": device_id_for(self.astronaut_id),
                 "parameter": k, "value": round(v, 2), "unit": u, "measured_at": now,
                 "quality": quality if k in ("heart_rate", "spo2") else "GOOD",
                 "classification": "derived" if k in ("hrv_rmssd", "core_temp", "af_probability") else "measured",
                 "context": {"activity_level": 0.05}} for k, (v, u) in vals.items()]


class SimulatorFleet:
    """One simulator per crew member, switchable at runtime by the presenter."""

    def __init__(self) -> None:
        self.sims: dict[str, Simulator] = {}

    def ensure(self, astronaut_ids: list[str]) -> None:
        for aid in astronaut_ids:
            self.sims.setdefault(aid, Simulator(aid))

    def state(self) -> dict[str, str]:
        return {aid: s.scenario for aid, s in self.sims.items()}


fleet = SimulatorFleet()
