"""Decoders for adopted Bluetooth SIG health characteristics (standard GATT profiles).

  0x2A37 Heart Rate Measurement            (Heart Rate Service)
  0x2A5E PLX Spot-Check Measurement        (Pulse Oximeter Service)
  0x2A5F PLX Continuous Measurement        (Pulse Oximeter Service)
  0x2A35 Blood Pressure Measurement        (Blood Pressure Service)
  0x2A1C Temperature Measurement           (Health Thermometer Service)

Values use IEEE 11073-20601 SFLOAT (16-bit) and FLOAT (32-bit). Special values (NaN, NRes,
+/-INF) decode to None and the measurement is dropped, never replaced with a default.
Verify flag bit positions against the adopted SIG specifications before flight use.
"""
import struct
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

_SFLOAT_SPECIAL = {0x07FF, 0x0800, 0x07FE, 0x0802, 0x0801}
_FLOAT_SPECIAL = {0x007FFFFF, 0x00800000, 0x007FFFFE, 0x00800002, 0x00800001}


def sfloat(raw: int) -> Optional[float]:
    if raw in _SFLOAT_SPECIAL:
        return None
    mant = raw & 0x0FFF
    if mant >= 0x0800:
        mant -= 0x1000
    exp = (raw >> 12) & 0x0F
    if exp >= 0x8:
        exp -= 0x10
    return round(mant * (10 ** exp), 6)


def float32(raw: int) -> Optional[float]:
    if raw in _FLOAT_SPECIAL:
        return None
    mant = raw & 0xFFFFFF
    if mant >= 0x800000:
        mant -= 0x1000000
    exp = (raw >> 24) & 0xFF
    if exp >= 0x80:
        exp -= 0x100
    return round(mant * (10 ** exp), 6)


def _ts(b: bytes, o: int) -> datetime:
    year, month, day, hour, minute, second = struct.unpack_from("<HBBBBB", b, o)
    return datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc)


@dataclass
class Reading:
    parameter: str
    value: float
    unit: str
    quality: str = "GOOD"
    measured_at: Optional[datetime] = None
    context: dict = field(default_factory=dict)


def heart_rate_measurement(b: bytes) -> list[Reading]:
    flags, o = b[0], 1
    if flags & 0x01:
        hr, o = struct.unpack_from("<H", b, o)[0], o + 2
    else:
        hr, o = b[o], o + 1
    quality = "POOR" if (flags & 0x04) and not (flags & 0x02) else "GOOD"  # contact supported, not detected
    if flags & 0x08:
        o += 2  # energy expended
    rr = []
    if flags & 0x10:
        while o + 1 < len(b):
            rr.append(struct.unpack_from("<H", b, o)[0] / 1024.0 * 1000.0)
            o += 2
    ctx = {"rr_intervals_ms": [round(x, 1) for x in rr]} if rr else {}
    return [Reading("heart_rate", float(hr), "bpm", quality, context=ctx)] if hr else []


def _plx_quality(status: int) -> Optional[str]:
    if status & (1 << 13):  # measurement unavailable
        return None
    if status & (1 << 15):  # invalid measurement detected
        return "UNUSABLE"
    if status & (1 << 14):  # questionable measurement detected
        return "DEGRADED"
    return "GOOD"


def plx_continuous(b: bytes) -> list[Reading]:
    flags = b[0]
    spo2, pr = sfloat(struct.unpack_from("<H", b, 1)[0]), sfloat(struct.unpack_from("<H", b, 3)[0])
    o, quality = 5, "GOOD"
    o += 4 if flags & 0x01 else 0  # SpO2PR-Fast
    o += 4 if flags & 0x02 else 0  # SpO2PR-Slow
    if flags & 0x04:
        q = _plx_quality(struct.unpack_from("<H", b, o)[0])
        if q is None:
            return []
        quality = q
    out = []
    if spo2 is not None:
        out.append(Reading("spo2", spo2, "%", quality))
    if pr is not None:
        out.append(Reading("pulse_rate", pr, "bpm", quality))
    return out


def plx_spot_check(b: bytes) -> list[Reading]:
    flags = b[0]
    spo2, pr = sfloat(struct.unpack_from("<H", b, 1)[0]), sfloat(struct.unpack_from("<H", b, 3)[0])
    o, ts, quality = 5, None, "GOOD"
    if flags & 0x01:
        ts, o = _ts(b, o), o + 7
    if flags & 0x02:
        q = _plx_quality(struct.unpack_from("<H", b, o)[0])
        if q is None:
            return []
        quality = q
    if flags & 0x10:  # device clock not set -> do not trust device timestamp
        ts = None
    out = []
    if spo2 is not None:
        out.append(Reading("spo2", spo2, "%", quality, ts))
    if pr is not None:
        out.append(Reading("pulse_rate", pr, "bpm", quality, ts))
    return out


def blood_pressure_measurement(b: bytes) -> list[Reading]:
    flags = b[0]
    unit = "kPa" if flags & 0x01 else "mmHg"
    sys_, dia = sfloat(struct.unpack_from("<H", b, 1)[0]), sfloat(struct.unpack_from("<H", b, 3)[0])
    o, ts = 7, None  # skip MAP
    if flags & 0x02:
        ts, o = _ts(b, o), o + 7
    pr = None
    if flags & 0x04:
        pr, o = sfloat(struct.unpack_from("<H", b, o)[0]), o + 2
    out = []
    if sys_ is not None:
        out.append(Reading("bp_systolic", sys_, unit, measured_at=ts))
    if dia is not None:
        out.append(Reading("bp_diastolic", dia, unit, measured_at=ts))
    if pr is not None:
        out.append(Reading("pulse_rate", pr, "bpm", measured_at=ts))
    return out


_CORE_SITES = {2, 3, 5, 6, 7, 9}  # body, ear, GI tract, mouth, rectum, tympanum


def temperature_measurement(b: bytes) -> list[Reading]:
    flags = b[0]
    value = float32(struct.unpack_from("<I", b, 1)[0])
    o, ts, site = 5, None, None
    if flags & 0x02:
        ts, o = _ts(b, o), o + 7
    if flags & 0x04 and o < len(b):
        site = b[o]
    if value is None:
        return []
    param = "core_temp" if site is None or site in _CORE_SITES else "skin_temp"
    return [Reading(param, value, "°F" if flags & 0x01 else "°C", measured_at=ts,
                    context={"site_code": site} if site is not None else {})]


DECODERS = {
    "2a37": heart_rate_measurement,
    "2a5e": plx_spot_check,
    "2a5f": plx_continuous,
    "2a35": blood_pressure_measurement,
    "2a1c": temperature_measurement,
}


def decode(characteristic_uuid: str, payload: bytes) -> list[Reading]:
    key = characteristic_uuid.lower().replace("0x", "")
    if len(key) > 4:  # full 128-bit SIG base UUID 0000xxxx-0000-1000-8000-00805f9b34fb
        key = key[4:8]
    if key not in DECODERS:
        raise ValueError(f"unsupported characteristic {characteristic_uuid}")
    return DECODERS[key](payload)
