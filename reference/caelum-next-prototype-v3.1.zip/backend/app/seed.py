"""Development seed data. Runs only in local_dev/test. Creates NO fake devices or readings."""
from sqlalchemy.orm import Session

from app.auth.models import Role
from app.auth.security import hash_password
from app.config.settings import settings
from app.databases.models import Astronaut, Device, User
from app.devices.simulator import device_id_for

CREW = [
    ("ast-01", "Cdr. Ines Varga", "IV", "Commander"),
    ("ast-02", "Dr. Alexei Chen", "AC", "Science Officer / Crew Medical Officer"),
    ("ast-03", "Lt. Maya Lin", "ML", "Flight Engineer"),
]
USERS = [
    ("varga", "Cdr. Ines Varga", Role.ASTRONAUT, "ast-01"),
    ("chen", "Dr. Alexei Chen", Role.MEDICAL_OFFICER, "ast-02"),
    ("lin", "Lt. Maya Lin", Role.ASTRONAUT, "ast-03"),
    ("surgeon", "Flight Surgeon (ground)", Role.FLIGHT_SURGEON, None),
    ("mcc", "Mission Control (ground)", Role.MISSION_CONTROL, None),
    ("gateway", "Device Gateway", Role.DEVICE_GATEWAY, None),
    ("admin", "System Administrator", Role.ADMINISTRATOR, None),
]


def seed_dev(db: Session) -> None:
    if not settings.is_dev:
        return
    for aid, name, ini, role in CREW:
        if not db.get(Astronaut, aid):
            db.add(Astronaut(id=aid, name=name, initials=ini, role=role,
                             mission="Expedition 74 (demo)", crew="Crew-1"))
    db.flush()
    pw = hash_password(settings.DEV_PASSWORD)
    for username, full, role, aid in USERS:
        if not db.get(User, username):
            db.add(User(username=username, full_name=full, role=role.value, hashed_password=pw,
                        astronaut_id=aid))
    if settings.ENABLE_SIMULATOR:
        for aid, name, ini, _ in CREW:
            did = device_id_for(aid)
            if not db.get(Device, did):
                db.add(Device(id=did, name=f"Simulated sensor kit ({ini})", category="simulator",
                              adapter="simulator", model="Sensor shirt + wristband (simulated)",
                              accuracy_class="estimate", is_simulated=True, astronaut_id=aid))
    db.commit()
