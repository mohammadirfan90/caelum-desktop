"""Store-and-forward downlink queue with per-destination ALLOW-lists (not deny-lists)."""
import threading
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core_time import utc_now
from app.databases.models import DownlinkPacket

PRIORITY_ORDER = {"CRITICAL": 0, "ROUTINE": 1, "BACKGROUND_RESEARCH": 2}

# Only these top-level keys may leave the spacecraft on each channel.
CHANNEL_ALLOWLIST: dict[str, set[str]] = {
    # Operations: status only, never raw physiology
    "MISSION_CONTROL": {"type", "alert_id", "astronaut_id", "level", "status", "module", "created_at"},
    # Medical: full clinical context, restricted channel
    "FLIGHT_SURGEON_SECURE": {"type", "alert_id", "astronaut_id", "level", "status", "module",
                              "created_at", "title", "why", "parameter", "trigger_value",
                              "sources", "observations", "fhir", "notifications", "simulated"},
    "RESEARCH_DEIDENTIFIED": {"type", "parameter", "summary"},
}
_lock = threading.Lock()


def filter_for_destination(payload: dict[str, Any], destination: str) -> dict[str, Any]:
    allowed = CHANNEL_ALLOWLIST.get(destination)
    if allowed is None:
        raise ValueError(f"unknown downlink destination {destination}")
    return {k: v for k, v in payload.items() if k in allowed}


def enqueue(db: Session, payload: dict[str, Any], priority: str = "ROUTINE",
            destination: str = "MISSION_CONTROL", commit: bool = True) -> DownlinkPacket:
    if priority not in PRIORITY_ORDER:
        raise ValueError(f"unknown priority {priority}")
    with _lock:
        seq = (db.scalar(select(func.max(DownlinkPacket.sequence_num))) or 0) + 1
        pkt = DownlinkPacket(sequence_num=seq, priority=priority, destination=destination,
                             payload=filter_for_destination(payload, destination))
        db.add(pkt)
        if commit:
            db.commit()
        else:
            db.flush()
        return pkt


def pending(db: Session, limit: int = 50) -> list[DownlinkPacket]:
    rows = db.scalars(select(DownlinkPacket).where(DownlinkPacket.status.in_(["QUEUED", "RETRYING"]))
                      .order_by(DownlinkPacket.sequence_num)).all()
    return sorted(rows, key=lambda p: (PRIORITY_ORDER[p.priority], p.sequence_num))[:limit]


def acknowledge(db: Session, packet_id: str) -> bool:
    pkt = db.get(DownlinkPacket, packet_id)
    if not pkt:
        return False
    pkt.status, pkt.sent_at = "ACKNOWLEDGED", utc_now()
    db.commit()
    return True
