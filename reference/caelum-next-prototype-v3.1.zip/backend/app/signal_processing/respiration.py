import numpy as np
from scipy import signal
from typing import Dict

class RespirationProcessor:
    """
    Processes thoracic and abdominal respiratory expansion signals (from AstroSkin inductive plethysmography).
    Extracts breath peaks, respiratory rate (breaths/min), estimated tidal volume, and minute ventilation.
    """
    def __init__(self, sampling_rate: int = 25):
        self.fs = sampling_rate

    def filter_respiration(self, signal_data: np.ndarray) -> np.ndarray:
        """Lowpass filter to remove cardiac oscillation and motion spikes (cutoff 0.8 Hz ~ 48 bpm)."""
        if len(signal_data) < 15:
            return signal_data
        nyquist = 0.5 * self.fs
        b, a = signal.butter(2, 0.8 / nyquist, btype='low')
        return signal.filtfilt(b, a, signal_data)

    def extract_breathing_parameters(self, raw_signal: np.ndarray) -> Dict[str, float]:
        filtered = self.filter_respiration(raw_signal)
        if len(filtered) < self.fs * 5: # Need at least 5 seconds
            return {"respiratory_rate": None, "relative_amplitude_au": None, "tidal_volume_ml": None,
                    "calibration": "UNCALIBRATED"}

        min_distance = int(self.fs * 1.5) # Minimum 1.5s between breaths (max 40 bpm)
        height_thresh = np.mean(filtered) + 0.2 * np.std(filtered)
        peaks, _ = signal.find_peaks(filtered, height=height_thresh, distance=min_distance)

        if len(peaks) < 2:
            return {"respiratory_rate": None, "relative_amplitude_au": None, "tidal_volume_ml": None,
                    "calibration": "UNCALIBRATED"}

        dur_sec = (peaks[-1] - peaks[0]) / self.fs
        rr_bpm = float((len(peaks) - 1) / dur_sec * 60.0) if dur_sec > 0 else 0.0

        # Approximate tidal volume from peak-to-trough amplitude (arbitrary units or calibrated mL)
        troughs, _ = signal.find_peaks(-filtered, distance=min_distance)
        if len(troughs) > 0:
            avg_peak = np.mean(filtered[peaks])
            avg_trough = np.mean(filtered[troughs])
            amplitude = float(avg_peak - avg_trough)
        else:
            amplitude = float(np.ptp(filtered))

        # Tidal volume requires per-astronaut spirometer calibration; until then report only the
        # relative breathing amplitude (arbitrary units) and never a fabricated millilitre value.
        return {
            "respiratory_rate": round(rr_bpm, 1),
            "relative_amplitude_au": round(amplitude, 4),
            "tidal_volume_ml": None,
            "calibration": "UNCALIBRATED",
        }
