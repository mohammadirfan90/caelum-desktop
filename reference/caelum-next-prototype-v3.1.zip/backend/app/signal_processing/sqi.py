import numpy as np
from scipy import signal, stats
from typing import Tuple

class SignalQualityAssessor:
    """
    Computes Signal Quality Index (SQI) for physiological waveforms.
    Evaluates:
    - kSQI (Kurtosis of ECG signal: normal QRS exhibits kurtosis > 5)
    - sSQI (Skewness of ECG signal)
    - basSQI (Relative power in baseline wander band < 1 Hz)
    - hfSQI (Relative high-frequency noise > 45 Hz)
    """
    @staticmethod
    def evaluate_ecg_quality(signal_data: np.ndarray, fs: int = 250) -> Tuple[str, float]:
        if len(signal_data) < fs * 2:
            return "UNKNOWN", 0.0

        # 1. Kurtosis (QRS peaks lead to leptokurtic distribution)
        kurt = stats.kurtosis(signal_data)

        # 2. Clipping or flatline check
        diffs = np.diff(signal_data)
        zero_diff_pct = np.sum(np.abs(diffs) < 1e-5) / len(diffs)
        if zero_diff_pct > 0.4:
            return "UNUSABLE", 0.0

        # 3. Dynamic range check
        std_val = np.std(signal_data)
        if std_val < 0.01:
            return "UNUSABLE", 0.0
        if std_val > 5000.0:
            return "POOR", 0.3

        # Normal kurtosis range for healthy lead II with clear QRS is ~5-25
        if kurt > 5.0 and zero_diff_pct < 0.05:
            score = min(1.0, 0.7 + (kurt / 50.0))
            return "GOOD", round(score, 2)
        elif kurt > 2.0:
            return "DEGRADED", 0.6
        else:
            return "POOR", 0.35

    @staticmethod
    def evaluate_ppg_quality(signal_data: np.ndarray, fs: int = 75) -> Tuple[str, float]:
        if len(signal_data) < fs * 2:
            return "UNKNOWN", 0.0
        x = np.asarray(signal_data, dtype=float)
        if np.std(x) < 1e-4:
            return "UNUSABLE", 0.0
        # Spectral concentration in the cardiac band (0.7-3.5 Hz = 42-210 bpm): a clean PPG has a
        # dominant pulse peak; motion artefact and noise spread power across the spectrum.
        f, pxx = signal.welch(x - np.mean(x), fs=fs, nperseg=min(len(x), fs * 8))
        band = (f >= 0.7) & (f <= 3.5)
        total = np.trapezoid(pxx[(f >= 0.3) & (f <= 8.0)], f[(f >= 0.3) & (f <= 8.0)])
        if total <= 0 or not np.any(band):
            return "UNUSABLE", 0.0
        k = int(np.argmax(np.where(band, pxx, 0)))
        peak = (f > f[k] - 0.15) & (f < f[k] + 0.15)
        ratio = float(np.trapezoid(pxx[peak], f[peak]) / total)
        if ratio > 0.45:
            return "GOOD", round(min(1.0, ratio + 0.3), 2)
        if ratio > 0.25:
            return "DEGRADED", round(ratio + 0.2, 2)
        return "POOR", round(ratio, 2)
