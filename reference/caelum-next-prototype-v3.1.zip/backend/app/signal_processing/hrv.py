import numpy as np
from scipy import signal
from typing import Dict

class HRVProcessor:
    """
    Standard clinical and aerospace Heart Rate Variability (HRV) calculator.
    Processes validated NN intervals into time-domain and frequency-domain metrics.
    """

    @staticmethod
    def calculate_time_domain(rr_intervals_ms: np.ndarray) -> Dict[str, float]:
        """
        Calculates SDNN, RMSSD, Mean NN, and pNN50.
        """
        # Filter physiological RR bounds (300 ms to 2000 ms)
        clean_rr = rr_intervals_ms[(rr_intervals_ms >= 300) & (rr_intervals_ms <= 2000)]
        if len(clean_rr) < 3:
            return {"mean_nn": None, "sdnn": None, "rmssd": None, "pnn50": None,
                    "valid_count": len(clean_rr)}

        mean_nn = float(np.mean(clean_rr))
        sdnn = float(np.std(clean_rr, ddof=1))

        successive_diffs = np.diff(clean_rr)
        rmssd = float(np.sqrt(np.mean(successive_diffs ** 2)))

        nn50_count = np.sum(np.abs(successive_diffs) > 50.0)
        pnn50 = float((nn50_count / len(successive_diffs)) * 100.0)

        return {
            "mean_nn": round(mean_nn, 1),
            "sdnn": round(sdnn, 1),
            "rmssd": round(rmssd, 1),
            "pnn50": round(pnn50, 1),
            "valid_count": int(len(clean_rr))
        }

    @staticmethod
    def calculate_frequency_domain(rr_intervals_ms: np.ndarray, resample_fs: float = 4.0) -> Dict[str, float]:
        """
        Calculates spectral metrics: VLF, LF (0.04 - 0.15 Hz), HF (0.15 - 0.40 Hz), and LF/HF ratio.
        Requires evenly interpolated RR series.
        """
        clean_rr = rr_intervals_ms[(rr_intervals_ms >= 300) & (rr_intervals_ms <= 2000)]
        if len(clean_rr) < 16:
            return {"lf_power": None, "hf_power": None, "lf_hf_ratio": None}

        time_points = np.cumsum(clean_rr) / 1000.0
        time_points -= time_points[0]

        # Linear interpolation to uniform sampling rate
        uniform_time = np.arange(0, time_points[-1], 1.0 / resample_fs)
        if len(uniform_time) < 16:
            return {"lf_power": None, "hf_power": None, "lf_hf_ratio": None}

        interpolated_rr = np.interp(uniform_time, time_points, clean_rr)
        interpolated_rr -= np.mean(interpolated_rr)

        # Welch power spectral density
        freqs, psd = signal.welch(interpolated_rr, fs=resample_fs, nperseg=min(len(interpolated_rr), 256))

        lf_band = (freqs >= 0.04) & (freqs < 0.15)
        hf_band = (freqs >= 0.15) & (freqs < 0.40)

        lf_power = float(np.trapezoid(psd[lf_band], freqs[lf_band])) if np.any(lf_band) else 0.0
        hf_power = float(np.trapezoid(psd[hf_band], freqs[hf_band])) if np.any(hf_band) else 0.0

        lf_hf_ratio = float(lf_power / hf_power) if hf_power > 0 else None

        return {
            "lf_power": round(lf_power, 2),
            "hf_power": round(hf_power, 2),
            "lf_hf_ratio": round(lf_hf_ratio, 2) if lf_hf_ratio is not None else None
        }
