import numpy as np
from scipy import signal
from typing import Optional

class ECGProcessor:
    """
    Standard SciPy-based biomedical ECG signal processor.
    Implements bandpass filtering (0.5 - 40 Hz), 50/60 Hz powerline notch filtering,
    Pan-Tompkins QRS detector, and RR-interval extraction.
    """
    def __init__(self, sampling_rate: int = 250):
        self.fs = sampling_rate

    def bandpass_filter(self, data: np.ndarray, lowcut: float = 0.5, highcut: float = 40.0, order: int = 3) -> np.ndarray:
        """Butterworth bandpass filter for baseline wander and high-frequency noise removal."""
        if len(data) < 15:
            return data
        nyquist = 0.5 * self.fs
        low = lowcut / nyquist
        high = highcut / nyquist
        b, a = signal.butter(order, [low, high], btype='band')
        return signal.filtfilt(b, a, data)

    def notch_filter(self, data: np.ndarray, notch_freq: float = 60.0, quality_factor: float = 30.0) -> np.ndarray:
        """Digital notch filter for powerline interference."""
        if len(data) < 15:
            return data
        nyquist = 0.5 * self.fs
        freq = notch_freq / nyquist
        if freq >= 1.0:
            return data
        b, a = signal.iirnotch(freq, quality_factor)
        return signal.filtfilt(b, a, data)

    def pan_tompkins_qrs_detect(self, ecg_signal: np.ndarray) -> np.ndarray:
        """
        Pan-Tompkins QRS detection algorithm:
        1. Derivative filter
        2. Squaring function
        3. Moving window integrator
        4. Adaptive threshold peak detection
        """
        if len(ecg_signal) < self.fs:
            return np.array([], dtype=int)

        # 0. Pan-Tompkins band-pass (5-15 Hz) isolates QRS energy from baseline wander/T waves
        nyq = 0.5 * self.fs
        b, a = signal.butter(2, [5.0 / nyq, 15.0 / nyq], btype="band")
        ecg_signal = signal.filtfilt(b, a, ecg_signal)

        # 1. Differentiation
        diff = np.diff(ecg_signal)

        # 2. Squaring
        squared = diff ** 2

        # 3. Moving-window integration (~150 ms window)
        window_size = int(0.15 * self.fs)
        if window_size < 1:
            window_size = 1
        window = np.ones(window_size) / window_size
        integrated = np.convolve(squared, window, mode='same')

        # 4. Adaptive peak finding
        min_distance = int(0.3 * self.fs) # refractory period 300 ms (max 200 bpm)
        # Adaptive threshold on rolling 2 s segments (robust to amplitude changes)
        seg = 2 * self.fs
        thr = np.empty_like(integrated)
        for i in range(0, len(integrated), seg):
            chunk = integrated[i:i + seg]
            thr[i:i + seg] = 0.3 * np.percentile(chunk, 99)
        peaks, _ = signal.find_peaks(integrated, height=thr, distance=min_distance)
        # Refine to the true R peak in the band-passed signal (+/- 75 ms search)
        w = int(0.075 * self.fs)
        refined = [max(0, p - w) + int(np.argmax(np.abs(ecg_signal[max(0, p - w):p + w]))) for p in peaks]
        return np.unique(np.array(refined, dtype=int))

    def compute_rr_intervals(self, r_peaks: np.ndarray) -> np.ndarray:
        """Computes RR intervals in milliseconds from peak indices."""
        if len(r_peaks) < 2:
            return np.array([], dtype=float)
        rr_samples = np.diff(r_peaks)
        rr_ms = (rr_samples / self.fs) * 1000.0
        return rr_ms

    def calculate_instantaneous_heart_rate(self, rr_intervals_ms: np.ndarray) -> Optional[float]:
        """Median heart rate in bpm. Returns None (never 0.0) when it cannot be computed."""
        if len(rr_intervals_ms) == 0:
            return None
        # Median filter to avoid ectopic spikes
        valid_rr = rr_intervals_ms[(rr_intervals_ms >= 300) & (rr_intervals_ms <= 2000)]
        if len(valid_rr) == 0:
            return None
        median_rr = np.median(valid_rr)
        return float(60000.0 / median_rr)
