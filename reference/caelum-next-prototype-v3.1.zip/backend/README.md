# CAELUM Backend Service
Authoritative Python FastAPI service for Astronaut Health Intelligence.
