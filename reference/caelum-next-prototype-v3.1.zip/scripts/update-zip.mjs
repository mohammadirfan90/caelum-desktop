import { execSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '..');
const pythonScript = path.join(projectRoot, 'scripts', 'package_codebase.py');

console.log('📦 Delegating codebase packaging to scripts/package_codebase.py...');

try {
  execSync(`python "${pythonScript}"`, {
    cwd: projectRoot,
    stdio: 'inherit',
    windowsHide: true,
  });
} catch (error) {
  console.error('❌ Failed to package codebase:', error.message);
  process.exit(1);
}
