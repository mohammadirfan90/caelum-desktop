#!/usr/bin/env python3
"""One-command pitch demo (Windows, macOS, Linux).

Starts the onboard server with the labelled simulator for all 3 crew, builds and starts the
crew app in live mode, then opens the sign-in page. Ctrl+C stops everything.

    python scripts/demo.py            # production build (smoothest for a pitch)
    python scripts/demo.py --dev      # hot-reload dev server (faster start, slower first clicks)
"""
import os
import shutil
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND, FRONTEND = ROOT / "backend", ROOT / "frontend"
IS_WIN = os.name == "nt"


def need(tool: str, hint: str) -> str:
    path = shutil.which(tool)
    if not path:
        sys.exit(f"[demo] '{tool}' not found. {hint}")
    return path


def run(cmd, cwd, env=None):
    print(f"[demo] $ {' '.join(cmd)}")
    subprocess.run(cmd, cwd=cwd, env=env, check=True, shell=IS_WIN)


def wait_for(url: str, seconds: int = 120) -> bool:
    for _ in range(seconds):
        try:
            urllib.request.urlopen(url, timeout=2)
            return True
        except Exception:
            time.sleep(1)
    return False


def main():
    dev = "--dev" in sys.argv
    need("uv", "Install: https://docs.astral.sh/uv/getting-started/installation/")
    pnpm = "pnpm" if shutil.which("pnpm") else None
    if not pnpm:
        need("npx", "Install Node.js 20+ from https://nodejs.org")
        pnpm = "npx"
    pn = [pnpm] if pnpm == "pnpm" else ["npx", "-y", "pnpm@9"]

    run(["uv", "sync", "--extra", "dev", "-q"], BACKEND)
    run([*pn, "install"], ROOT)

    demo_db = BACKEND / "caelum_demo.db"
    for f in (demo_db, demo_db.with_suffix(".db-wal"), demo_db.with_suffix(".db-shm")):
        f.unlink(missing_ok=True)
    benv = {**os.environ, "CAELUM_PROFILE": "local_dev", "CAELUM_ENABLE_SIMULATOR": "true",
            "CAELUM_DEMO_TIME_SCALE": "0.1", "CAELUM_DATABASE_URL": "sqlite:///./caelum_demo.db"}
    fenv = {**os.environ, "NEXT_PUBLIC_DATA_MODE": "live", "NEXT_PUBLIC_DEMO_LOGIN": "true",
            "NEXT_PUBLIC_BACKEND_URL": "http://127.0.0.1:8000",
            "NEXT_PUBLIC_WS_URL": "ws://127.0.0.1:8000/ws/telemetry", "NEXT_TELEMETRY_DISABLED": "1"}

    procs = [subprocess.Popen(["uv", "run", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8000"],
                              cwd=BACKEND, env=benv, shell=IS_WIN)]
    try:
        if dev:
            procs.append(subprocess.Popen([*pn, "--filter", "caelum-frontend", "dev"], cwd=ROOT, env=fenv, shell=IS_WIN))
        else:
            run([*pn, "--filter", "caelum-frontend", "build"], ROOT, fenv)
            procs.append(subprocess.Popen([*pn, "--filter", "caelum-frontend", "start"], cwd=ROOT, env=fenv, shell=IS_WIN))
        if not wait_for("http://127.0.0.1:8000/api/v1/health"):
            sys.exit("[demo] backend did not start")
        if wait_for("http://127.0.0.1:3000/login"):
            print("\n[demo] Ready.\n"
                  "  Crew app:          http://localhost:3000/login   (pick a role, no password needed)\n"
                  "  Presenter console: http://localhost:3000/presenter\n"
                  "  API docs:          http://localhost:8000/docs\n"
                  "  Press Ctrl+C to stop.\n")
            webbrowser.open("http://localhost:3000/login")
        while all(p.poll() is None for p in procs):
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        for p in procs:
            if p.poll() is None:
                p.terminate()
        for p in procs:
            try:
                p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                p.kill()


if __name__ == "__main__":
    main()
