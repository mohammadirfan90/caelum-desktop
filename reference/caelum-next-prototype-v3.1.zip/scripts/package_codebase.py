#!/usr/bin/env python3
"""
Automated Source Packager for CAELUM Platform.
Packages clean codebase atomically into caelum-next.zip with SHA-256 verification.
Excludes node_modules, .next, .venv, build artifacts, databases, and secrets.
"""

import os
import sys
import zipfile
import hashlib
import tempfile
import shutil
from pathlib import Path

if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

EXCLUDED_DIRS = {
    "node_modules",
    ".next",
    ".venv",
    "venv",
    "__pycache__",
    ".git",
    ".pytest_cache",
    ".turbo",
    "dist",
    "build",
    ".gemini"
}

EXCLUDED_FILES = {
    "caelum-next.zip",
    "caelum-next.zip.sha256",
    "caelum_onboard.db",
    "caelum_demo.db",
    "caelum_demo.db-wal",
    "caelum_demo.db-shm",
    "caelum_onboard.db-wal",
    "caelum_onboard.db-shm",
    ".DS_Store",
    "Thumbs.db",
    "tsconfig.tsbuildinfo"
}

REQUIRED_DIRS = [
    "frontend",
    "backend",
    "acquisition",
    "interoperability",
    "docs",
    "scripts"
]

def calculate_sha256(filepath: Path) -> str:
    hasher = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            hasher.update(chunk)
    return hasher.hexdigest()

def is_permitted(path: Path, root: Path) -> bool:
    rel_parts = path.relative_to(root).parts
    for part in rel_parts:
        if part in EXCLUDED_DIRS:
            return False
    if path.name in EXCLUDED_FILES:
        return False
    if path.name.endswith(".zip") or path.name.endswith(".pyc") or path.name.endswith(".log"):
        return False
    return True

def package_codebase():
    root = Path(__file__).resolve().parent.parent
    dest_zip = root / "caelum-next.zip"
    parent_zip = root.parent / "caelum-next.zip"
    sha_file = root / "caelum-next.zip.sha256"
    
    print("=" * 70)
    print("[PACK] CAELUM PLATFORM ATOMIC SOURCE CODE PACKAGER")
    print("=" * 70)
    print(f"[ROOT] Repository Root: {root}")
    
    # 1. Run secret scanner first
    scanner_path = root / "scripts" / "check_secrets.py"
    if scanner_path.exists():
        print("[CHECK] Executing secret scanner verification...")
        import subprocess
        proc = subprocess.run([sys.executable, str(scanner_path)], cwd=str(root))
        if proc.returncode != 0:
            print("[ERROR] Secret check failed! Aborting packaging.")
            sys.exit(1)
            
    # 2. Collect permitted files
    files_to_pack = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in EXCLUDED_DIRS]
        for f in filenames:
            p = Path(dirpath) / f
            if is_permitted(p, root):
                files_to_pack.append(p)
                
    print(f"[COLLECT] Collected {len(files_to_pack)} permitted source files.")
    
    # 3. Create archive in temporary location
    with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp_file:
        tmp_zip_path = Path(tmp_file.name)
        
    try:
        with zipfile.ZipFile(tmp_zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipf:
            for p in files_to_pack:
                arcname = p.relative_to(root).as_posix()
                zipf.write(p, arcname=arcname)
                
        # 4. Verify ZIP integrity and validate required directories
        with zipfile.ZipFile(tmp_zip_path, "r") as test_zip:
            bad_file = test_zip.testzip()
            if bad_file:
                raise RuntimeError(f"Corrupted entry in archive: {bad_file}")
            names = test_zip.namelist()
            for rd in REQUIRED_DIRS:
                if not any(n.startswith(rd + "/") for n in names):
                    raise RuntimeError(f"Missing required subsystem directory in archive: {rd}")
                    
        # 5. Atomic replacement
        shutil.move(str(tmp_zip_path), str(dest_zip))
        shutil.copyfile(str(dest_zip), str(parent_zip))
        
        # 6. Generate SHA-256
        checksum = calculate_sha256(dest_zip)
        sha_file.write_text(f"{checksum}  caelum-next.zip\n", encoding="utf-8")
        
        stat = dest_zip.stat()
        print("[SUCCESS] Archive verified and packaged successfully!")
        print(f"   - Location:  {dest_zip} ({stat.st_size / 1024:.1f} KB)")
        print(f"   - Parent:    {parent_zip}")
        print(f"   - SHA-256:   {checksum}")
        print("=" * 70)
        
    finally:
        if tmp_zip_path.exists():
            try:
                tmp_zip_path.unlink()
            except Exception:
                pass

if __name__ == "__main__":
    package_codebase()
