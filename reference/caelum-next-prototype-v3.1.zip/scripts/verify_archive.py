#!/usr/bin/env python3
"""
Archive Integrity and Content Verification for CAELUM Platform.
Validates caelum-next.zip against structural rules, corruption checks, and SHA-256 checksums.
"""

import sys
import zipfile
import hashlib
from pathlib import Path

if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

REQUIRED_SUBSYSTEMS = [
    "frontend/",
    "backend/",
    "acquisition/",
    "interoperability/",
    "docs/",
    "scripts/"
]

FORBIDDEN_PATTERNS = [
    "node_modules/",
    ".next/",
    ".venv/",
    "__pycache__/",
    ".git/",
    ".pyc",
    ".db",
    ".log",
    "caelum-next.zip"
]

def main():
    root = Path(__file__).resolve().parent.parent
    zip_path = root / "caelum-next.zip"
    sha_path = root / "caelum-next.zip.sha256"
    
    print("=" * 70)
    print("[VERIFY] CAELUM PLATFORM ARCHIVE INTEGRITY VERIFICATION")
    print("=" * 70)
    
    if not zip_path.exists():
        print(f"[ERROR] Error: Archive {zip_path} not found.")
        sys.exit(1)
        
    # 1. Test ZIP validity
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            corrupt = zf.testzip()
            if corrupt:
                print(f"[ERROR] CRC Error: Corrupted file detected in archive: {corrupt}")
                sys.exit(1)
                
            entries = zf.namelist()
            print(f"[OK] Archive format valid. Contains {len(entries)} files.")
            
            # 2. Check required subsystems
            for req in REQUIRED_SUBSYSTEMS:
                if not any(e.startswith(req) for e in entries):
                    print(f"[ERROR] Structural Error: Required subsystem directory '{req}' is missing.")
                    sys.exit(1)
            print(f"[OK] All {len(REQUIRED_SUBSYSTEMS)} required subsystem structures present.")
            
            # 3. Check forbidden patterns
            leaked = []
            for pattern in FORBIDDEN_PATTERNS:
                matches = [e for e in entries if pattern in e]
                if matches:
                    leaked.extend(matches)
            if leaked:
                print(f"[ERROR] Leakage Error: Forbidden files found in archive:\n  " + "\n  ".join(leaked[:5]))
                sys.exit(1)
            print("[OK] Zero forbidden build/cache/secret files detected.")
            
    except Exception as e:
        print(f"[ERROR] Failed to inspect archive: {str(e)}")
        sys.exit(1)
        
    # 4. Verify checksum
    if sha_path.exists():
        expected_sha = sha_path.read_text(encoding="utf-8").split()[0].strip()
        hasher = hashlib.sha256()
        with open(zip_path, "rb") as f:
            while chunk := f.read(65536):
                hasher.update(chunk)
        actual_sha = hasher.hexdigest()
        
        if expected_sha.lower() == actual_sha.lower():
            print(f"[OK] SHA-256 Checksum Verified: {actual_sha}")
        else:
            print(f"[ERROR] Checksum mismatch!\nExpected: {expected_sha}\nActual:   {actual_sha}")
            sys.exit(1)
            
    size_kb = zip_path.stat().st_size / 1024
    print(f"[SUCCESS] Verification successful! caelum-next.zip is production-ready ({size_kb:.1f} KB).")
    print("=" * 70)
    sys.exit(0)

if __name__ == "__main__":
    main()
