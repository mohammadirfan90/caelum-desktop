#!/usr/bin/env python3
"""
Pre-commit / Pre-packaging Secret Scanner for CAELUM Platform.
Scans source files for leaked private keys, API secrets, and sensitive tokens.
"""

import os
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

# Sensitive patterns to block
SECRET_PATTERNS = [
    (r"-----BEGIN (?:RSA|OPENSSH|EC|PGP|PRIVATE) KEY-----", "Private cryptographic key"),
    (r"(?:api_key|apiKey|secret_key|secretKey)\s*[:=]\s*['\"][A-Za-z0-9+/=_-]{32,}['\"]", "API or secret token"),
    (r"ghp_[A-Za-z0-9_]{36}", "GitHub Personal Access Token"),
    (r"ey[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+\.?[A-Za-z0-9-_.+/=]*", "JWT token in source"),
    (r"AWS_SECRET_ACCESS_KEY\s*[:=]\s*['\"][A-Za-z0-9+/=]{40}['\"]", "AWS secret key"),
]

EXCLUDE_DIRS = {
    ".git", ".next", "node_modules", ".venv", "__pycache__", "dist", "build", ".pytest_cache"
}

def scan_file(file_path: Path) -> list:
    violations = []
    # Skip binary files or archives
    if file_path.suffix.lower() in [".zip", ".png", ".jpg", ".ico", ".woff", ".woff2", ".db", ".sqlite", ".pyc"]:
        return violations
        
    try:
        content = file_path.read_text(encoding="utf-8", errors="ignore")
        for pattern, label in SECRET_PATTERNS:
            # Skip test fixtures that intentionally test fake tokens
            if "test" in str(file_path).lower() and "caelum-flight-secret-key" in content:
                continue
            if "settings.py" in str(file_path).lower() and "caelum-flight-secret-key" in content:
                continue
            if ".env.example" in str(file_path).lower():
                continue
            if re.search(pattern, content):
                violations.append((label, pattern))
    except Exception as e:
        pass
    return violations

def main():
    root_dir = Path(__file__).resolve().parent.parent
    print(f"[SCAN] Scanning repository for sensitive secrets at: {root_dir}")
    
    total_files = 0
    total_violations = 0
    
    for dirpath, dirnames, filenames in os.walk(root_dir):
        # Exclude ignored directories
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
        
        for filename in filenames:
            file_path = Path(dirpath) / filename
            total_files += 1
            violations = scan_file(file_path)
            if violations:
                total_violations += len(violations)
                for label, pattern in violations:
                    print(f"  [VIOLATION] {file_path.relative_to(root_dir)}: {label}")
                    
    if total_violations == 0:
        print(f"[OK] Secret scan passed cleanly across {total_files} files.")
        sys.exit(0)
    else:
        print(f"[FAILED] Secret scan failed with {total_violations} violation(s).")
        sys.exit(1)

if __name__ == "__main__":
    main()
