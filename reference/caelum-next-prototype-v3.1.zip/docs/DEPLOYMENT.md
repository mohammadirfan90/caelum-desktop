# CAELUM — Deployment & Data Storage Architecture

## Overview
CAELUM supports three deployment profiles:
1. **Local Development Profile**: Runs on development workstations with mock hardware simulation and local SQLite.
2. **Onboard Spacecraft Profile**: Runs autonomously on an approved onboard service host with embedded SQLite WAL mode storage, zero cloud dependence, and store-and-forward queueing.
3. **Ground Medical Operations Profile**: Deployed at mission control with PostgreSQL storage, Yamcs / Open MCT ingestion, and flight surgeon review console.

---

## 7. Data Storage Architecture

```mermaid
flowchart TB
    subgraph DataIngestionLayer["Data Ingestion"]
        HighFreqData["High-Frequency Telemetry<br/>(250Hz ECG, 25Hz Respiration)"]
        LowFreqObs["Discrete Observations<br/>(HR, SpO2, Temp, Radiation, ECLSS)"]
        ClinicalEvents["Clinical Events & SBAR Reports"]
    end

    subgraph StorageManager["CAELUM Storage Subsystem (SQLAlchemy 2)"]
        direction TB
        subgraph OnboardProfile["Onboard Mode (Embedded / Offline-First)"]
            SQLiteWAL[("SQLite 3 with Write-Ahead Logging (WAL)<br/>Synchronous=NORMAL, ForeignKeys=ON<br/>File: caelum_onboard.db")]
        end
        subgraph GroundProfile["Ground Mission Mode (High-Concurrency)"]
            PostgresStore[("PostgreSQL 16 Enterprise Database<br/>Partitioned Time-Series Tables")]
        end
        
        AuditChain[("Cryptographic SHA-256 Audit Ledger<br/>(Tamper-Evident Chained Records)")]
    end

    subgraph ClientAccess["Authorized Query & Access"]
        QueryCache["TanStack Query Client State"]
        DownlinkManager["Downlink Queue Reader"]
    end

    HighFreqData --> StorageManager
    LowFreqObs --> StorageManager
    ClinicalEvents --> StorageManager
    
    StorageManager --> AuditChain
    StorageManager --> QueryCache
    StorageManager --> DownlinkManager
```
