# CAELUM — Codebase Packaging & ZIP Release Workflow

## Overview
CAELUM maintains continuous, verified source code distribution via `caelum-next.zip`. Packaging is fully automated, preventing ZIP recursion, scanning for secrets, verifying format and structural integrity, and producing SHA-256 checksums.

---

## 10. Automated Source Code Packaging & Release Pipeline

```mermaid
flowchart TD
    Trigger["Code Change Completed / CI Release Triggered"] --> PreScan["Execute `scripts/check_secrets.py`<br/>(Scan for leaked keys, tokens, credentials)"]
    
    PreScan -- Secrets Found --> Abort["Halt Build Immediately with Exit Code 1"]
    PreScan -- Clean --> FilterFiles["Collect Permitted Source Files<br/>(Exclude node_modules, .next, .venv, *.zip, *.pyc)"]
    
    FilterFiles --> CreateTmp["Create Archive in Temp Location<br/>(ZIP_DEFLATED, Level 9 Compression)"]
    CreateTmp --> VerifyArchive["Execute `scripts/verify_archive.py`<br/>(Test ZIP integrity, validate required directories)"]
    
    VerifyArchive -- CRC Error / Missing Dirs --> Abort
    VerifyArchive -- Valid --> AtomicReplace["Atomically Replace `caelum-next.zip`<br/>(Project root and parent copy)"]
    
    AtomicReplace --> GenSHA["Generate SHA-256 Checksum<br/>(Save to `caelum-next.zip.sha256`)"]
    GenSHA --> ReleaseReady["Release Artifact Production-Ready"]
```

---

## Execution Commands

### In PowerShell / Bash:
```bash
# Full packaging run (includes secret scanning, compression, and verification)
python scripts/package_codebase.py

# Standalone integrity validation
python scripts/verify_archive.py

# Standalone secret scanner
python scripts/check_secrets.py

# Using npm / pnpm
npm run zip
npm run verify:zip
npm run check:secrets
```
