# CAELUM — Medical Record Interoperability & HL7 FHIR

## Overview
CAELUM integrates with onboard electronic health systems using standard HL7 FHIR Release 4 (R4) resource models. Rather than dumping raw, noisy high-frequency sensor ticks into the medical ledger, CAELUM converts validated clinical encounters, physiological summaries, and verified alerts into FHIR Observations and DiagnosticReports.

---

## 4. Medical Record Integration Architecture

```mermaid
flowchart TB
    subgraph CAELUM_Clinical["CAELUM Clinical Core"]
        RawVitals["Continuous Bio-Signals<br/>(ECG, Respiration, SpO2, Temp)"]
        FeatureProc["Feature Processing & SQI Validation"]
        Alerts["Reviewed Clinical Alert Events"]
        Encounter["Crew Medical Check-ins & Triage (SBAR)"]
    end

    subgraph InteroperabilityAdapter["FHIR Interoperability Engine (`interoperability/fhir/`)"]
        ObsBuilder["FHIR Observation Builder<br/>(LOINC 8867-4, 2708-6, 9279-1, 8310-5)"]
        DiagReport["FHIR DiagnosticReport Builder<br/>(LOINC 11524-6 Study Summary)"]
        ConditionBuilder["FHIR Condition Builder<br/>(Clinical Observations & Symptoms)"]
    end

    subgraph MedicalRecords["Onboard / Ground Medical Health Record System"]
        EHR[("Onboard Electronic Health Record (EHR)<br/>(Encrypted, Access-Controlled)")]
        SurgeonConsole["Flight Surgeon Review Console"]
    end

    RawVitals --> FeatureProc
    FeatureProc --> ObsBuilder
    Alerts --> ConditionBuilder
    Encounter --> DiagReport
    FeatureProc --> DiagReport

    ObsBuilder ==> EHR
    DiagReport ==> EHR
    ConditionBuilder ==> EHR

    EHR ==> SurgeonConsole
```

---

## Standard LOINC Coding Map

| Clinical Parameter | LOINC Code | Display Name | Standard Unit | UCUM Code |
| :--- | :--- | :--- | :--- | :--- |
| **Heart Rate** | `8867-4` | Heart rate | beats/minute | `/min` |
| **Blood Oxygen (SpO₂)** | `2708-6` | Oxygen saturation in Arterial blood | % | `%` |
| **Respiratory Rate** | `9279-1` | Respiratory rate | breaths/minute | `/min` |
| **Body Temperature** | `8310-5` | Body temperature | degC | `Cel` |
| **Systolic Blood Pressure** | `8480-6` | Systolic blood pressure | mmHg | `mm[Hg]` |
| **Diastolic Blood Pressure** | `8462-4` | Diastolic blood pressure | mmHg | `mm[Hg]` |
| **Cabin CO₂ Concentration** | `82654-5` | Carbon dioxide partial pressure | ppm | `ppm` |
