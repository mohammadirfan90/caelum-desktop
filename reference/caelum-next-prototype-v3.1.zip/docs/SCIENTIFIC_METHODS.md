# CAELUM — Scientific Methods & Biomedical Signal Processing

## Overview
CAELUM executes defensible physiological signal processing implemented in Python using SciPy and NumPy. This ensures transparent, scientifically traceable feature extraction from raw biopotential and optical waveforms.

---

## 5. Real-Time Biomedical Signal Processing Pipeline

```mermaid
flowchart TD
    RawECG["Raw Biopotential ECG (250 Hz)"] --> BPF["Butterworth Bandpass Filter<br/>(0.5 - 40 Hz, Order 3)"]
    BPF --> Notch["Notch Filter (50/60 Hz Powerline Rejection)"]
    Notch --> SQI["Signal Quality Index Assessor (kSQI & sSQI)"]
    
    SQI --> PT_Diff["Pan-Tompkins: First Derivative"]
    PT_Diff --> PT_Sq["Pan-Tompkins: Squaring Function"]
    PT_Sq --> PT_MVI["Pan-Tompkins: Moving Window Integrator (150 ms)"]
    PT_MVI --> PeakDetect["Adaptive Threshold Peak Detector (300 ms Refractory)"]
    
    PeakDetect --> RPeaks["Identified R-Peaks (Timestamped)"]
    RPeaks --> RRIntervals["RR / NN Interval Calculation (ms)"]
    RRIntervals --> EctopicRejection["Ectopic & Non-Sinus Beat Filter"]
    
    EctopicRejection --> TimeHRV["Time-Domain HRV Metrics<br/>(Mean NN, SDNN, RMSSD, pNN50)"]
    EctopicRejection --> Resample["Interpolate to Uniform 4 Hz Time Grid"]
    Resample --> WelchPSD["Welch Power Spectral Density (PSD)"]
    WelchPSD --> FreqHRV["Frequency-Domain HRV Metrics<br/>(LF: 0.04-0.15Hz, HF: 0.15-0.40Hz, LF/HF Ratio)"]
```

---

## Signal Processing Specifications

### 1. ECG Conditioning & QRS Detection
- **Bandpass Filter**: 3rd-order Butterworth zero-phase forward-backward filter (`scipy.signal.filtfilt`) between 0.5 Hz (removes respiration baseline wander) and 40 Hz (attenuates EMG muscle tremor noise).
- **Notch Filter**: Digital IIR notch filter at 50/60 Hz with quality factor $Q = 30$ to reject spacecraft instrumentation powerline interference.
- **Pan-Tompkins Algorithm**: Detects QRS complexes through successive differentiation, squaring, moving integration across a 150 ms window, and dual adaptive amplitude/noise thresholding with a 300 ms refractory blanking period.

### 2. Autonomic Tone & HRV Calculations
- **RMSSD**: Root mean square of successive NN differences; serves as the primary index of parasympathetic (vagal) cardiac control during spaceflight sleep and rest.
- **SDNN**: Standard deviation of all NN intervals; reflects total cyclic autonomic variability.
- **pNN50**: Percentage of adjacent NN intervals that differ by more than 50 milliseconds.
- **Spectral Bands**: Welch periodogram integrates low-frequency (LF: 0.04–0.15 Hz) sympathetic/baroreflex power and high-frequency (HF: 0.15–0.40 Hz) respiratory sinus arrhythmia power to compute the autonomic balance ratio ($\text{LF}/\text{HF}$).

### 3. Respiratory Inductive Plethysmography (RIP)
- Dual-band chest and abdominal signals pass through an 0.8 Hz 2nd-order lowpass filter to suppress cardiac ballistic pulsations, followed by peak-trough volume calibration to estimate breath rate (breaths/min), tidal volume (mL), and minute ventilation (L/min).
