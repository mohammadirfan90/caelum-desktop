# CAELUM — Spacecraft Communications & Ground Operations

## Overview
Communication between spacecraft and Earth experiences high latency, low bandwidth windows, and frequent Loss of Signal (LOS). CAELUM implements a dedicated store-and-forward telemetry queue with priority-based sequencing and CCSDS Space Packet framing.

---

## 8. Spacecraft-to-Ground Communications Pipeline

```mermaid
flowchart LR
    subgraph OnboardCAELUM["CAELUM Onboard System"]
        EventGenerator["Clinical & Operational Events<br/>(Alerts, Summaries, Dosimetry)"]
        PrivacyFilter["Privacy Allowlist Filter<br/>(Redacts Private Notes & Diary Entries)"]
        StoreForward["Store-and-Forward Queue<br/>(Priority: CRITICAL, ROUTINE, RESEARCH)"]
        CCSDS_Encoder["CCSDS Packetizer<br/>(APID 0x01E4, Sequence Counter)"]
    end

    subgraph DeepSpaceNetwork["Space Communications Link (DSN / TDRS)"]
        RF_Link["Uplink / Downlink RF Carrier<br/>(Loss-of-Signal Resilient)"]
    end

    subgraph MissionControl["Ground Segment (Mission Control Center)"]
        CCSDS_Decoder["CCSDS Frame Demultiplexer"]
        OpenMCT_Bridge["NASA Open MCT Provider<br/>(Dictionary: caelum.health)"]
        FlightSurgeon_DB["Flight Surgeon Medical Repository"]
    end

    EventGenerator --> PrivacyFilter
    PrivacyFilter --> StoreForward
    StoreForward --> CCSDS_Encoder
    CCSDS_Encoder ==> RF_Link
    RF_Link ==> CCSDS_Decoder
    CCSDS_Decoder --> OpenMCT_Bridge
    CCSDS_Decoder --> FlightSurgeon_DB
```
