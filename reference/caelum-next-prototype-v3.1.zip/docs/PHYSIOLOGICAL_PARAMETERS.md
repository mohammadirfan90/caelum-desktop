# CAELUM — Physiological Parameter Catalog

## Overview
Comprehensive parameter registry defining scientific units, native sampling rates, sensor sources, and measurement classifications across the platform.

---

## Catalog Table

| Parameter Key | Physiological Definition | Canonical Unit | Sampling Rate | Primary Hardware Source | Classification |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `ecg_lead_ii` | Lead II cardiac biopotential waveform | mV | 250 Hz | AstroSkin Bio-Vest | Direct Measured |
| `hr` | Instantaneous Heart Rate | bpm | 1 Hz | AstroSkin / PPG | Derived (Pan-Tompkins) |
| `hrv_rmssd` | Heart Rate Variability (rMSSD) | ms | Rolling 5-min | AstroSkin ECG | Derived (Successive Diff) |
| `hrv_sdnn` | Heart Rate Variability (SDNN) | ms | Rolling 24-hr | AstroSkin ECG | Derived (Total Variance) |
| `spo2` | Functional Arterial Oxygen Saturation | % | 1 Hz | AstroSkin Optical Headband | Direct Optical |
| `respiration_rate`| Breaths per minute | breaths/min | 25 Hz RIP band | AstroSkin Dual Band | Derived (Peak-to-Peak) |
| `tidal_volume` | Estimated breathing tidal volume | mL | 25 Hz RIP band | AstroSkin Dual Band | Estimated (Calibrated) |
| `eda_usiemens` | Electrodermal skin conductance | µS | 4 Hz | Wrist Biometric Module | Direct Measured |
| `peripheral_temp`| Distal skin temperature | °C | 4 Hz | Wrist Biometric Module | Direct Measured |
| `core_temp` | Deep body core temperature | °C | Episodic | Ingestible / Telemetric Capsule | Direct Measured |
| `bp_systolic` | Systolic arterial pressure | mmHg | Episodic | Clinical NIBP Monitor | Direct Oscillometric |
| `bp_diastolic` | Diastolic arterial pressure | mmHg | Episodic | Clinical NIBP Monitor | Direct Oscillometric |
| `radiation_dose` | Personal cumulative absorbed dose | mSv | Daily / Hourly | Personal Active Dosimeter | Direct Measured |
