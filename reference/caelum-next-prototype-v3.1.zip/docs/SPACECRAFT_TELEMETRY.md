# CAELUM — Spacecraft Environmental Telemetry Integration

## Overview
CAELUM consumes environmental, operational, and vehicle status telemetry from spacecraft avionics through an authorized, read-only bridge. The bridge is architecturally isolated to guarantee that medical software can never issue unauthorized flight or life-support commands.

---

## 1. Safety Isolation
1. **Unidirectional Ingestion**: All communication between the vehicle telemetry bus and CAELUM is inbound only. No command-and-control APIs or hardware control lines are linked to the health platform.
2. **Standardized Normalization**: Ingested telemetry is validated against physical sensor ranges and converted into standard SI/ISO units before storage or alert evaluation.

---

## 2. Ingested Telemetry Parameters

| Vehicle Parameter | Canonical Unit | Typical Flight Range | Warning Threshold | Critical Threshold |
| :--- | :--- | :--- | :--- | :--- |
| **Cabin Oxygen ($O_2$)** | kPa / % atm | 20.0 – 21.5 kPa (20.9%) | $< 19.5$ kPa | $< 18.0$ kPa |
| **Cabin Carbon Dioxide ($CO_2$)** | ppm / mmHg | 2,500 – 3,800 ppm | $> 3,800$ ppm | $> 5,000$ ppm |
| **Atmospheric Pressure** | kPa / mmHg | 101.3 kPa (1.0 atm) | $< 95.0$ kPa | $< 80.0$ kPa (Depress) |
| **Cabin Temperature** | °C | 20.0 – 24.0 °C | $> 26.5$ °C | $> 30.0$ °C |
| **Relative Humidity** | % | 40 – 60 % | $> 70$ % (Condensation) | $> 80$ % |
| **Active Radiation Rate** | µSv/h | 15 – 35 µSv/h (LEO) | $> 100$ µSv/h (SPE Warning) | $> 500$ µSv/h (SPE Shelter) |
| **Mission Elapsed Time (MET)** | Hours / Days | In-Flight Duration | — | — |
