# Implementation status (honest ledger, v3.1.0)

Legend: **Live** = backed by the FastAPI service and tested · **Demo** = demo data only (UI badge says so;
in live mode the module reports *not connected*) · **Planned** = designed, not implemented.

## Backend services
| Capability | Status | Evidence |
|---|---|---|
| Authentication (bcrypt + JWT), role and per-astronaut scoping | Live | `tests/test_api.py` |
| Ingestion pipeline (validation, units, plausibility, provenance) | Live | `test_api.py`, `test_alert_engine.py` |
| Alert engine: absolute limits, persistence, hysteresis, supersession | Live | `test_alert_engine.py` |
| Escalation (astronaut → medical officer → sound → crew → ground) | Live | `test_escalation_timeline_and_acknowledgement` |
| Personal baselines (median/MAD, observe-level only) | Live | engine + `/vitals/baselines` |
| Hash-chained HMAC audit log | Live | `test_audit_chain_detects_timestamp_tampering` |
| Downlink queue, per-channel allow-lists, sequence numbers | Live | `test_critical_alert_downlinks...` |
| WebSocket event stream (role-filtered) | Live | `test_websocket_requires_token` |
| Bluetooth SIG health profiles (HR, PLX, BP, thermometer) | Live | `test_ble_decoders.py` |
| FHIR R4 Observation import/export | Live | `test_fhir_round_trip` |
| CCSDS space packets, Open MCT dictionary | Live | `interoperability/tests` |
| Simulator (labelled SIMULATED end to end) | Live (dev only) | smoke test |
| Bluetooth GHS, IEEE 11073 SDC, DICOM ultrasound, ECG files, smart garment | Planned | `devices/registry.py` |
| ML models M1–M9 | Planned | fatigue score is a labelled heuristic |
| Fail-over instance, desktop packaging, native BLE gateway | Planned | see AUDIT_REPORT roadmap |

## Frontend
| Area | Status |
|---|---|
| Data-mode badge, login, authenticated HTTP client, live WebSocket store | Live |
| Alerts list, baselines, crew header, audit log | Live in live mode (no demo fallback) |
| Home / Heart / app frame live numbers | Live (telemetry store; NO DATA / STALE when not live) |
| Alerts screen: escalation tracker, acknowledge, crew-wide banner | Live |
| Presenter console, demo roles, simulator scenarios | Live (dev only) |
| Historical charts and summary tiles | Demo data set, also in live mode |
| Radiation, environment, mood, exercise, triage, hazards, validation, coach, timeline, twin, bone, vision, immune | Demo |
| Mission Control screens gated by server role | Live |
