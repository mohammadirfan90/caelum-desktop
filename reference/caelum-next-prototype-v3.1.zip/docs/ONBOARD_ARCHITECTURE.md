# CAELUM — Onboard Architecture & IPC Communication

## Overview
CAELUM separates persistent computation and acquisition from browser presentation. If crew members close browser tabs, background monitoring, alert evaluation, and downlink queuing continue without interruption.

---

## 3. Frontend / Backend Communication Architecture

```mermaid
sequenceDiagram
    autonumber
    actor Crew as Astronaut / Flight Surgeon
    participant UI as Next.js 16 Web Client (Browser)
    participant Proxy as Next.js App Router Proxy (/api/v1)
    participant API as FastAPI Authoritative Backend (:8000)
    participant WS as WebSocket Live Stream (/ws/telemetry)
    participant DB as SQLite WAL / PostgreSQL Store

    Note over API,DB: Background acquisition running continuously
    Crew->>UI: Opens Dashboard (http://localhost:3000)
    UI->>Proxy: GET /api/v1/crew/ast-01
    Proxy->>API: Forward authenticated request
    API->>DB: Query active astronaut profile
    DB-->>API: Return astronaut record
    API-->>Proxy: Return JSON
    Proxy-->>UI: Render Astronaut Identity & Profile
    
    UI->>WS: Establish WebSocket Connection (/ws/telemetry)
    WS-->>UI: Connection Accepted (Heartbeat active)
    
    loop Every 100ms (10 Hz Packet Burst)
        API->>WS: Send LiveTelemetryPacket (250Hz ECG chunks, Vitals, ECLSS)
        WS-->>UI: Real-time telemetry stream
        UI->>UI: Render live ECG canvas & vital tiles
    end

    Note over Crew,UI: Crew acknowledges clinical alert
    Crew->>UI: Clicks "Acknowledge Alert"
    UI->>Proxy: POST /api/v1/alerts/alt-01/acknowledge
    Proxy->>API: Execute state transition & audit log
    API->>DB: Update alert state & append SHA-256 audit entry
    DB-->>API: Success
    API-->>Proxy: 200 OK
    Proxy-->>UI: Update Alert Badge & Dismiss Notification
```
