# CAELUM — Hardware Integration & Sensor Acquisition

## Overview
CAELUM acquires physiological data through modular device adapters. Unrelated hardware is never connected directly into frontend UI components. All signals route through the persistent local acquisition gateway.

---

## 2. Sensor Acquisition Architecture

```mermaid
flowchart LR
    subgraph WearableHardware["Biomedical Wearable & Clinical Hardware"]
        AS_Vest["AstroSkin Smart Vest<br/>(3-Lead ECG 250Hz, Inductive Resp 25Hz)"]
        AS_Headband["AstroSkin Optical Headband<br/>(SpO2, Skin Temp)"]
        Wrist_E4["Physiological Wrist Module<br/>(EDA/GSR 4Hz, PPG 64Hz, Temp 4Hz)"]
        NIBP["Clinical Blood Pressure Monitor<br/>(Oscillometric)"]
        CoreT["Core Body Temp Sensor<br/>(Ingestible / Continuous)"]
    end

    subgraph AcquisitionAdapters["Hardware Acquisition Gateway"]
        AS_Adapter["AstroSkin Protocol Adapter<br/>(OneSDK Bridge / BLE)"]
        Wrist_Adapter["Wrist Module Adapter<br/>(BLE GATT Stream)"]
        NIBP_Adapter["Diagnostic Device Serial Adapter"]
        
        SyncEngine["MET Clock Drift Synchronizer"]
        SQI_Engine["Signal Quality Index (SQI) Evaluator<br/>(Kurtosis, Baseline Wander, Noise)"]
        RingBuffer["Persistent Buffer Queue<br/>(Dropout Recovery)"]
    end

    subgraph BackendCore["Authoritative Backend Ingestion"]
        Normalization["Unit Normalization (SI/ISO)"]
        Storage["SQLAlchemy 2 Ingest Service"]
        Streamer["WebSocket Telemetry Broadcaster"]
    end

    AS_Vest --> AS_Adapter
    AS_Headband --> AS_Adapter
    Wrist_E4 --> Wrist_Adapter
    NIBP --> NIBP_Adapter
    CoreT --> NIBP_Adapter

    AS_Adapter --> SyncEngine
    Wrist_Adapter --> SyncEngine
    NIBP_Adapter --> SyncEngine

    SyncEngine --> SQI_Engine
    SQI_Engine --> RingBuffer
    RingBuffer --> Normalization
    Normalization --> Storage
    Normalization --> Streamer
```

---

## Supported Hardware Specifications

| Device | Physiological Channels | Native Sampling Rate | Protocol / Transport |
| :--- | :--- | :--- | :--- |
| **AstroSkin Bio-Vest** | 3-Lead ECG (Lead I, II, III), Dual Inductive Plethysmography (Thorax + Abdomen) | ECG: 250 Hz, Resp: 25 Hz | BLE OneSDK Bridge |
| **AstroSkin Optical Headband** | Pulse Oximetry (SpO₂), Infrared Skin Temp | SpO₂: 1 Hz, Temp: 1 Hz | Serial / BLE Bridge |
| **Physiological Wristband** | Electrodermal Activity (EDA), Optical PPG, Skin Temp, 3-Axis IMU | EDA: 4 Hz, PPG: 64 Hz, IMU: 32 Hz | BLE GATT |
| **Clinical NIBP Monitor** | Systolic / Diastolic BP, Mean Arterial Pressure (MAP) | Episodic on request | Authenticated USB/Serial |
| **Active Radiation Dosimeter** | Personal Dose Equivalent Rate (Hp(10)), Cumulative Dose | 1 Hz / 10s integration | Spacecraft Sensor Bus |
