# Pitch guide: 5-minute live demo

## Setup (once, about 3 minutes)
```bash
python scripts/demo.py        # or: npm run demo
```
It installs dependencies, starts the onboard server with a **labelled simulator** for all 3 crew,
builds the crew app in live mode and opens the sign-in page. Ctrl+C stops everything. Each run
starts with a clean demo database.

Open two browser windows side by side:

| Window | Sign in as | Page |
|---|---|---|
| Left: "the astronaut" | Cdr. Ines Varga | `/` then `/alerts` |
| Right: "the presenter" | Flight surgeon | `/presenter` |

Optional third window: Lt. Maya Lin (another astronaut) to show the crew alert arriving.
Sign-in pages show one-click demo roles; no passwords needed.

## What is real and what is simulated (say this first)
The **sensors are simulated**; the badge in the corner always says so. Everything after the
sensor is the real software: data validation, the alert engine, escalation, the audit log, role
security and the downlink to the ground. Demo timing shortens only windows longer than 60 s
(fever, AF, CO2) so they fit in a pitch. Critical timings stay real.

## Script
| Time | Do | Say |
|---|---|---|
| 0:00 | Left window: home screen, live heart rate and SpO2 | "Varga wears our shirt and wristband. Data streams to the crew laptop, fully offline." |
| 0:30 | Presenter: **Loose sensor** on Varga | "Signals go bad. A naive system would alarm. Ours raises a sensor advisory only: no false alarm, so the crew keeps trusting it." |
| 1:00 | Presenter: **Normal day**, then **Oxygen dropping** | "Now a real problem. Watch SpO2 fall on the left." |
| 1:50 | Critical alert appears (~50 s) | "It fired only after 15 seconds below 85 %: persistence prevents flicker. The card says why, what to do, and who has been told." |
| 2:05 | Escalation reaches *Wristband sound* (+15 s) | "She hasn't responded, so the wristband sounds." |
| 2:20 | Escalation reaches *Whole crew* (+30 s): red banner on Lin's window | "Still no response. Every crewmate is alerted with location and action, but not her medical details." |
| 2:50 | Escalation reaches *Flight surgeon* (+60 s); presenter shows downlink queue | "The ground gets a priority packet, queued if the link is down. Mission control sees status only; the flight surgeon sees full detail." |
| 3:15 | Left window: **I'm OK: acknowledge** | "When she responds, escalation stops and it's logged in a tamper-evident audit chain." |
| 3:40 | Presenter: **Irregular heartbeat** or **Fever** on another crew member | "Slower conditions use longer persistence windows; here at demo speed." |
| 4:20 | Presenter: **Reset demo** | |
| 4:30 | Close | "NASA asked for an offline Windows hub that connects medical devices over Bluetooth and USB. This is that hub, with the safety logic on top. Next: desktop app and native device gateway." |

## Likely judge questions
- **Is the AI deciding emergencies?** No. Emergencies use fixed, testable medical thresholds. Personal
  baselines only add early "observe" notes and can never suppress an emergency rule.
- **What if the sensor is wrong?** Implausible values are rejected; poor signals pause clinical rules
  and raise a sensor advisory instead.
- **What if there's no link to Earth?** Everything runs onboard; the downlink queue stores and
  forwards when the link returns.
- **Can it use real devices?** Yes, standard Bluetooth health devices (pulse oximeter, BP cuff,
  thermometer, heart-rate strap) are decoded today via `/api/v1/ingest/ble`; FHIR import works.
  Bluetooth GHS, IEEE 11073 SDC, DICOM ultrasound and ECG files are next.
- **Are the thresholds clinically approved?** Not yet: they are drafts for flight-surgeon review.
