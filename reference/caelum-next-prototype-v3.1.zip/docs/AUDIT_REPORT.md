# CAELUM audit and remake report (v2.0.0 → v3.1.0)

**Scope:** full codebase (`caelum-next.zip`): FastAPI backend, Next.js 16 frontend, acquisition,
interoperability, docs, scripts, CI. **Method:** code reading, running the test suite, building the
frontend offline, and probe scripts that reproduce each safety defect, then a live end-to-end run.

> CAELUM is advisory research software. It is not approved for clinical use. All alert thresholds
> are engineering placeholders (`RULES_VERSION = 3.0.0-draft`) and need flight-surgeon sign-off.

---

## 1. Executive summary

| Area | Before (v2.0.0) | After (v3.0.0) |
|---|---|---|
| Alert safety | Absolute limits could be bypassed; alerts not per astronaut; most limits never evaluated; no persistence/hysteresis; no escalation | Absolute limits always evaluated; per-astronaut; persistence, hysteresis, supersession, data-gap handling; 5-stage escalation; 11 safety tests |
| Data honesty | Random-walk vitals, silent fallback to demo data, fake "STREAMING" devices, nominal defaults for missing values | Explicit demo/live mode, visible data-source badge, no silent fallback, no fabricated defaults, simulator labelled end to end. **Random-walk vitals on 3 screens remain (F07)** |
| Security | No password check; no token = commander; hard-coded secret; unauthenticated endpoints | bcrypt + JWT, all endpoints authenticated, role and per-astronaut scoping, Mission Control redaction |
| Integrity | Audit hash ignored timestamps; downlink queue crashed on every insert | HMAC chain covering every field; working sequenced downlink queue with allow-lists |
| Device integration | Adapters returned constants; no real decoding | Standard Bluetooth health profiles decoded; FHIR import/export; adapter catalogue with planned GHS/SDC/DICOM/ECG |
| Build & CI | Build failed offline; duplicate stale codebase; CI misconfigured | Offline build; single pnpm workspace; CI fixed |
| Tests | 19, none safety-relevant | 38 (+ live smoke test), safety rules encoded as tests |
| Docs | Claimed screens were "connected to functioning backend" | Honest status ledger (`IMPLEMENTATION_STATUS.md`) |

---

## 2. What NASA asks for

### 2.1 yet2 challenge: PC application to run medical and scientific devices
NASA sought software for spaceflight that lets a Windows PC replace a phone as the host for
portable mHealth and scientific devices
(<https://www.yet2.com/active-projects/nasa-seeking-pc-application-to-run-medical-scientific-devices/>).
Its stated constraints, and how CAELUM maps to them:

| NASA constraint (paraphrased) | CAELUM v3 design | Status |
|---|---|---|
| Runs on Windows 10 | Web UI runs in any browser on Windows; Python backend runs on Windows | Partial: desktop package planned (§6, P3) |
| Continuous Bluetooth and USB connection to peripheral devices | Standard BLE health-profile decoders + `/ingest/ble`; adapter catalogue | Partial: native BLE/USB gateway service planned (P1) |
| Very resource lean; drop phone functions not needed in flight | SQLite, single FastAPI process, no cloud, no telemetry | Partial: footprint benchmark planned |
| Simple interface for non-programmers | Existing crew UI; data-source badge; plain-language alerts | Partial: live wiring of screens (F07) |
| Store and expose device data on the PC file system | SQLite database; FHIR export | Partial: raw-file export planned |
| Updatable for new hardware, apps and interfaces | Parameter catalogue + adapter registry | Partial: plug-in loading planned |
| Fail-over to another instance on separate hardware | Not yet | Planned (P2) |
| No internet connection required | Offline build, no remote fonts or services | Done |
| Ultimately meets NASA flight-software requirements | Tests, CI, audit chain, documented safety rules | Partial: NPR 7150.2 classification, IEC 62304 / ISO 14971 planned |

### 2.2 Related NASA needs
- **Multifunctional integrated medical device** (yet2): fewer devices combining vital signs
  (SpO₂, temperature, heart rate, blood pressure), secure audio/video, ultrasound, ECG,
  defibrillation, laryngoscopy, visual acuity and otoscopy.
- **Orion medical system (Artemis II):** 128 conditions planned for, 139 resources, 5 digital
  diagnostic devices (ECG, otoscope, stethoscope, pulse oximeter, BP monitor). All connect to
  mobile devices; the ECG needs one; only one connects natively to Windows, Orion's only
  operating system (NTRS 20210025203).
- **Exploration Medical Capability:** evaluating a single vital-signs system integrated with other
  medical capabilities. Ultrasound in off-the-shelf integrated devices did not meet many needs,
  so higher-quality ultrasound inside a custom integration is preferred (NTRS 20250000099).

### 2.3 The actual problem
1. **Crew self-reliance:** on long missions astronauts must spot health changes themselves, with
   delayed or no ground contact (the NASA Space Apps challenge statement).
2. **Fragmented devices:** discrete devices, manual file transfers, minimal data integration.
3. **Host mismatch:** device apps assume a phone; spacecraft computers run Windows.
4. **Trust:** a monitoring system is only safe if every number on screen is real, current and
   traceable, and every alarm is reliable. Alarm fatigue and fabricated values are both hazards.

CAELUM's role: **the offline hub** that connects devices through open standards, keeps one
trustworthy record, and turns it into explained, escalating alerts for crew and flight surgeons.

---

## 3. Findings

Severity: **S1** patient safety · **S2** security / data integrity · **S3** correctness / standards ·
**S4** quality / UX. Status: **Fixed** · **Partial** · **Open**.

### 3.1 S1: patient safety
| ID | Finding | Evidence (v2) | Fix (v3) | Status |
|---|---|---|---|---|
| F01 | Heart-rate absolute limit skipped whenever a baseline existed | HR 190 bpm with baseline SD 50 → no alert (probe) | `rules.py`: absolute rules always run; baseline adds observe-only alerts | Fixed |
| F02 | Alerts had no `astronaut_id`; de-duplication by module+level merged astronauts | Second astronaut's critical SpO₂ returned the first astronaut's alert | Alerts keyed by astronaut + rule | Fixed |
| F03 | Temperature, cabin O₂, low HR, respiration limits defined but never evaluated | `core_temp 40.5`, `cabin_o2 15`, `hr 28` → None | 12 rules covering SpO₂, HR high/low, respiration, temperature, AF probability, CO₂, O₂ | Fixed |
| F04 | No persistence or hysteresis (docs claimed both); one sample alarms; alarms never clear | Code review | Persistence, separate clear threshold + clear period, data-gap restart | Fixed |
| F05 | No escalation; nothing happens if the astronaut can't respond | Code review | Escalation plan per level, background tick, notifications, crew-wide banner, acknowledge button | Fixed |
| F06 | Frontend falls back to demo data on any error; shows demo alerts when there are zero alerts | `clients.ts` `getAlerts` | Explicit `DATA_MODE`; live mode never falls back; empty list stays empty | Fixed for alerts, vitals, baselines, audit; other modules demo-only |
| F07 | Displayed vitals are `Math.random()` walks | `Home.tsx` 124–141, `NextAppFrame.tsx` 166–178, `modules/heart` 37–48 | `useVitals()` from the telemetry store; non-live values show NO DATA / STALE / SIGNAL UNUSABLE | Fixed |
| F08 | Adapters and vehicle bridge substitute nominal values (SpO₂ 98, CO₂ 3280 ppm, O₂ 21.3 kPa) | `acquisition/*` | Missing → `None`; unimplemented garment adapter raises | Fixed |
| F09 | WebSocket streams constant synthetic vitals, unlabelled; frontend never connects | `telemetry_ws.py` | Event bus fed by the ingestion pipeline; token-authenticated, role-filtered; simulator labelled | Fixed |
| F10 | HR/HRV return 0.0 when not computable (reads as asystole or as a value) | `ecg.py`, `hrv.py` | Return `None` | Fixed |
| F11 | QRS detector has no band-pass; overcounts under noise | 50 beats vs 36 true, HR 118 vs 72 | 5–15 Hz band-pass, rolling adaptive threshold, R-peak refinement; test at 48/72/120 bpm | Fixed |
| F12 | PPG signal quality always "GOOD" | `sqi.py` stub | Spectral pulse-band concentration index | Fixed |
| F13 | GET endpoints seed fake devices ("STREAMING", battery), fake alerts, fake baselines | `devices.py`, `alerts.py`, `vitals.py` | No fake seeding; devices start NO_DATA | Fixed |

### 3.2 S2: security and data integrity
| ID | Finding | Fix | Status |
|---|---|---|---|
| F14 | Login ignored the password | bcrypt verification | Fixed |
| F15 | Missing token treated as the commander | 401 without a valid token | Fixed |
| F16 | Hard-coded JWT secret in code and `.env.example` | Required outside dev; ≥ 32 chars; ephemeral in dev | Fixed |
| F17 | Vitals, observation POST, alert acknowledge, audit had no auth | All endpoints authenticated, role-checked | Fixed |
| F18 | Roles and privacy tiers enforced only in the browser (zustand toggle) | Server scoping; UI role synced from the signed-in user | Fixed (live mode) |
| F19 | Acknowledging actor taken from a query parameter defaulting to the commander | Actor from token; only affected astronaut or medical roles | Fixed |
| F20 | Audit hash excluded timestamp; plain SHA-256 recomputable; seeded by GET; write race | HMAC-SHA256 over all fields, lock, no seeding | Fixed |
| F21 | Downlink privacy filter was a deny-list | Per-channel allow-lists | Fixed |
| F22 | `python-jose` (unmaintained) and unused `passlib` | PyJWT | Fixed |
| F23 | CORS allowed all methods and headers with credentials | Explicit methods and headers | Fixed |

### 3.3 S3: correctness and standards
| ID | Finding | Fix | Status |
|---|---|---|---|
| F24 | Downlink enqueue crashed on every insert (`sequence_num` NOT NULL, autoincrement on a non-key column) | Sequence assigned under lock; unique | Fixed |
| F25 | Baseline names (`restHR`) never matched observation names (`hr`) | Single catalogue `domain/parameters.py` | Fixed |
| F26 | Baselines used mean/SD (docs said robust) and would include simulated data | Median/MAD, GOOD/DEGRADED only, simulated excluded, `INSUFFICIENT_DATA` below 30 samples | Fixed |
| F27 | Tidal volume invented (amplitude × 12 mL) | Relative amplitude only, marked UNCALIBRATED | Fixed |
| F28 | FHIR: SpO₂ coded 2708-6 (arterial blood gas) instead of 59408-5 (pulse oximetry); cabin CO₂ categorised as vital sign; ids collide per second | Codes from catalogue, correct categories, stable ids, SIMULATED meta tag | Fixed (Observation); DiagnosticReport open |
| F29 | CCSDS: secondary-header flag set with no secondary header; no length check | Flag only with a CUC time header; length validation; sequence wrap | Fixed |
| F30 | Open MCT dictionary hand-written, diverged from data | Generated from catalogue | Fixed |
| F31 | Alert ids from second-resolution timestamps collide | UUID ids | Fixed |
| F32 | Observations timestamped at receipt; no device provenance | `measured_at`, `received_at`, `device_id`, `quality`, `simulated` | Fixed |
| F33 | No unit or plausibility validation | Unit conversion table, plausible ranges, rejection reasons | Fixed |
| F34 | Fatigue "validated mathematical model" is a hand-weighted heuristic | Renamed `fatigue_heuristic_v0`, `NOT_VALIDATED` | Fixed; real models M1–M9 open |
| F35 | SQLite returns timezone-naive datetimes (comparison errors) | `as_utc()` everywhere | Fixed |
| F36 | No real device path | BLE HR/PLX/BP/thermometer + FHIR import | Partial: GHS, SDC, DICOM, ECG files open |

### 3.4 Build, CI and documentation
| ID | Finding | Fix | Status |
|---|---|---|---|
| F37 | Production build fails offline (`next/font/google`); fatal for an air-gapped build | Local `@fontsource/outfit` | Fixed |
| F38 | Stale duplicate codebase at repo root (`src/`, `app/`, react-router shim) diverging from `frontend/` | Removed; pnpm workspace | Fixed |
| F39 | CI: `setup-node` pnpm cache before pnpm installed; `frontend/` had no lockfile | Reordered; workspace lockfile; separate jobs | Fixed |
| F40 | `next lint` script (removed in Next.js 16) | Removed | Fixed |
| F41 | Next.js mock routes `/api/alerts`, `/api/vitals` served demo data | Removed | Fixed |
| F42 | Docs claimed "connected to functioning backend", hysteresis, audit-on-alert | Honest ledger | Fixed: other docs need review (P1) |
| F43 | Tests passed but covered nothing safety-relevant | 38 tests incl. 11 alert-safety tests | Fixed |

### 3.5 S4: UX and accessibility
| ID | Finding | Status |
|---|---|---|
| F44 | Zoom disabled (`maximumScale: 1`, `userScalable: false`) and text unselectable | Fixed |
| F45 | Hard-coded data in screens (e.g. `MONTH_DATA` in Home) | Open |
| F46 | No sign-in | Fixed (basic `/login`) |
| F47 | Mission Control routes visible to anyone | Fixed (role gate in live mode) |
| F48 | Crew identity hard-coded in `NextAppFrame` (`AX-07`) | Fixed (crew API + crew switcher) |

---

## 4. What was remade

```
backend/app/
  config/settings.py        env-driven, secret required outside dev
  domain/parameters.py      single parameter catalogue (units, LOINC, IEEE 11073, ranges)
  databases/models.py       provenance on every observation; alerts per astronaut; notifications
  ingestion/pipeline.py     validate → convert → store → evaluate → publish
  alerts/rules.py, engine.py  absolute limits, persistence, hysteresis, escalation
  baselines/engine.py       median/MAD personal baselines
  auth/                     bcrypt + PyJWT, roles, per-astronaut scoping
  medical/audit.py          HMAC hash chain
  communications/queue.py   sequenced downlink with channel allow-lists
  devices/                  BLE health decoders, FHIR import, simulator, adapter catalogue
  realtime/bus.py           event bus for the WebSocket
  api/v1/                   auth, crew, devices, ingest, vitals, alerts, audit, interop, models
interoperability/           FHIR export, CCSDS packets, Open MCT dictionary
acquisition/                no fabricated defaults
frontend/src/api/           config (data mode), session, http (auth), live (WebSocket store), clients
frontend/src/components/DataModeBadge.tsx, frontend/app/login/page.tsx
```

### Data flow
`device / gateway → POST /ingest/* → pipeline (validate, units, plausibility, provenance) →
SQLite → alert engine (rules + baseline) → audit + downlink + notifications → event bus →
WebSocket (role-filtered) → UI`. Escalation runs every second in the background.

### Alert behaviour (draft thresholds)
| Rule | Fires when | Clears when |
|---|---|---|
| SpO₂ critical | < 85 % for 15 s | ≥ 90 % for 60 s |
| SpO₂ warning | < 90 % for 60 s | ≥ 92 % for 60 s |
| HR critical high / low | > 180 for 30 s / < 40 for 30 s | ≤ 160 / ≥ 45 for 60 s |
| HR warning (rest only) | > 130 for 120 s, skipped if activity > 0.3 | ≤ 120 for 120 s |
| Respiration | > 30 for 120 s (warning), < 6 for 30 s (critical) | ≤ 25 / ≥ 8 |
| Core temperature | > 38.0 for 10 min (warning), > 39.5 for 5 min (critical) | ≤ 37.7 / ≤ 39.0 |
| AF probability | > 0.8 for 5 min | ≤ 0.5 for 10 min |
| Cabin CO₂ / O₂ | > 4 mmHg for 15 min / < 16 kPa for 30 s | ≤ 3.5 / ≥ 17 |
| Baseline deviation | robust \|z\| ≥ 4 for 10 min (observe only) | \|z\| ≤ 2.5 for 10 min |
| Sensor quality | POOR / UNUSABLE → advisory; clinical rules paused | GOOD sample |

Escalation: **critical** astronaut + medical officer at 0 s, sound 15 s, crew 30 s, ground 60 s;
**warning** crew at 60 s; **observe** reminder at 1 h, medical officer at 24 h. Acknowledgement stops it.

---

## 5. Verification evidence
- `cd backend && uv run pytest` → **41 passed** (adds demo-control and crew-emergency tests): alert engine (11), API and auth (8), BLE decoders
  (6), signal processing (4), interoperability (3), acquisition (4), plus fixtures.
- Live run, simulator `hypoxia`: critical SpO₂ alert after 15 s sustained, escalation stage 5,
  downlink packets 1–3 (flight surgeon, redacted mission-control copy, escalation), labelled simulated,
  no server errors.
- Frontend: `tsc --noEmit` clean; `next build` succeeds with no network access.
- Pitch rehearsal through the Next.js server (v3.1): presenter set *hypoxia* on ast-01 → critical
  alert → escalation reached the whole crew; a second astronaut's WebSocket received only her own
  data plus the crew escalation; `/alerts/crew` showed the emergency without physiology; the
  flight surgeon saw the alert; downlink held the critical packets.
- **Not verified:** clicking through the UI in a real browser (no browser in the build environment).

---

## 6. Roadmap

### Done in v3.1 (prototype demo release)
- F07 live vitals, F05 escalation UI and crew-wide banner, F18/F47/F48 server roles and crew.
- Presenter console (`/presenter`), simulator for all crew with 8 scenarios, demo timing,
  one-command launcher (`scripts/demo.py`), pitch guide (`docs/PITCH_GUIDE.md`).

### P0: next
1. Historical charts and summary tiles still come from the demo evaluation data set even in live
   mode (labelled by the badge). Feed them from `GET /vitals/history` and `/vitals/baselines`.
2. Live mode: every demo-only module (radiation, mood, exercise, triage, hazards...) renders
   "Not connected" (`NotConnectedError`). *Acceptance:* with the backend stopped in live mode,
   no screen shows a number.

### P1: plug-and-play devices (the NASA ask)
5. Native gateway service (`bleak`) for standard BLE health devices → `POST /ingest/ble`.
6. Device screen: `GET /devices` (LIVE/STALE/NO_DATA), adapter catalogue, registration form.
7. Adapters with tests: Bluetooth GHS (IEEE 11073-10206), IEEE 11073 SDC (read-only, `sdc11073`),
   DICOM ultrasound import attached to event packets, ECG files (HL7 aECG, DICOM waveform, EDF+).
8. Review remaining docs against the code; delete claims without tests.

### P2: robustness
9. Alembic migrations; persistent rule timers across restarts.
10. Fail-over: second instance on separate hardware with replicated store and health checks.
11. Resource benchmark (CPU, RAM, disk/day) on a laptop-class machine.
12. ML models M1–M9 per the project specification, each with a dataset card, metrics and a
    validation status shown in the UI.

### P3: flight path
13. Desktop packaging for Windows (e.g. Tauri or Electron) with the backend as a local service.
14. Software classification (NPR 7150.2), IEC 62304 lifecycle, ISO 14971 risk file,
    flight-surgeon sign-off of thresholds.

---

## 7. How to run
```bash
pnpm install
cd backend && uv sync --extra dev && cd ..
# backend with labelled simulator (demo users, password: caelum-dev)
CAELUM_ENABLE_SIMULATOR=true CAELUM_SIMULATOR_SCENARIO=hypoxia npm run dev:backend
# frontend against the backend
NEXT_PUBLIC_DATA_MODE=live npm run dev:frontend   # sign in at /login as varga / surgeon / mcc
```
Demo users: `varga`, `lin` (astronauts), `chen` (crew medical officer), `surgeon`, `mcc`,
`gateway` (device ingestion), `admin`.

---

## 8. Instruction prompt for the AI coding assistant

```
You are working on CAELUM, an advisory crew-health monitoring web system (FastAPI backend in
/backend, Next.js 16 frontend in /frontend, pnpm workspace). Read AGENTS.md and
docs/AUDIT_REPORT.md first; finding IDs (F01...) refer to that report.

Non-negotiable rules:
- Never fabricate or default physiological values. Missing data shows NO DATA / STALE / UNAVAILABLE.
- In NEXT_PUBLIC_DATA_MODE=live never fall back to demo data. Label simulated data everywhere.
- Absolute alert limits can never be suppressed by baselines. Any rule change bumps RULES_VERSION
  and adds a test in backend/tests/test_alert_engine.py.
- Read-only to spacecraft systems and therapeutic devices.
- Every endpoint authenticated and scoped by role and astronaut. Mission Control never gets raw physiology.
- Parameters come only from backend/app/domain/parameters.py.

Work through docs/AUDIT_REPORT.md section 6 in order (P0, then P1, then P2). Keep the pitch demo
(python scripts/demo.py + docs/PITCH_GUIDE.md) working after every change.
After every task run:
  cd backend && uv run pytest
  pnpm typecheck:frontend && pnpm build:frontend
and keep both green. Add tests for every new behaviour. Update docs/IMPLEMENTATION_STATUS.md
only with what a test proves. Report each finished item by ID with the evidence.
```
