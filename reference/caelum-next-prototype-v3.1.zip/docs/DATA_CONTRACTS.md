# CAELUM — Data Contracts & Interface Schemas

## Overview
All inter-service and frontend-backend communications adhere to versioned, strictly typed schemas. Python data contracts use Pydantic v2; TypeScript contracts use Zod and TypeScript strict interfaces.

---

## 1. Core Endpoints & Schemas

### Live Telemetry WebSocket (`/ws/telemetry`)
```json
{
  "seq": 1024,
  "timestamp": "2026-10-09T12:00:00.000Z",
  "astronaut_id": "ast-01",
  "vitals": {
    "heart_rate": 64.0,
    "hrv_rmssd": 48.0,
    "spo2": 98.0,
    "respiration_rate": 14.5,
    "skin_temperature": 34.8,
    "signal_quality": "GOOD"
  },
  "environment": {
    "cabin_o2_kpa": 21.3,
    "cabin_co2_ppm": 3280.0,
    "cabin_pressure_kpa": 101.1,
    "radiation_rate_usv_h": 21.5
  },
  "ecg_lead_ii_chunk": [0.02, 0.05, 0.15, 1.25, -0.28, 0.28],
  "devices_streaming": 4
}
```

### Observation Ingestion Contract (`POST /api/v1/vitals/observation`)
```json
{
  "astronaut_id": "ast-01",
  "parameter": "hr",
  "value": 68.0,
  "unit": "bpm",
  "source": "AstroSkin Smart Garment",
  "signal_quality": "GOOD",
  "classification": "measured",
  "uncertainty": 1.2
}
```

### Cryptographic Audit Ledger Entry (`GET /api/v1/assessments/audit-log`)
```json
{
  "id": 42,
  "actor": "Dr. Marcus Webb, MD",
  "role": "Medical Officer",
  "action": "Acknowledged alert alt-hrv-01 for Cdr. Ines Varga",
  "target_id": "alt-hrv-01",
  "timestamp": "2026-10-09T14:30:00.000Z",
  "prev_hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
  "current_hash": "a1b2c3d4e5f6...",
  "valid": true
}
```
