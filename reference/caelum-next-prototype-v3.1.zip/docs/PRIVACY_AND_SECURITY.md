# CAELUM — Privacy, Security & Trust Boundaries

## Overview
Astronaut physiological data constitutes highly sensitive personal medical information. CAELUM enforces fine-grained Role-Based Access Control (RBAC) in the authoritative backend, separating operational vehicle telemetry from private medical consultations.

---

## 9. Security & Trust Boundaries

```mermaid
flowchart TB
    subgraph Users["System Actors & Roles"]
        Astronaut["Astronaut Crew Member<br/>(Full access to personal health & vitals)"]
        CMO["Crew Medical Officer / Flight Surgeon<br/>(Full clinical access, SBAR triage, alert reviews)"]
        FlightController["Mission Control / Flight Dynamics<br/>(ECLSS, Radiation status, aggregated readiness ONLY)"]
        Researcher["Ground Biomedical Researcher<br/>(Authorized, de-identified datasets ONLY)"]
    end

    subgraph TrustBoundary["Authoritative Security Boundary (FastAPI JWT / RBAC)"]
        AuthMiddleware["FastAPI Security & RBAC Enforcement<br/>(Bearer JWT, Signed Claims)"]
        
        subgraph DataDomains["Enforced Data Domains"]
            DomainPublic["Operational Status Domain<br/>(ECLSS CO2, Dose Rate, Device Battery)"]
            DomainClinical["Clinical Health Domain<br/>(ECG Waveforms, Blood Pressure, SBAR, Diagnoses)"]
            DomainPrivate["Private Behavioral Domain<br/>(Mental Health Diary, Sleep Subjective Rating)"]
        end
    end

    Astronaut --> AuthMiddleware
    CMO --> AuthMiddleware
    FlightController --> AuthMiddleware
    Researcher --> AuthMiddleware

    AuthMiddleware -->|Permitted| DomainPublic
    AuthMiddleware -->|Restricted: Astronaut & CMO Only| DomainClinical
    AuthMiddleware -->|Restricted: Individual Astronaut Only| DomainPrivate
```

---

## Access Control Matrix

| Data Domain | Astronaut | Medical Officer (CMO) | Mission Control | Researcher (Approved) |
| :--- | :---: | :---: | :---: | :---: |
| **Personal Vitals & ECG** | Read / Self-Log | Full Read / Clinical Review | Aggregated Status Only | De-identified |
| **Spacecraft ECLSS & Radiation** | Read | Read | Full Read | Read |
| **Private Behavioral Health Diary** | Full Access | Requires Crew Consent | No Access | No Access |
| **Clinical Encounter Notes (SBAR)** | Read Self | Full Read / Write | Summary Only | No Access |
| **Audit Ledger Verification** | Read | Read | Read | Read |
