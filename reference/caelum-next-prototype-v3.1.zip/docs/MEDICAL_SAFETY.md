# CAELUM — Medical Safety, Alert Evaluation & Human Factors

## Overview
CAELUM is an advisory astronaut health intelligence system designed to minimize false alarms and clinical alarm fatigue. It implements multi-parameter sensor gating, persistence timers, hysteresis bands, and individualized longitudinal baselines.

---

## 6. Traceable Alert Evaluation Engine

```mermaid
flowchart TD
    ObsIn["New Measurement Observation Ingested"] --> QualityCheck{"Signal Quality<br/>Acceptable?<br/>(SQI != POOR / UNUSABLE)"}
    
    QualityCheck -- No --> DiscardAlarm["Suppress Clinical Alarm<br/>Emit Hardware Quality Advisory"]
    QualityCheck -- Yes --> BaselineQuery["Retrieve Individual Baseline & NASA STD-3001 Bounds"]
    
    BaselineQuery --> RuleEval["Multi-Parameter Rule Evaluation"]
    
    RuleEval --> DevTest{"Deviation Exceeds<br/>Warning / Critical Threshold?"}
    
    DevTest -- No --> NormalState["Maintain Normal Status (Green Circle)"]
    DevTest -- Yes --> Hysteresis{"Sustained Beyond<br/>Persistence Window?<br/>(Hysteresis Timer)"}
    
    Hysteresis -- No --> Transient["Log Transient Deviation<br/>Do Not Trigger Acoustic / Modal Alarm"]
    Hysteresis -- Yes --> ActiveAlert["Emit Active Clinical Alert<br/>(Shape-Coded: Diamond Observe, Hexagon Warning, Octagon Critical)"]
    
    ActiveAlert --> AuditLog["Append to Cryptographic Audit Ledger"]
    ActiveAlert --> DownlinkQueue["Queue for Flight Surgeon Downlink (Priority: CRITICAL)"]
    ActiveAlert --> CrewUI["Present in Crew Overview with 'Why am I seeing this?' Protocol"]
```

---

## Shape-Coded Severity System (NASA STD-3001)

To protect color-deficient crew members and maintain immediate situational awareness under emergency lighting or high-stress cockpit vibration, alert severity is encoded by geometric shape, not merely color:

| Severity Level | Shape Identifier | Color Scheme | Clinical Action Required |
| :--- | :--- | :--- | :--- |
| **Normal** | Circle (●) | Green / Cyan | Standard flight routine; within personal baseline bounds. |
| **Observe** | Diamond (◇) | Amber / Yellow | Early trend deviation; review procedure protocol, repeat test. |
| **Warning** | Hexagon (⬡) | Orange | Significant physiological shift or ECLSS breach; notify CMO. |
| **Critical** | Octagon (🛑) | Red / Bright White | Emergency clinical event; immediate medical countermeasure required. |
