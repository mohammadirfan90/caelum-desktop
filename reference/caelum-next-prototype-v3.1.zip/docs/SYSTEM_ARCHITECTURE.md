# CAELUM — System Architecture

## Overview
CAELUM is the autonomous onboard Crew Health Intelligence & Biomedical Telemetry platform. It serves as the primary medical computing host aboard crewed spacecraft, acquiring real-time physiological data from wearable biometric garments, personal dosimeters, and clinical instruments, alongside vehicle environmental life support telemetry (ECLSS).

---

## 1. Complete Onboard-to-Ground Architecture

```mermaid
flowchart TB
    subgraph SpacecraftEnvironment["Spacecraft Environment & Sensor Sources"]
        BioSensors["AstroSkin Garment (3-Lead ECG, Respiration, SpO2, Temp)<br/>Empatica E4 / NASA Wristband (EDA/GSR, Temp, PPG)<br/>Active Dosimeter (uSv/h, mSv) & Diagnostic Devices"]
        ECLSSBus["Spacecraft Avionics Bus<br/>(Cabin O2, CO2, Barometric Press, Temp, MET)"]
    end

    subgraph CAELUM_Onboard["CAELUM Onboard Core System"]
        subgraph AcquisitionGate["Local Acquisition Subsystem"]
            Adapters["Hardware Protocol Adapters<br/>(BLE Bridge, Serial, Driver)"]
            RO_Bridge["Read-Only Vehicle Telemetry Bridge"]
            SyncClock["MET Clock Synchronizer & Quality Engine"]
        end

        subgraph AuthoritativeBackend["Authoritative Python FastAPI Service (Persistent)"]
            SigEngine["Biomedical Signal Processing (SciPy)<br/>(Butterworth, Pan-Tompkins, HRV, SQI)"]
            BaseEngine["Longitudinal Baseline Engine<br/>(Mission Phase, Circadian Bands)"]
            AlertEngine["Traceable Clinical Alert Engine<br/>(NASA STD-3001, Hysteresis, Confidence)"]
            AuditChain["Tamper-Evident SHA-256 Medical Audit Trail"]
            DB[("Onboard SQLite WAL / PostgreSQL Store")]
            StoreForward["Store-and-Forward Downlink Queue<br/>(Priority & Retries)"]
        end

        subgraph PresentationLayer["Presentation Subsystem (Next.js 16 + React 19)"]
            WebConsole["Crew Workstation & Tablet Web Client<br/>(Cardiology, Ventilation, ECLSS, Alerts, SBAR)"]
        end
    end

    subgraph SpaceGroundLink["Spacecraft-to-Ground Communications"]
        CCSDS_Frame["CCSDS Space Packet (APID 0x01E4)<br/>CFDP File Transport / DTN Transport"]
    end

    subgraph GroundSegment["Ground Operations & Mission Control"]
        MCC_OpenMCT["NASA Open MCT / Yamcs<br/>(Operational Telemetry Visualization)"]
        FlightSurgeon["Flight Surgeon Medical Console<br/>(Encrypted Clinical Records & Review)"]
        ResearchDB["Authorized De-identified Research Archive<br/>(NASA LSDA Compatible)"]
    end

    BioSensors --> Adapters
    ECLSSBus --> RO_Bridge
    Adapters --> SyncClock
    RO_Bridge --> SyncClock
    SyncClock --> SigEngine
    SigEngine --> BaseEngine
    BaseEngine --> AlertEngine
    AlertEngine --> AuditChain
    SigEngine --> DB
    AlertEngine --> DB
    AuditChain --> DB

    AuthoritativeBackend <== "REST APIs & WebSockets" ==> PresentationLayer

    AlertEngine --> StoreForward
    AuditChain --> StoreForward
    StoreForward ==> CCSDS_Frame
    CCSDS_Frame ==> MCC_OpenMCT
    CCSDS_Frame ==> FlightSurgeon
    CCSDS_Frame ==> ResearchDB
```

---

## 2. Key Subsystems & Boundaries
1. **Acquisition Layer (`acquisition/`)**: Decoupled from user interface sessions. Ingests raw telemetry frames, estimates clock drift relative to Spacecraft Master Time (MET), evaluates Signal Quality Indices (SQI), and buffers packets safely.
2. **Authoritative Backend (`backend/app/`)**: Built on FastAPI, SQLAlchemy 2, Pydantic v2, and SciPy. Processes physiological waveforms, evaluates individual baselines and clinical alerts, maintains cryptographically chained audit trails, and manages the downlink queue.
3. **Presentation Layer (`frontend/`)**: Next.js 16 App Router application rendering 31 modules with native navigation, WebSocket live streaming, and honest status indication.
4. **Interoperability Layer (`interoperability/`)**: Standardizes interfaces using HL7 FHIR R4, CCSDS Space Packet Protocol, and NASA Open MCT dictionaries.
